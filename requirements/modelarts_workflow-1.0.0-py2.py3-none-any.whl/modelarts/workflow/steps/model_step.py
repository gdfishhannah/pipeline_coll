import logging
import json

import attr
from attr import validators

from modelarts.workflow.util.utils import (
    get_obs_url,
    get_random_name,
    get_next_version_name,
)
from modelarts.workflow.core.serialize import (
    serialize,
    prepare_for_properties,
)
from modelarts.workflow.core.data import (
    AbstractData,
    AbstractDataConsumption,
    AbstractOutputConfig
)
from modelarts.workflow.steps.common_input import CommonInput
from modelarts.workflow.steps.step_state_mapping import StepStateMapping
from modelarts.workflow.core.steps import (
    Step,
    StepTypeEnum,
    StepState,
    AbstractOutput
)
from modelarts.workflow.core.entities import TransformType
from modelarts.workflow.core.placeholder import Placeholder
from modelarts.workflow.client.model_predictor_client import ModelPredictorClient
from modelarts.workflow.data.model import ModelData, MODEL_DATA_TYPE, GalleryModel
from modelarts.workflow.data.obs import OBSPath, OBSPlaceholder, OBSConsumption
from modelarts.workflow.data.swr import SWRImage, SWRImagePlaceholder
from modelarts.workflow.data.storage import Storage
from modelarts.workflow.data.data_selector import DataConsumptionSelector

MODEL_STATE_MAPPING = {
    "publishing": StepState.Running,
    "published": StepState.Completed,
    "failed": StepState.Failed,
}

MODEL_TYPE = ("TensorFlow", "MXNet", "Caffe", "Spark_MLlib",
              "Scikit_Learn", "XGBoost", "Image", "PyTorch", "Template", "Custom")
TYPE_OF_MODEL_TYPE = (str, Placeholder)
MODEL_INSTALL_TYPE = ("real-time", "edge", "batch")


def _verify_model_type(instance, attribute, value):
    if not isinstance(value, TYPE_OF_MODEL_TYPE):
        raise TypeError("Type(model_type) must be one of the {}. But "
                        "provided: {}.".format(TYPE_OF_MODEL_TYPE, type(value)))
    if isinstance(value, str) and value not in MODEL_TYPE:
        raise ValueError("Model type must be one of the values: {}. But "
                         "provided: {}.".format(MODEL_TYPE, value))


def _verify_model_install_type(instance, attribute, install_type_list):
    if not install_type_list:
        return
    if not isinstance(install_type_list, list):
        raise TypeError("The type of install_type field must be list, but provided {}".format(type(install_type_list)))
    for value in install_type_list:
        if isinstance(value, str) and value not in MODEL_INSTALL_TYPE:
            raise ValueError("Model install type must be one of the values: {}. But "
                             "provided: {}.".format(MODEL_INSTALL_TYPE, value))


@attr.s
class Params:
    """"
    Model create "input_params" and "output_params" structure

    Attributes:
        url (str): api url path
        param_name (str): parameter name, can't exceed 64 characters
        param_type: parameter type, include {int/string/float/timestamp/date/file}
        min: default null, when param-type is "int" or "float", it can fill in
        max: default null, when param-type is "int" or "float", it can fill in
        param_desc: default null, parameter description, can't exceed 100 character
    """
    url = attr.ib(default=None, validator=validators.instance_of((str, type(None))))
    method = attr.ib(default=None, validator=validators.instance_of((str, type(None))))
    protocol = attr.ib(default=None, validator=validators.instance_of((str, type(None))))
    param_name = attr.ib(default=None, validator=validators.instance_of((str, type(None))))
    param_type = attr.ib(default=None)
    min = attr.ib(default=None, validator=validators.instance_of((int, float, type(None))))
    max = attr.ib(default=None, validator=validators.instance_of((int, float, type(None))))
    param_desc = attr.ib(default=None, validator=validators.instance_of((str, type(None))))


@attr.s
class Packages:
    """
    Dependencies packages set

    Attributes:
        package_name (str): dependency package name
        package_version (str): dependency package version
        restraint (str): version restraint conditions, can choose "EXACT", "ATLEAST", "ATMOST"
    """
    package_name = attr.ib(validator=validators.instance_of(str))
    package_version = attr.ib(default=None, validator=validators.instance_of((str, type(None))))
    restraint = attr.ib(default=None, validator=validators.instance_of((str, type(None))))


@attr.s
class Dependencies:
    """
    The packages that need to install in runtime

    Attributes:
        installer (str): install way, can choose "conda","yum","pip", "apt-get
        packages (list[Packages]): dependency package set
    """
    installer = attr.ib(validator=validators.instance_of(str))
    packages = attr.ib(validator=validators.instance_of(list))


@attr.s
class TemplateInputs:
    """
    Configure the source path of the model

    Attributes:
        input_id (Union[str, Placeholder]): enter the item ID, obtained from the template details
        input (Union[str, Placeholder, Storage]): template input path, which can be OBS file path or OBS directory path
    """
    input_id = attr.ib(validator=attr.validators.instance_of((str, Placeholder)))
    input = attr.ib(validator=attr.validators.instance_of((str, Placeholder, Storage)))


@attr.s
class Template:
    """
    The related configuration items of the template, can use the template to import the model

    Attributes:
        template_id (Union[str, Placeholder]): the template ID, an input and output mode will be built into the template
        infer_format (Union[str, Placeholder]): Input and output mode IDs,
                                            overriding the built-in input and output modes in the template when provided
        template_inputs (Union[List[TemplateInputs], TemplateInputs]): configure the source path of the model
    """
    template_id = attr.ib(validator=attr.validators.instance_of((str, Placeholder)))
    infer_format = attr.ib(validator=attr.validators.instance_of((str, Placeholder, type(None))))
    template_inputs = attr.ib(validator=attr.validators.instance_of((list, TemplateInputs)))

    def __attrs_post_init__(self):
        if self.template_inputs and not isinstance(self.template_inputs, list):
            self.template_inputs = [self.template_inputs]


@serialize
@attr.s
class ModelConfig(AbstractOutputConfig):
    """Config of model

    Attributes:
        model_name (Union[str, Placeholder]):  If model_name is not passed in, it will be automatically generated.
        If model_name is not passed in, it will be automatically generated.
        model_version (str, Placeholder): The version of the model. Support self-increment.
        model_type (str, Placeholder): The type of the model
        runtime (Union[str, Placeholder]): Supported Operating Environments
        source_location (str): The location of the source. It is mutually exclusive with source_job_id.
        source_job_id (str): The source training job id of the model. It is mutually exclusive with source_location.
        model_id (str): The id of the model
        source_type (str): The type of model source
        description (str): The description of the model
        execution_code (Union[str, Placeholder, Storage]): The OBS address where the execution code is stored
        input_params (list[Params]): The input parameter set of the model
        output_params (list[Params]): The output parameter set of the model
        dependencies (list[Dependencies]): Inference code and model packages to be installed
        model_metrics (str): Model accuracy information
        apis (str): All apis input and output parameters of the model
        initial_config (dict): Model configuration file
        template (Template): The related configuration items of the template
        arch (Union[str, Placeholder]): System operating structure
        dynamic_load_mode (Union[str, Placeholder]): When enabled, model files and runtime dependencies are only pulled
                                                    during actual deployment, not during import
        prebuild (Union[bool, Placeholder]): Indicates whether the model is prebuild
        install_type (list): Model install type, only support real-time, edge, batch
    """

    model_type = attr.ib(default="TensorFlow", validator=_verify_model_type)
    model_name = attr.ib(default=None, validator=validators.instance_of((str, Placeholder, type(None))))
    model_version = attr.ib(default=None, validator=validators.instance_of((str, Placeholder, type(None))))
    runtime = attr.ib(default=None, validator=validators.instance_of((str, Placeholder, type(None))))
    source_location = attr.ib(default=None)
    source_job_id = attr.ib(default=None, validator=validators.instance_of((str, type(None))))
    source_type = attr.ib(default=None, validator=validators.instance_of((str, type(None))))
    description = attr.ib(default=None, validator=validators.instance_of((str, type(None))))
    execution_code = attr.ib(default=None, validator=validators.instance_of((str, Placeholder, Storage, type(None))))
    input_params = attr.ib(default=None, validator=validators.instance_of((list, type(None))))
    output_params = attr.ib(default=None, validator=validators.instance_of((list, type(None))))
    dependencies = attr.ib(default=None, validator=validators.instance_of((list, type(None))))
    model_metrics = attr.ib(default=None, validator=validators.instance_of((str, type(None))))
    apis = attr.ib(default=None, validator=validators.instance_of((str, type(None))))
    initial_config = attr.ib(default=None, validator=validators.instance_of((dict, type(None))))
    template = attr.ib(default=None, validator=validators.instance_of((Template, type(None))))
    arch = attr.ib(default=None, validator=validators.instance_of((str, Placeholder, type(None))))
    dynamic_load_mode = attr.ib(default=None, validator=validators.instance_of((str, Placeholder, type(None))))
    prebuild = attr.ib(default=None, validator=validators.instance_of((bool, Placeholder, type(None))))
    install_type = attr.ib(default=None, validator=_verify_model_install_type)
    _model = attr.ib(default=None, validator=validators.instance_of((ModelData, type(None))))

    def __attrs_post_init__(self):
        if self.initial_config:
            self.initial_config = json.dumps(self.initial_config)

    def _set_model(self, model):
        self._model = model

    @property
    def model(self):
        return self._model

    def data_consumption(self, step_name, output_name):
        return _ModelConsumption(self, step_name, output_name)


class _ModelConsumption(AbstractDataConsumption):

    def __init__(self, config: ModelConfig, step_name: str, output_name: str):
        super(_ModelConsumption, self).__init__(config, step_name, output_name)

    def consume(self) -> AbstractData:
        return self.config.model

    def type(self):
        return MODEL_DATA_TYPE


class ModelInput(CommonInput):
    def __init__(self, name, data):
        """

        Args:
            name (str): the name of the ModelInput
            data (Union[OBSPath, SWRImage, OBSConsumption, OBSPlaceholder, SWRImagePlaceholder,
                    DataConsumptionSelector, GalleryModel]): The metamodel source
            currently supports selection from the an OBS path or from a container image
        """
        self._check_input_data(data=data)
        super(ModelInput, self).__init__(name, data)

    def to_request(self):
        # Creating model from an OBS path
        if isinstance(self.data, OBSPath):
            if self.data.obs_path and isinstance(self.data.obs_path, str):
                return {"source_location": self.data.obs_path}
            raise ValueError("The obs_path of data of model_input must be type of str and can not be empty")
        # Creating model from a container image
        if isinstance(self.data, SWRImage):
            if self.data.swr_path and isinstance(self.data.swr_path, str):
                return {"source_location": self.data.swr_path}
            raise ValueError("The swr_path of data of model_input must be type of str and can not be empty")

    @staticmethod
    def _check_input_data(data):
        data_type_tuple = (OBSPath, SWRImage, OBSConsumption, OBSPlaceholder, SWRImagePlaceholder,
                           DataConsumptionSelector, GalleryModel)
        if not isinstance(data, data_type_tuple):
            raise TypeError('The data type of ModelInput must be one of the {}. But provided: {}'.format(
                data_type_tuple, type(data)))


class ModelOutput(AbstractOutput):

    def __init__(
            self,
            name=None,
            model_config: ModelConfig = None):
        """

        Args:
            name (str): the name of the ModelOutput
            model_config (ModelConfig): Model configuration, which defines the model name, model version, model type,
            etc.
        """
        self._check_output_config(config=model_config)
        super(ModelOutput, self).__init__(name)
        self.config = model_config

    def as_input(self):
        return self.config.data_consumption(self.step_name, self.name)

    def to_request(self):
        return self.config.serialize()

    def set_data_to_config(self, model):
        self.config._set_model(model)

    def to_definition_json(self) -> TransformType:
        return {
            "name": self.name,
            "type": "model"
        }

    @staticmethod
    def _check_output_config(config):
        if not isinstance(config, ModelConfig):
            raise TypeError('The model_config type of ModelOutput must be ModelConfig. But provided: {}'.format(
                type(config)))

    def set_to_skip(self):
        self.config.is_skipped = True


class ModelStep(Step):
    """Model step for workflow."""

    def __init__(
        self,
        name,
        outputs,
        inputs=None,
        title=None,
        description=None,
        policy=None,
        depend_steps=None,
    ):
        """
            Constructs a ModelStep to create model
            There are three ways to use it:
            1. Select from an OBS path(generally obtained from the output of the JobStep)
            2. Select from a container image
            3. Select from a template

        Args:
            name (str): The name of the Model step.
            inputs (Union(ModelInput, List[ModelInput])): A or a list of `ModelInput` instance. The inputs of
            ModelStep can only be a single input.
            outputs (Union(ModelOutput, List[ModelOutput])): A or a list of `ModelOutput` instance. The outputs of
            ModelStep can only be a single output.
            title (str): The title message of ModelStep.
            description (str): Description info of ModelStep
            policy (StepPolicy): Step execution policy
            depend_steps (Union(Step, List[Step])): A or a list of step which this `ModelStep` depends on.
        """

        if outputs and not isinstance(outputs, list):
            outputs = [outputs]
        super(ModelStep, self).__init__(
            name=name,
            step_type=StepTypeEnum.MODEL,
            title=title,
            description=description,
            inputs=inputs,
            outputs=outputs,
            properties=prepare_for_properties(outputs[0].config),
            policy=policy,
            depend_steps=depend_steps
        )
        self._check_init()

    def build_client(self, session):
        super(ModelStep, self).build_client(session)
        self.client = ModelPredictorClient(session)

    def create_instance(self):
        self._check_client()
        create_model_body = self._to_request()
        logging.debug("The ModelStep %s is creating model with request body: %s", self.name, create_model_body)
        model_id = self.client.create_modelarts_model(create_model_body)
        logging.info("step(%s) successfully creates an instance. instance id: %s, model name: %s", self.name, model_id,
                     create_model_body.get("model_name"))
        return True, model_id

    def update_instance_state(self):
        if self.instance_id is None:
            raise ValueError("No instance of ModelStep {}".format(self.name))
        self._check_client()
        logging.debug("The ModelStep %s is updating the state, and current state is %s", self.name, self.state)
        model_state = self.client.get_model_state(self.instance_id)
        model_name = self.client.get_model_name(self.instance_id)
        step_state = StepStateMapping.get_step_state(str(model_state), MODEL_STATE_MAPPING)
        self.set_state(step_state)
        if step_state == StepState.Completed:
            self._set_data_to_output(model_name)

    def stop_instance(self) -> (bool, str):
        return True, "success"

    def _check_init(self):
        for value in self.inputs.values():
            if not isinstance(value, ModelInput):
                raise TypeError("The type of ModelStep input must be ModelInput")
        for value in self.outputs.values():
            if not isinstance(value, ModelOutput):
                raise TypeError("The type of ModelStep output must be ModelOutput")
        if len(self.inputs) == 2:
            obs_type = (OBSPath, OBSConsumption, OBSPlaceholder)
            swr_type = (SWRImage, SWRImagePlaceholder, GalleryModel)
            inputs_list = list(self.inputs.values())
            data_first = inputs_list[0].declared_data
            data_second = inputs_list[1].declared_data
            if not ((isinstance(data_first, obs_type) and isinstance(data_second, swr_type)) or
                    (isinstance(data_first, swr_type) and isinstance(data_second, obs_type))):
                raise TypeError("The input data must be one OBS relevant and the other swr relevant")

    def _to_request(self):
        request = list(self.outputs.values())[0].to_request()
        if len(self.inputs) == 1:
            request.update(list(self.inputs.values())[0].to_request())
        if len(self.inputs) == 2:
            for model_input in self.inputs.values():
                if isinstance(model_input.data, OBSPath):
                    request.update(model_input.to_request())
                else:
                    request["runtime"] = model_input.data.swr_path
        self._verify_request(request)
        self._set_default_params(request)
        return request

    def _set_data_to_output(self, model_name):
        if self.instance_id is None:
            raise ValueError("No instance of ModelStep {}".format(self.name))
        output = list(self.outputs.values())[0]
        model_data = ModelData(name=model_name, model_id=self.instance_id)
        output.set_data_to_config(model_data)

    def _verify_request(self, request_dict):
        self._check_client()
        source_location = request_dict.get("source_location", None)
        # if source_location is empty, use template import model
        if not source_location:
            self._verify_template(request_dict)
        else:
            self._verify_obs_and_swr(request_dict, source_location)

    def _verify_template(self, request_dict):
        if not request_dict.get("template", None) or request_dict.get("model_type", None) != "Template":
            raise ValueError("When use template import model, the model type must be Template and "
                             "request body must have the template configuration")

    def _verify_obs_and_swr(self, request_dict, source_location):
        # if source_location is an OBS path
        if not source_location.startswith("swr."):
            request_dict["source_location"] = get_obs_url(self.client.session.region_name, source_location)
        else:
            if source_location.find(".com") > -1:
                if request_dict.get("model_type") != "Image":
                    raise ValueError("When source_location is a SWR image path, the model type must be Image")
            else:
                raise ValueError("the SWR image path must be start with swr.{}.***.com".format(
                    self.client.session.region_name))
        if request_dict.get("execution_code"):
            request_dict["execution_code"] = \
                get_obs_url(self.client.session.region_name, request_dict.get("execution_code"))

    def _set_default_params(self, request_dict):
        request_dict["model_name"] = request_dict.get("model_name", get_random_name("model-"))
        # Model version self-increasing
        self._set_model_version(request_dict)

    def _set_model_version(self, request_dict):
        self._check_client()
        model_name = request_dict["model_name"]
        resp = self.client.get_model_list(model_name=model_name)
        # if the count of model with model_name is equal to 0
        if resp.get("count") == 0:
            request_dict["model_version"] = "0.0.1"
        # else the count of model with model_name is not equal to 0
        else:
            # the version list with the same model_name
            version_list = [item_dict.get("model_version") for item_dict in resp.get("models")
                            if item_dict.get("model_name") == model_name]
            request_dict["model_version"] = get_next_version_name(version_list)

    def _check_client(self):
        if self.client is None:
            raise ValueError("The client of ModelStep {} is None, "
                             "please use the <build_client> method to initialize the client".format(self.name))
