import logging
from typing import List
from modelarts.workflow.core.entities import TransformType
from modelarts.workflow.core.serialize import prepare_for_properties
from modelarts.workflow.core.steps import Step, AbstractOutput, StepTypeEnum
from modelarts.workflow.core.state import StepState
from modelarts.workflow.core.placeholder import Placeholder
from modelarts.workflow.data.obs import OBSPath, OBSConsumption, OBSOutputConfig, OBSPlaceholder
from modelarts.workflow.steps.common_input import CommonInput
from modelarts.workflow.steps.step_state_mapping import StepStateMapping
from modelarts.workflow.client.mrs_client import MrsClient
from modelarts.workflow.steps.job_step import BaseAlgorithm
from modelarts.workflow.util.utils import get_random_name
from modelarts.workflow.data.storage import Storage
from modelarts.workflow.data.data_selector import DataConsumptionSelector


MRS_STATE_MAPPING = {
    "NEW": StepState.Running,
    "NEW_SAVING": StepState.Running,
    "SUBMITTED": StepState.Running,
    "ACCEPTED": StepState.Running,
    "RUNNING": StepState.Running,
    "FINISHED": StepState.Completed,
    "FAILED": StepState.Failed,
    "KILLED": StepState.Stopped
}

MRS_RESULT_MAPPING = {
    "FAILED": StepState.Failed,
    "KILLED": StepState.Stopped,
    "UNDEFINED": StepState.Failed,
    "SUCCEEDED": StepState.Completed
}


class MrsJobInput(CommonInput):

    def __init__(self, name, data):
        """
        The input of MrsJobStep
        Args:
            name (str): The name of input
            data (Union[OBSPath, OBSConsumption, OBSPlaceholder, DataConsumptionSelector]):
                    input data used by an training job
        """
        self._check_input_data(data=data)
        super(MrsJobInput, self).__init__(name, data)

    def to_request(self):
        """
        Get the request structure for workflow service calls
        Returns:
            name(str): name of MRS Job input
            obs_url(str): value of obs url
        """
        name = self.name
        if isinstance(self.data, OBSPath):
            obs_url = self.data.obs_path
        else:
            raise TypeError(
                'The Mrs Job Input data only support OBSPath. But provided: {}'.format(type(self.data)))
        return name, obs_url

    @staticmethod
    def _check_input_data(data):
        """
        Check the input data type, and throw an TypeError if the data type is wrong
        Args:
            data (object): input data from user
        Returns:
        """
        data_type_tuple = (OBSPath, OBSConsumption, OBSPlaceholder, DataConsumptionSelector)
        if not isinstance(data, data_type_tuple):
            raise TypeError('The data type of MrsJobInput must be one of the {}. But provided: {}'.format(
                data_type_tuple, type(data)))


class MrsJobOutput(AbstractOutput):
    def __init__(self, name, obs_config):
        """
        The output of MrsJobStep
        Args:
            name (str): The name of output
            obs_config (OBSOutputConfig): OBSOutputConfig with obs_path
        """
        self._check_output_config(config=obs_config)
        super().__init__(name)
        self.config = obs_config

    @staticmethod
    def _check_output_config(config):
        """
        Check the output config type, and throw an TypeError if the config type is wrong
        Args:
            config (object):  input data from user
        Returns:
        """
        if not isinstance(config, OBSOutputConfig):
            raise TypeError('The config type must be OBSOutputConfig. But provided: {}'.format(type(config)))

    def to_definition_json(self) -> TransformType:
        """
        Returns the serialization definition of MrsJobOutput
        Returns (TransformType): The serialization structure
        """
        result = {
            "name": self.name
        }
        if isinstance(self.config, OBSOutputConfig):
            result["type"] = "obs"
            result["config"] = self.config.to_definition_json()
        return result

    def to_request(self):
        """
        Get the request structure of JobOutput for workflow service calls
        Returns:
            name(str): name of MRS Job input
            obs_url(str): value of obs url
        """
        name = self.name
        if isinstance(self.config, OBSOutputConfig):
            if isinstance(self.config.obs_path, (Placeholder, Storage)):
                obs_url = self.config.obs_path.ref()
            else:
                obs_url = self.config.obs_path
        else:
            raise TypeError(
                'The config type must be OBSOutputConfig. But provided: {}'.format(type(self.config)))
        return name, obs_url

    def as_input(self):
        """
        Get the AbstractDataConsumption object, which is used for data transfer between multiple Steps
        Returns (AbstractDataConsumption):
        """
        return self.config.data_consumption(self.step_name, self.name)

    def set_to_skip(self):
        self.config.is_skipped = True


class MrsJobAlgorithm(BaseAlgorithm):
    """
    Algorithm from algorithm management
    """
    def __init__(self, boot_file, parameters):
        """
        Args:
            boot_file (Union[str, Placeholder]): The boot file of algorithm
            parameters(List[AlgorithmParameters]): parameters of algorithm;
            "run_args"， run argument of program
            "app_args", argument for script
            "properties", properties of MRS job

        Example:
            run_args = "--master,yarn-cluster"
            app_args = "--pram_a=3,--param_b=4"
            properties = "{"fs.obs.access.key":"xxx","fs.obs.secret.key":"yyy"}"
        """
        super(MrsJobAlgorithm, self).__init__(boot_file=boot_file, parameters=parameters)
        self._check_parameters_names()

    def _check_parameters_names(self):
        parameters_names = ("run_args", "app_args", "properties")
        parameters = self.parameters
        if parameters is None:
            return

        new_list = []
        for parameter in parameters:
            if parameter not in new_list:
                new_list.append(parameter)
        if len(new_list) != len(parameters):
            raise ValueError('The AlgorithmParameter can not duplicate')

        for parameter in parameters:
            if parameter.name not in parameters_names:
                raise ValueError('The AlgorithmParameter name must be in {}, '
                                 'but you provided {}'.format(parameters_names, parameter.name))
            if parameter.name == "properties" and parameter.value != "":
                if not isinstance(eval(parameter.value), dict):
                    raise ValueError(
                        "The type of properties must str of dict, but you provide {}".format(eval(parameter.value)))


class MrsJobStep(Step):

    def __init__(
        self,
        name,
        inputs,
        outputs,
        mrs_algorithm,
        cluster_id,
        title=None,
        description=None,
        policy=None,
        depend_steps=None
    ):
        """
        Construct a MrsJobStep to create job
        Args:
            name (str): The name of MrsJobStep
            inputs (Union(MrsJobInput, List[MrsJobInput])): A or a list of `MrsJobInput` instance.
            outputs (Union(MrsJobOutput, List[MrsJobOutput])): A or a list of `MrsJobOutput` instance.
            mrs_algorithm (MrsJobAlgorithm): The MrsJobAlgorithm
            title (str): The title of the job, which is equal to name by default
            description (str): Description info of MrsJobStep
            policy (StepPolicy): Step execution policy
            depend_steps (Union(Step, List[Step])): A or a list of step which this `MrsJobStep` depends on
        """

        MrsJobStep._checkout_init_info(mrs_algorithm)
        super().__init__(
             name=name,
             step_type=StepTypeEnum.MRSJOB,
             title=title,
             description=description,
             properties=MrsJobStep._prepare_properties(algorithm=mrs_algorithm, cluster_id=cluster_id),
             inputs=inputs,
             outputs=outputs,
             policy=policy,
             depend_steps=depend_steps
        )
        self.cluster_id = cluster_id
        self.mrs_algorithm = mrs_algorithm

    @staticmethod
    def _checkout_init_info(mrs_algorithm):
        if not isinstance(mrs_algorithm, MrsJobAlgorithm):
            raise TypeError('The mrs_algorithm type must be Algorithm. But provided: {}'.format(type(mrs_algorithm)))
        if not isinstance(mrs_algorithm.parameters, List):
            raise ValueError("The parameters is not instance of List")

    def build_client(self, session):
        """
        Build a client for MrsJobStep service calls
        Args:
            session (Session): building interactions with cloud MRS service.
        Returns:
        """
        super(MrsJobStep, self).build_client(session)
        self.client = MrsClient(session=session)

    def create_instance(self) -> (bool, str):
        self._check_client()
        request_body = self._to_request
        logging.debug("The MrsJobStep %s is creating job with request body: %s", self.name, request_body)
        job_id = self.client.create_job(cluster_id=self.cluster_id, create_job_body=request_body)
        return True, job_id

    def update_instance_state(self):
        if self.instance_id is None:
            raise ValueError('No instance of MrsJobStep {}'.format(self.name))
        self._check_client()
        logging.debug(
            "The MrsJobStep <step_name:%s, instance_id:%s> is updating the state, and current state is %s",
            self.name, self.instance_id, self.state)
        job_state, job_result = self.client.get_job_state(cluster_id=self.cluster_id, job_id=self.instance_id)
        step_state = StepStateMapping.get_step_state(instance_state=job_state, mapping_dic=MRS_STATE_MAPPING)
        if step_state == StepState.Completed:
            step_state = StepStateMapping.get_step_state(instance_state=job_result, mapping_dic=MRS_RESULT_MAPPING)
        self.set_state(step_state)

    def stop_instance(self) -> (bool, str):
        if self.instance_id is None:
            raise ValueError('No instance of JobStep {}'.format(self.name))
        if self.state not in (StepState.Creating, StepState.Pending, StepState.Running):
            raise TypeError('can not stop the state {}'.format(self.state))
        self._check_client()
        logging.debug(
            "The MrsJobStep <step_name:%s, instance_id:%s> is stopping the instance, and current state is %s",
            self.name, self.instance_id, self.state)
        job_state = self.client.stop_job(cluster_id=self.cluster_id, job_id=self.instance_id)
        step_state = StepStateMapping.get_step_state(instance_state=job_state, mapping_dic=MRS_STATE_MAPPING)
        self.set_state(step_state)
        return True, "success"

    @property
    def _to_request(self):
        """
        Convert into the json body required by the mrs interface
        Args:
        Returns: json of request body
        """

        request = {
            "job_name": get_random_name(prefix="workflow_mrs_", len_random=50),
            "job_type": "SparkSubmit",
        }

        boot_file = self.mrs_algorithm.boot_file
        parameters = self.mrs_algorithm.parameters

        run_args = ""
        app_args = ""
        properties = ""
        for parameter in parameters:
            if parameter.name == "run_args":
                run_args = parameter.value
            elif parameter.name == "app_args":
                app_args = parameter.value
            elif parameter.name == "properties":
                properties = parameter.value

        app_args = self._build_app_arg_arguments(app_args)
        arguments = run_args.split(',')
        arguments.append(boot_file)
        arguments.extend(app_args)
        request["arguments"] = arguments
        if properties != "":
            request["properties"] = eval(properties)

        return request

    def _build_app_arg_arguments(self, app_args):
        """

        Args:
            app_args(str): arguments of app

        Returns:
            app_args_arr(List(str)): list of app_args
        """
        if app_args != "":
            app_args_arr = app_args.split(',')
        else:
            app_args_arr = []

        for mrs_input in self.inputs.values():
            name, obs_url = mrs_input.to_request()
            app_args_arr.append('--' + name + '=' + 'obs:/' + obs_url)

        for mrs_output in self.outputs.values():
            name, obs_url = mrs_output.to_request()
            app_args_arr.append('--' + name + '=' + 'obs:/' + obs_url)

        return app_args_arr

    def _serialize_inputs(self):
        return [job_input.to_request() for job_input in self.inputs.values()]

    def _serialize_outputs(self):
        return [job_output.to_request() for job_output in self.outputs.values()]

    @staticmethod
    def _prepare_properties(algorithm, cluster_id):
        return {
            "cluster_id": cluster_id,
            "algorithm": prepare_for_properties(algorithm),
        }

    def _check_client(self):
        if self.client is None:
            raise ValueError("The client of MrsJobStep {} is None, "
                             "please use the <build_client> method to initialize the client".format(self.name))
