import logging

from modelarts.workflow.core.steps import Step, StepTypeEnum, StepState, AbstractOutput
from modelarts.workflow.steps.common_input import CommonInput
from modelarts.workflow.data.dataset import Dataset, DatasetPlaceholder, DatasetConsumption, DatasetClient
from modelarts.workflow.data.dataset import DatasetVersionConfig
from modelarts.workflow.core.serialize import prepare_for_properties
from modelarts.workflow.steps.step_state_mapping import StepStateMapping
from modelarts.workflow.data.label_task import LabelTask, LabelTaskPlaceholder, LabelTaskConsumption
from modelarts.workflow.data.data_selector import DataConsumptionSelector


DATASET_VERSION_STATE_MAPPING = {
    # 0: dataset version is publishing
    "0": StepState.Running,
    # 1: dataset version is published
    "1": StepState.Completed,
    # 2: dataset version is deleting
    "2": StepState.Running,
    # 3: dataset version is deleted
    "3": StepState.Failed,
    # 4: dataset version is abnormal
    "4": StepState.Failed
}


class ReleaseDatasetInput(CommonInput):

    def __init__(self, name, data):
        """
        The input of ReleaseDatasetStep
        Args:
            name (str): The name of ReleaseDatasetInput
            data (Union[Dataset, DatasetConsumption, DatasetPlaceholder, LabelTask, LabelTaskPlaceholder,
                LabelTaskConsumption, DataConsumptionSelector]): The input data type must be related to dataset
        """
        self._check_data(data)
        super(ReleaseDatasetInput, self).__init__(name=name, data=data)

    @staticmethod
    def _check_data(data):
        data_type_tuple = (Dataset, DatasetConsumption, DatasetPlaceholder, LabelTask, LabelTaskPlaceholder,
                           LabelTaskConsumption, DataConsumptionSelector)
        if not isinstance(data, data_type_tuple):
            raise TypeError('The data type of ReleaseDatasetInput must be one of the {}. But provided: {}'.format(
                data_type_tuple, type(data)))


class ReleaseDatasetOutput(AbstractOutput):
    def __init__(self, name, dataset_version_config=None):
        """
        The output of ReleaseDatasetStep
        Args:
            name (str): The name of ReleaseDatasetOutput
            dataset_version_config (DatasetVersionConfig): configuration related to dataset version info
        """
        dataset_version_config = DatasetVersionConfig() if dataset_version_config is None else dataset_version_config
        self._check_output_config(config=dataset_version_config)
        super().__init__(name)
        self.config = dataset_version_config

    def as_input(self):
        """
        Get the AbstractDataConsumption object, which is used for data transfer between multiple Steps
        Returns (AbstractDataConsumption):

        """
        return self.config.data_consumption(step_name=self.step_name, output_name=self.name)

    def set_data_to_config(self, data):
        """
        Set the dataset to the output config
        Args:
            data (Dataset): A new dataset constructed based on the version information released by the input dataset

        Returns:

        """
        self.config.set_dataset(data)

    def to_definition_json(self):
        result = {
            "name": self.name,
            "type": "dataset"
        }
        return result

    @classmethod
    def _check_output_config(cls, config):
        if not isinstance(config, DatasetVersionConfig):
            raise TypeError('The config of ReleaseDatasetOutput must be DatasetVersionConfig. But provided: {}'.format(
                type(config)))

    def set_to_skip(self):
        self.config.is_skipped = True


class ReleaseDatasetStep(Step):
    def __init__(
        self,
        name,
        inputs,
        outputs,
        title=None,
        description=None,
        policy=None,
        depend_steps=None
    ):
        """
        Construct a ReleaseDatasetStep for dataset ReleaseDataset
        Args:
            name (str): The name of step
            inputs (ReleaseDatasetInput): A ReleaseDatasetInput instance
            outputs (ReleaseDatasetOutput): output of step
            title (str): title info of ReleaseDatasetStep
            description (str): Description info of ReleaseDatasetStep
            policy (StepPolicy): Step execution policy
            depend_steps (Union[Step, List[Step]]): A or a list of step which this `ReleaseDatasetStep` depends on
        """
        ReleaseDatasetStep._check_inputs_and_outputs(inputs=inputs, outputs=outputs)
        properties = ReleaseDatasetStep._prepare_properties(output_config=outputs.config)
        super(ReleaseDatasetStep, self).__init__(
            name=name,
            step_type=StepTypeEnum.RELEASE_DATASET,
            properties=properties,
            inputs=inputs,
            outputs=outputs,
            title=title,
            description=description,
            policy=policy,
            depend_steps=depend_steps
        )
        self._version_id = None
        self._dataset_name = None

    def build_client(self, session):
        super(ReleaseDatasetStep, self).build_client(session)
        self.client = DatasetClient(session=session)

    def create_instance(self) -> (bool, str):
        data = list(self.inputs.values())[0].data
        if isinstance(data, Dataset):
            logging.info("The dataset %s is being released version", data.dataset_name)
            self._version_id = self.client.release_dataset_version(data.id, list(self.outputs.values())[0].config)
            self._dataset_name = data.dataset_name
            return True, data.id
        else:
            logging.info("The label task %s of dataset %s is being released version",
                         data.task_name, data.dataset_name)
            self._version_id = self._release_label_task(data.dataset_id, data.task_id)
            self._dataset_name = data.dataset_name
            return True, data.dataset_id

    def update_instance_state(self):
        version_state = self.client.get_version_state(dataset_id=self.instance_id, version_id=self._version_id)
        step_state = StepStateMapping.get_step_state(str(version_state), DATASET_VERSION_STATE_MAPPING)
        if step_state == StepState.Completed:
            self._set_data_to_output()
        self.set_state(step_state)

    def stop_instance(self) -> (bool, str):
        return True, "success"

    def _release_label_task(self, dataset_id, task_id):
        publish_dataset_output = list(self.outputs.values())[0]
        dataset_version_config = publish_dataset_output.config
        dataset_version_config.label_task_id = task_id
        return self.client.release_dataset_version(
            dataset_id=dataset_id,
            dataset_version_config=dataset_version_config
        )

    @staticmethod
    def _check_inputs_and_outputs(inputs, outputs):
        if not isinstance(inputs, ReleaseDatasetInput):
            raise TypeError(
                'The input of ReleaseDatasetStep must be ReleaseDatasetInput. But provided: {}'.format(type(inputs)))
        if not isinstance(outputs, ReleaseDatasetOutput):
            raise TypeError(
                'The output of ReleaseDatasetStep must be ReleaseDatasetOutput. But provided: {}'.format(type(outputs)))
        tuple_dataset = (Dataset, DatasetConsumption, DatasetPlaceholder)
        dataset_version_config = outputs.config
        if isinstance(inputs.declared_data, tuple_dataset) and dataset_version_config.label_task_type is None:
            raise ValueError('When ReleaseDatasetStep releases a dataset version, '
                             'the label_task_type of dataset_version_config cannot be None')

    @staticmethod
    def _prepare_properties(output_config):
        if output_config is not None:
            return prepare_for_properties(output_config)
        return {}

    def _set_data_to_output(self):
        if self.instance_id is None:
            raise ValueError('No instance of ReleaseDatasetStep {}'.format(self.name))
        version_name = self.client.get_version_name(dataset_id=self.instance_id, version_id=self._version_id)
        dataset = Dataset(dataset_name=self._dataset_name, version_name=version_name)
        dataset.id = self.instance_id
        dataset.version_id = self._version_id
        output = list(self.outputs.values())[0]
        output.set_data_to_config(dataset)
