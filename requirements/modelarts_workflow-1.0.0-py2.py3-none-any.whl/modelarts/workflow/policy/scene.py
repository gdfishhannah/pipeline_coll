from typing import Sequence

from modelarts.workflow.core.entities import TransformType


class Scene(object):

    def __init__(self, scene_name, scene_steps=None):
        if scene_steps is None:
            scene_steps = []
        self.scene_name = scene_name
        self.scene_steps = scene_steps

    def get_step_name_list(self) -> Sequence[str]:
        step_names = []
        for step in self.scene_steps:
            step_names.append(step.name)
        return step_names

    def to_definition_json(self) -> TransformType:
        return {
            "name": self.scene_name,
            "steps": self.get_step_name_list(),
        }

    def check(self):
        if len(self.scene_steps) == 0:
            raise ValueError('The parameter scene_steps cannot be empty.')
        if len(self.scene_steps) != len(set(self.scene_steps)):
            raise ValueError('The parameter scene_steps must be unique.')
