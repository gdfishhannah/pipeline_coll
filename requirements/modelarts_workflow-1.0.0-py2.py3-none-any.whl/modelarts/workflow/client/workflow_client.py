from json import JSONEncoder

from modelarts import constant
from modelarts.config.auth import auth_by_apig
from modelarts.util.secret_util import auth_expired_handler
from modelarts.workflow.resource.workspace import Workspace

HTTPS_POST = constant.HTTPS_POST
HTTPS_GET = constant.HTTPS_GET
HTTPS_PUT = constant.HTTPS_PUT


class _WorkflowApiAKSKImpl:
    def __init__(self, session):
        """
        Initialize a ModelArts workflow instance when using AKSK auth.
        Args:
            session (Session): building interactions with cloud service.
        """
        self.session = session

    @auth_expired_handler
    def release_workflow(self, request_body):
        """
        Create a workflow instance according to the request_body
        Args:
            request_body (dict): The request body

        Returns (dict): The workflow instance info

        """
        request_url = "/v2/{project_id}/workflows".format(
            project_id=self.session.project_id)
        body_encode = JSONEncoder().encode(request_body)
        return auth_by_apig(
            self.session, HTTPS_POST, request_url, body=body_encode)

    @auth_expired_handler
    def run_workflow(self, workflow_id, request_body=None):
        """
        run the specified workflow
        Args:
            workflow_id (str): workflow id
            request_body (dict): The request body

        Returns (dict): the workflow execution instance info

        """
        request_url = "/v2/{project_id}/workflows/{workflow_id}/executions".format(
            project_id=self.session.project_id, workflow_id=workflow_id)
        body_encode = JSONEncoder().encode(request_body) if request_body else {}
        return auth_by_apig(
            self.session, HTTPS_POST, request_url, body=body_encode)

    @auth_expired_handler
    def update_workflow(self, workflow_id, request_body):
        """
        update the specified workflow
        Args:
            workflow_id (str): workflow id
            request_body (dict): The request body

        Returns (dict): the workflow execution instance info

        """
        request_url = "/v2/{project_id}/workflows/{workflow_id}".format(
            project_id=self.session.project_id, workflow_id=workflow_id)
        body_encode = JSONEncoder().encode(request_body)
        return auth_by_apig(
            self.session, HTTPS_PUT, request_url, body=body_encode)

    @auth_expired_handler
    def get_workflow(self, workflow_name, search_type="equal"):
        """
        get workflow infos
        Args:
        workflow_name(str): the workflow name
        search_type (str): Available values,contain or equal
        Returns (dict): the list of workflow info

        """
        request_url = "/v2/{project_id}/workflows".format(project_id=self.session.project_id)
        query_args = {
            "workspace_id": Workspace.instance().workspace_id,
            "name": workflow_name,
            "search_type": search_type
        }
        resp = auth_by_apig(self.session, HTTPS_GET, request_url, query_args)
        if not resp:
            raise Exception("the response has no content")
        return resp


class WorkflowClient:

    def __init__(self, session):
        """
        Class for Client which makes ModelArts workflow service calls.
        Args:
            session (Session): building interactions with cloud service.
        """
        if session.auth == constant.AKSK_AUTH:
            self._workflow_impl = _WorkflowApiAKSKImpl(session)
        else:
            raise ValueError('Only support aksk authorization')

    def release_workflow(self, body):
        """
        Create a workflow instance according to the body
        Args:
            body (dict): The request body

        Returns (str): The workflow instance ID

        """
        body["workspace_id"] = Workspace.instance().workspace_id
        resp = self._workflow_impl.release_workflow(request_body=body)
        workflow_id = resp.get("workflow_id")
        if workflow_id is None:
            raise KeyError("The response has no workflow_id field")
        return workflow_id

    def update_workflow(self, workflow_id, body):
        """
        update the specified workflow according to the body
        Args:
            workflow_id(str): The workflow ID
            body (dict): The request body

        Returns (str): The workflow instance ID

        """
        body["workspace_id"] = Workspace.instance().workspace_id
        resp = self._workflow_impl.update_workflow(workflow_id, request_body=body)
        workflow_id = resp.get("workflow_id")
        if workflow_id is None:
            raise KeyError("The response has no workflow_id field")
        return workflow_id

    def run_workflow(self, workflow_id, request_body=None):
        """
        run the specified workflow
        Args:
            workflow_id (str): workflow id
            request_body (dict): The request body

        Returns (dict): the workflow execution instance ID

        """
        resp = self._workflow_impl.run_workflow(workflow_id=workflow_id, request_body=request_body)
        execution_id = resp.get("execution_id")
        if execution_id is None:
            raise KeyError("The response has no execution_id field")
        return execution_id

    @auth_expired_handler
    def get_workflow_id(self, workflow_name):
        """
        Gets the workflow ID through the workflow name.

        Args:

        Returns (dict): the workflow id; if not found, return None

        """
        resp = self._workflow_impl.get_workflow(workflow_name)
        items = resp.get("items")
        if items:
            return items[0].get("workflow_id", None)
        return None
