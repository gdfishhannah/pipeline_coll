from json import JSONEncoder

from modelarts import constant
from modelarts.config.auth import auth_by_apig
from modelarts.util.secret_util import auth_expired_handler

HTTPS_GET = constant.HTTPS_GET
HTTPS_POST = constant.HTTPS_POST
HTTPS_DELETE = constant.HTTPS_DELETE
HTTPS_PUT = constant.HTTPS_PUT


class _AlgorithmApiAKSKImpl:
    def __init__(self, session):
        """
        Initialize a ModelArts Algorithm instance when using AKSK auth.
        Args:
            session (Session): building interactions with cloud service.
        """
        self.session = session

    @auth_expired_handler
    def create_algorithm(self, create_algorithm_body):
        """
        Create algorithm.
        Args:
            create_algorithm_body (dict): the body of create algorithm

        Returns (dict): The algorithm info
        """

        request_url = "/v2/{project_id}/algorithms".format(project_id=self.session.project_id)
        body_encode = JSONEncoder().encode(create_algorithm_body)
        return auth_by_apig(
            self.session, HTTPS_POST, request_url, body=body_encode)

    @auth_expired_handler
    def publish_algorithm(self, algorithm_id, content_id, version_num):
        """
        Publish the algorithm to the AI gallery.
        Args:
            algorithm_id (str): The algorithm ID
            content_id (str): The content ID of AI Gallery
            version_num (str): The version num of content

        Returns (dict): The algorithm info of AI Gallery
        """
        request_url = "/v2/{project_id}/gallery-algorithm-publication".format(project_id=self.session.project_id)
        body = {
            "content_id": content_id,
            "content_info": {
                "version_num": version_num,
                "desc": ""
            },
            "algorithm": {
                "id": algorithm_id
            }
        }
        body_encode = JSONEncoder().encode(body)
        return auth_by_apig(
            self.session, HTTPS_POST, request_url, body=body_encode)

    @auth_expired_handler
    def algorithm_info(self, algorithm_id):
        """
        Get algorithm info according to algorithm ID
        Args:
            algorithm_id (str): The algorithm ID

        Returns (dict): The algorithm info

        """
        request_url = "/v2/{project_id}/algorithms/{algorithm_id}".format(
            project_id=self.session.project_id,
            algorithm_id=str(algorithm_id))
        return auth_by_apig(
            self.session, HTTPS_GET, request_url)

    @auth_expired_handler
    def gallery_algorithm_info(self, subscription_id, version_id):
        """
        Get algorithm info according subscription ID and version ID
        Args:
            subscription_id (str): The subscription ID of the subscription algorithm
            version_id (str): The version ID of the subscription algorithm

        Returns (dict): The subscription algorithm info

        """
        request_url = "/v2/{project_id}/gallery-algorithm-query".format(
            project_id=self.session.project_id)
        body = {
            "subscription_id": subscription_id,
            "version_id": version_id
        }
        body_encode = JSONEncoder().encode(body)
        return auth_by_apig(
            self.session, HTTPS_POST, request_url, body=body_encode)


class AlgorithmClient:

    def __init__(self, session):
        """
        Class for Client which makes ModelArts algorithm service calls.
        Args:
            session (Session): building interactions with cloud service.
        """
        if session.auth == constant.AKSK_AUTH:
            self._algorithm = _AlgorithmApiAKSKImpl(session)
        else:
            raise ValueError('Only support aksk authorization.')

    def create_algorithm(self, create_algorithm_body):
        """
        Create algorithm.
        Args:
            create_algorithm_body (dict):The body of create algorithm

        Returns (str):The algorithm_id of algorithm

        """
        if create_algorithm_body is None:
            raise ValueError("create algorithm body is empty")
        resp = self._algorithm.create_algorithm(create_algorithm_body)
        metadata = resp.get("metadata")
        if metadata is None:
            raise KeyError("the response of create algorithm has no metadata field")
        algorithm_id = metadata.get("id")
        if algorithm_id is None:
            raise KeyError("the metadata has no id field")
        return algorithm_id

    def publish_algorithm(self, algorithm_id, content_id, version_num):
        """
        Publish the algorithm to the AI gallery.
        Args:
            algorithm_id (str): The algorithm ID
            content_id (str): The content ID of AI Gallery
            version_num (str): The version num of content

        Returns (str): the version id of content
        """
        resp = self._algorithm.publish_algorithm(algorithm_id, content_id, version_num)
        version_id = resp.get("version_id")
        if version_id is None:
            raise KeyError("the response of release algorithm has no version_id field")
        return version_id

    def get_algorithm_info(self, algorithm_id):
        """
        Get algorithm info according to the algorithm_id
        Args:
            algorithm_id (str): The algorithm ID

        Returns (dict): The algorithm info

        """
        return self._algorithm.algorithm_info(algorithm_id)

    def get_gallery_algorithm_info(self, subscription_id, version_id):
        """
        Get subscription algorithm info according to the subscription_id and version_id
        Args:
            subscription_id (str): The subscription ID of the subscription algorithm
            version_id (str): The version ID of the subscription algorithm

        Returns (dict): The subscription algorithm info

        """
        return self._algorithm.gallery_algorithm_info(subscription_id=subscription_id, version_id=version_id)
