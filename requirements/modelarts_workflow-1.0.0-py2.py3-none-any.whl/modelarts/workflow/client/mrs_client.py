from json import JSONEncoder
import copy
from modelarts import constant

from modelarts.config.auth import auth_by_apig

from modelarts.util.secret_util import auth_expired_handler

HTTPS_GET = constant.HTTPS_GET
HTTPS_POST = constant.HTTPS_POST
HTTPS_DELETE = constant.HTTPS_DELETE
HTTPS_PUT = constant.HTTPS_PUT


_MRS = "mrs"


def _get_mrs_host(ma_host):
    """
    Get mrs host according to modelarts host
    Args:
        ma_host (str): modelarts host

    Returns (str): mrs host
    """
    arr = ma_host.split(".", 1)
    if len(arr) < 2:
        raise ValueError("ma host is abnormal: {}".format(ma_host))
    return _MRS + "." + arr[1]


class _MrsApiAKSKImpl:
    def __init__(self, session):
        """
        Initialize a Mrs client instance when using AKSK auth.
        Args:
            session (Session): building interactions with cloud MRS service.
        """
        self.session = copy.copy(session)
        self.session.host = _get_mrs_host(self.session.host)

    @auth_expired_handler
    def create_mrs_job(self, cluster_id, create_body):
        """
        Create a mrs job
        Args:
            cluster_id (str): The cluster id
            create_body (dict): The body of create mrs job
        Returns (dict): The job_id
        """

        request_url = "/v2/{project_id}/clusters/{cluster_id}/job-executions".format(
                                                 project_id=self.session.project_id, cluster_id=cluster_id)
        body_encode = JSONEncoder().encode(create_body)
        return auth_by_apig(self.session, HTTPS_POST, request_url=request_url, body=body_encode)

    @auth_expired_handler
    def get_job_info(self, cluster_id, job_id):
        """
        Get mrs job info
        Args:
            cluster_id (str): The cluster id
            job_id (str): The id of mrs job
        Returns (dict): The rspContent
        """
        request_url = "/v2/{project_id}/clusters/{cluster_id}/job-executions/{job_execution_id}".format(
            project_id=self.session.project_id,
            cluster_id=str(cluster_id),
            job_execution_id=str(job_id))
        return auth_by_apig(self.session, HTTPS_GET, request_url)

    @auth_expired_handler
    def stop_job(self, cluster_id, job_id):
        """
        Stop mrs job
        Args:
            cluster_id (str): The cluster id
            job_id (): The id of mrs job
        Returns (dict): The stop_rsp_content
        """
        request_url = "/v2/{project_id}/clusters/{cluster_id}/job-executions/{job_execution_id}/kill".format(
            project_id=self.session.project_id,
            cluster_id=str(cluster_id),
            job_execution_id=str(job_id))
        return auth_by_apig(self.session, HTTPS_POST, request_url)


class MrsClient:
    def __init__(self, session):
        """
        Class for Client which makes MRS Job service calls.
        Args:
            session (Session): building interactions with cloud MRS service.
        """
        self.mrs_client = _MrsApiAKSKImpl(session)

    def create_job(self, cluster_id, create_job_body):
        """
        Create Mrs Job.
        Args:
            create_job_body (dict):The body of create job
            cluster_id (str): The id of mrs cluster
        Returns (str):The id of job
        """
        if not create_job_body:
            raise ValueError("create_job_body is empty")
        resp = self.mrs_client.create_mrs_job(cluster_id, create_job_body)
        job_id = MrsClient._get_job_id(resp)
        return job_id

    def get_job_state(self, cluster_id, job_id):
        """
        Args:
            cluster_id(str): The is of cluster
            job_id(str): The id of job

        Returns:
            job_state(str): the state of job
            job_result(str): the result of job
        """
        job_info = self.mrs_client.get_job_info(cluster_id, job_id)
        job_state, job_result = MrsClient._get_job_state_from_job_info(job_info)
        return job_state, job_result

    def stop_job(self, cluster_id, job_id):
        """
        Stop the specified step
        Args:
            job_id (str): The job id
            cluster_id(str): The id of cluster
        Returns (str): The state of job

        """
        stop_resp = self.mrs_client.stop_job(cluster_id=cluster_id, job_id=job_id)
        if stop_resp is None:
            return "KILLED"
        return MrsClient._get_job_state_from_stop_job_resp(stop_resp)

    @staticmethod
    def _get_job_id(resp):
        """
        Get the job id from the response of create job request
        Args:
            resp (dict): The response of create job request

        Returns (str): The job id

        """
        job_submit_result = resp.get("job_submit_result")
        if job_submit_result is None:
            raise KeyError("the response of create job has no job_submit_result field")
        job_id = job_submit_result.get("job_id")
        if job_id is None:
            raise KeyError("the response of create job has no job_id field")
        return job_id

    @staticmethod
    def _get_job_state_from_job_info(job_info):
        """
        Get the job state from job info
        Args:
            job_info (dict): The job info

        Returns:
            job_state(str): the state of job
            job_result(str): the result of job

        """
        if job_info is None:
            raise KeyError("the response has no job_info field")
        job_detail = job_info.get("job_detail")
        if job_detail is None:
            raise KeyError("the response has no job_detail field")
        job_state = job_detail.get("job_state")
        if job_state is None:
            raise KeyError("the status has no job_state field")
        job_result = job_detail.get("job_result")
        if job_result is None:
            raise KeyError("the status has no job_result field")
        return job_state, job_result

    @staticmethod
    def _get_job_state_from_stop_job_resp(stop_resp):
        """
        Get the job state from job info
        Args:
            stop_resp (dict): The job stop response

        Returns (str): The job state

        """
        if stop_resp is None:
            raise KeyError("the response has no stop_resp field")
        job_detail = stop_resp.get("job_detail")
        if job_detail is None:
            raise KeyError("the response has no job_detail field")
        job_state = job_detail.get("job_state")
        if job_state is None:
            raise KeyError("the status has no job_state field")
        return job_state
