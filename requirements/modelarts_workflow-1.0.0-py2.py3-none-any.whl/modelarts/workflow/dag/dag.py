from collections import deque


class Dag(object):
    def __init__(self):
        self.graph = dict()
        self.reverse_graph = dict()

    def add_step(self, step_name, dep_step_names=None):
        """
        Add step to graph
        Args:
            step_name (str): step name
            dep_step_names (list[str]): depend step names list

        Returns:

        """
        if not step_name:
            return False, 'step name is empty or none'

        if not isinstance(step_name, str):
            return False, 'step name type is not str'

        if step_name in self.graph:
            return False, ('step (%s) already exists' % step_name)
        self.graph[step_name] = set()
        if step_name not in self.reverse_graph.keys():
            self.reverse_graph[step_name] = set()
        if dep_step_names:
            if not isinstance(dep_step_names, list):
                return False, 'depend steps type is not list'
            for dep_step_name in dep_step_names:
                if not dep_step_name:
                    return False, 'step (%s), depend step name exist empty or none' % step_name
                if not isinstance(dep_step_name, str):
                    return False, 'depend step name type is not str'
                if dep_step_name in self.graph[step_name]:
                    return False, ('depend steps duplicate:step (%s) depend step (%s)' % (step_name, dep_step_name))
                self.graph[step_name].add(dep_step_name)

                if dep_step_name not in self.reverse_graph.keys():
                    self.reverse_graph[dep_step_name] = set()
                self.reverse_graph[dep_step_name].add(step_name)
        return True, "success"

    def validate(self):
        """
        Validate graph
        Returns (Boolean, message): validate result and message

        """
        if len(self.graph) <= 0:
            return False, 'graph size is 0'

        step_in_degree = {}
        for step_name, depend_step_names in self.graph.items():
            for dep_name in depend_step_names:
                if dep_name not in self.graph.keys():
                    return False, ('depend name (%s) not in step names' % dep_name)
            step_in_degree[step_name] = len(depend_step_names) if depend_step_names else 0

        queue = deque()
        for u, v in step_in_degree.items():
            if v == 0:
                queue.append(u)

        zero_in_degree = []
        while queue:
            step_name = queue.pop()
            zero_in_degree.append(step_name)
            for next_step_name in self.get_next_step_names(step_name):
                step_in_degree[next_step_name] -= 1
                if step_in_degree[next_step_name] == 0:
                    queue.appendleft(next_step_name)

        if len(zero_in_degree) == len(self.graph):
            return True, 'valid'
        return False, 'graph is not acyclic'

    def reset_graph(self):
        self.graph = dict()
        self.reverse_graph = dict()

    def get_step_names(self):
        return self.graph.keys()

    def get_dep_step_names(self, step_name):
        if step_name not in self.graph.keys():
            raise KeyError("get depend step name failed. step_name {}".format(step_name))
        return self.graph.get(step_name)

    def get_next_step_names(self, step_name):
        if step_name not in self.reverse_graph.keys():
            raise KeyError("get next step name failed. step_name {}".format(step_name))
        return self.reverse_graph.get(step_name)
