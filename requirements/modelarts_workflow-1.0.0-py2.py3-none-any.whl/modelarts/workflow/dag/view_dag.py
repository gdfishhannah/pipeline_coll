import networkx as nx
from matplotlib import pyplot as plt


def _build_graph(workflow_dag):
    step_names = set(workflow_dag.get_step_names())
    # max length of step_names
    max_name_length = 0
    for step_name in step_names:
        max_name_length = max(max_name_length, len(step_name))
    # key is step_name, value is level
    step_name_levels = {step_name: 0 for step_name in step_names if not workflow_dag.get_dep_step_names(step_name)}

    curr_level_step_names = set(step_name_levels.keys())
    level = 1
    while True:
        next_level_step_names = set()
        for step_name in curr_level_step_names:
            next_level_step_names.update(workflow_dag.get_next_step_names(step_name))
        next_level_step_names = next_level_step_names & step_names
        if not next_level_step_names:
            break
        for step_name in next_level_step_names:
            step_name_levels[step_name] = level
        level += 1
        curr_level_step_names = next_level_step_names

    # The number of steps corresponding to each level
    level_cnt = [0] * level
    for step_name_level in step_name_levels.values():
        level_cnt[step_name_level] += 1
    max_per_level = max(level_cnt)

    level_cnt_curr = [0] * level
    pos_dict = {}
    G = nx.DiGraph()
    for step_name, step_name_level in step_name_levels.items():
        x = step_name_levels[step_name] * max_name_length
        level_cnt_curr[step_name_level] += 1
        y = level_cnt_curr[step_name_level] + (max_per_level - level_cnt[step_name_level]) * 0.5
        pos_dict[step_name] = (x, y)
        G.add_node(step_name)
        if not workflow_dag.get_dep_step_names(step_name):
            continue
        G.add_edges_from([(parent_step_name, step_name)
                          for parent_step_name in workflow_dag.get_dep_step_names(step_name)])
    return G, pos_dict


def view_dag(workflow_dag, step_colors=None):
    G, pos_dict = _build_graph(workflow_dag)
    if step_colors:
        values = [step_colors.get(node, '#ADB0B8') for node in G.nodes()]
    else:
        values = 'lightgrey'
    nx.draw_networkx(G=G, pos=pos_dict, node_size=500, node_color=values, node_shape='s', edgecolors='grey',
                     with_labels=True, connectionstyle="arc3,rad=0.2", font_size=6)
    plt.show()
