from abc import ABCMeta, abstractmethod
from json import JSONEncoder

from modelarts import constant
from modelarts.config.auth import auth_by_apig
from modelarts.util.secret_util import auth_expired_handler
from six import with_metaclass


class APIInterfaceBase(with_metaclass(ABCMeta, object)):
    """

    """

    def __init__(self):
        """
        Initialize a APIInterface instance.
        """

    @abstractmethod
    def create_workflow(self, body):
        """create structured workflow
        """
        pass

    @abstractmethod
    def update_workflow(self, workflow_id, body):
        """update structured workflow
        """
        pass

    @abstractmethod
    def get_workflow(self, workflow_id):
        """get workflow info
        """
        pass

    @abstractmethod
    def create_execution(self, workflow_id, body):
        """create execution
        """
        pass

    @abstractmethod
    def get_execution(self, workflow_id, execution_id):
        """get execution info
        """
        pass

    @abstractmethod
    def list_workflows(self, **kwargs):
        """list workflows
        """
        pass


class APIInterfaceAKSKImpl(APIInterfaceBase):
    """

    """

    def __init__(self, session, headers=None):
        """
        Initialize a APIInterface instance when using AKSK auth.
        """
        APIInterfaceBase.__init__(self)
        self.session = session
        self.headers = headers
        self.base_request_url = '/v2/' + self.session.project_id + '/workflows'

    @auth_expired_handler
    def create_workflow(self, body):
        """
        create_workflow
        Args:
            body (dict): request body of creating workflow

        Returns: response of creating workflow, including workflow id
        """
        request_url = self.base_request_url
        create_dataset_body = JSONEncoder().encode(body)
        return auth_by_apig(self.session,
                            constant.HTTPS_POST,
                            request_url, body=create_dataset_body,
                            headers=self.headers)

    @auth_expired_handler
    def update_workflow(self, workflow_id, body):
        """
        update_workflow
        Args:
            workflow_id (str): workflow_id
            body (dict): request body of updating workflow

        Returns: response of updating workflow, including workflow id
        """
        request_url = self.base_request_url + '/' + workflow_id
        update_dataset_body = JSONEncoder().encode(body)
        return auth_by_apig(self.session,
                            constant.HTTPS_PUT, request_url, '',
                            body=update_dataset_body,
                            headers=self.headers)

    @auth_expired_handler
    def get_workflow(self, workflow_id):
        """
        get_workflow
        Args:
            workflow_id (str): workflow_id

        Returns: workflow information
        """
        request_url = self.base_request_url + '/' + workflow_id
        return auth_by_apig(self.session,
                            constant.HTTPS_GET, request_url,
                            headers=self.headers)

    @auth_expired_handler
    def create_execution(self, workflow_id, body=None):
        """
        create_execution
        Args:
            workflow_id (str): workflow_id
            body (dict): request body of creating execution

        Returns: response of creating execution, including execution id

        """
        request_url = self.base_request_url + '/' + workflow_id + '/' + 'executions'
        create_dataset_body = JSONEncoder().encode(body)
        return auth_by_apig(self.session,
                            constant.HTTPS_POST,
                            request_url, body=create_dataset_body,
                            headers=self.headers)

    @auth_expired_handler
    def get_execution(self, workflow_id, execution_id):
        """
        get_execution
        Args:
            workflow_id (str): workflow_id
            execution_id (str): execution_id

        Returns: execution information

        """
        request_url = self.base_request_url + '/' + workflow_id + '/' + 'executions' + '/' + execution_id
        return auth_by_apig(self.session,
                            constant.HTTPS_GET, request_url,
                            headers=self.headers)

    @auth_expired_handler
    def list_workflows(self, **kwargs):
        """
        list workflows according conditions
        Args:
            **kwargs: query args

        Returns: workflow list info

        """
        request_url = self.base_request_url
        return auth_by_apig(self.session,
                            constant.HTTPS_GET, request_url,
                            query=kwargs, headers=self.headers)
