from enum import Enum


class StepState(Enum):
    Init = ("init", "#999999")
    WaitInputs = ("wait_inputs", "#FA9841")
    Creating = ("creating", "#5E7CE0")
    Created = ("created", "#5E7CE0")
    CreateFailed = ("create_failed", "#F66F6A")
    Pending = ("pending", "#6CBFFF")
    Running = ("running", "#6CBFFF")
    Stopping = ("stopping", "#6CBFFF")
    Stopped = ("stopped", "#C6C5C5")
    Timeout = ("timeout", "#F66F6A")
    Completed = ("completed", "#50D4AB")
    Failed = ("failed", "#F66F6A")
    Skipped = ("skipped", "#999999")


class WorkflowState(Enum):
    Init = ("init", "#ADB0B8")
    Running = ("running", "#FF8000")
    Stopped = ("stopped", "#F66F6A")
    Completed = ("completed", "#50D4AB")
    Failed = ("failed", "#F66F6A")


class WorkflowStateMapping:
    """
        Transition from Step state to Workflow state
    """
    _step_workflow_state_mapping = {
        StepState.Init: WorkflowState.Init,
        StepState.WaitInputs: WorkflowState.Running,
        StepState.Creating: WorkflowState.Running,
        StepState.Pending: WorkflowState.Running,
        StepState.Created: WorkflowState.Running,
        StepState.Running: WorkflowState.Running,
        StepState.Stopping: WorkflowState.Running,
        StepState.Stopped: WorkflowState.Stopped,
        StepState.Completed: WorkflowState.Completed,
        StepState.Failed: WorkflowState.Failed,
        StepState.CreateFailed: WorkflowState.Failed,
        StepState.Timeout: WorkflowState.Failed,
        StepState.Skipped: WorkflowState.Completed
    }

    @staticmethod
    def get_state(step_state):
        """
        Get workflow state according to step state
        Args:
            step_state (StepState): step state

        Returns: workflow state

        """
        workflow_state = WorkflowStateMapping._step_workflow_state_mapping.get(step_state)
        if workflow_state is None:
            raise KeyError("get workflow state failed. step_state {}".format(step_state))
        return workflow_state
