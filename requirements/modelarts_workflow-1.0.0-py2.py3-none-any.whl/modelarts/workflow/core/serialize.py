from enum import Enum
from typing import Dict, List
from modelarts.workflow.core.placeholder import Placeholder
from modelarts.workflow.data.storage import Storage
from modelarts.workflow.core.data import VariableConsumption


def serialize(cls):
    """
    This function is a Decorator, and used to add the ability to serialize to json for the specified class
    Args:
        cls (Object): need to be serialized class

    Returns (Object): need to be serialized class

    """
    def common_serialize(self):
        request = {}
        for name, value in vars(self).items():
            if value is None:
                continue
            request[name] = _serialize_value(value)
        return request
    cls.serialize = common_serialize
    return cls


def _serialize_value(value, serialize_placeholder_data=True):
    """
    Supported data types are: List, Dict, int, str, float, bool, Enum, Placeholder and custom objects

    Args:
        value (Object): need to be serialized object
        serialize_placeholder_data (bool): default is True

    Returns:

    """
    if value is None:
        return value
    if isinstance(value, List):
        result_list = [_serialize_value(e, serialize_placeholder_data) for e in value]
        return result_list
    elif isinstance(value, Dict):
        dic = {}
        for k, v in value.items():
            dic[k] = _serialize_value(v, serialize_placeholder_data)
        return dic
    elif isinstance(value, (int, str, float, bool)):
        return value
    elif isinstance(value, Enum):
        return value.value
    elif isinstance(value, Placeholder):
        if serialize_placeholder_data:
            if not value.is_set():
                raise ValueError('The value of placeholder {} does not set!'.format(value.name))
            return value.value
        return value
    elif isinstance(value, Storage):
        if serialize_placeholder_data:
            if value.path is None:
                raise ValueError('The value of Storage {} is None!'.format(value.name))
            return value.path
        return value
    elif isinstance(value, VariableConsumption):
        if serialize_placeholder_data:
            return value.consume()
        return value
    else:
        dic = {}
        for variable_name, variable_value in vars(value).items():
            if variable_value is None:
                continue
            dic[variable_name] = _serialize_value(variable_value, serialize_placeholder_data)
        return dic


def prepare_for_properties(obj):
    return _serialize_value(obj, serialize_placeholder_data=False)


def prepare_for_placeholders(*args):
    return [_serialize_value(element, serialize_placeholder_data=False) for element in args]
