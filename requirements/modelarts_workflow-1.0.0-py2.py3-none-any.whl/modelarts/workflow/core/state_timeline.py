import time
from typing import Union
from modelarts.workflow.core.state import WorkflowState, StepState

StateType = Union[WorkflowState, StepState]


class StateTimeline(object):
    """
    A timeline for recording workflow and step state changes
    """
    def __init__(self, state):
        """
            Initially set cur_state to init
        """
        self.cur_state = state
        self.timeline = list()

    def add_new_state(self, state: StateType, timestamp):
        if self.cur_state == state:
            return
        self.cur_state = state
        self.timeline.append((state.value[0], timestamp))

    @property
    def state_timeline(self):
        create_time = round(time.time() * 1000)
        if len(self.timeline) > 0:
            create_time = self.timeline[0][1]
        return {"state": self.cur_state.value[0], "create_time": create_time, "timeline": self.timeline}
