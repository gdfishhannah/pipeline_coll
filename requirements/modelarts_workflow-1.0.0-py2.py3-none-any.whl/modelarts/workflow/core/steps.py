import abc
import collections
import json
import logging
import time
from enum import Enum
from typing import Sequence

from modelarts.workflow.core.serialize import prepare_for_placeholders
from modelarts.workflow.core.entities import Entity, TransformType
from modelarts.workflow.core.state import StepState
from modelarts.workflow.core.state_timeline import StateTimeline
from modelarts.workflow.core.placeholder import Placeholder, PlaceholderDict, PlaceholderNotReadyException
from modelarts.workflow.core.data import AbstractDataConsumption, DataPlaceholdersDict, DataDict, AbstractData, \
    DataPlaceholderNotSet
from modelarts.workflow.util.validators import check_name
from modelarts.workflow.data.obs import OBSPlaceholder
from modelarts.workflow.data.dataset import DatasetPlaceholder, ServiceInputPlaceholder
from modelarts.workflow.data.storage import Storage
from modelarts.workflow.core.data import VariableConsumption
from modelarts.workflow.steps.condition import Condition
from modelarts.workflow.client.obs_client import ObsClient

JSON_INDENT_LEN = 4
DEFAULT_MAX_EXECUTION_MINUTES = 10080
DEFAULT_POLL_INTERVAL_SECONDS = 1

if not hasattr(time, 'time_ns'):
    time.time_ns = lambda: int(time.time() * 1e9)


class StepTypeEnum(Enum):
    MOCK = "mock"
    JOB = "job"
    MODEL = 'model'
    SERVICE = 'service'
    CREATE_DATASET = "create_dataset"
    RELEASE_DATASET = "release_dataset"
    LABELING = "labeling"
    DATASET_IMPORT = "dataset_import"
    CONDITION = "condition"
    MRSJOB = "mrs_job"
    SUBGRAPH = "sub_graph"


class StepPolicy:
    """
    Step execution policy
    """
    def __init__(
            self,
            poll_interval_seconds=DEFAULT_POLL_INTERVAL_SECONDS,
            max_execution_minutes=DEFAULT_MAX_EXECUTION_MINUTES,
            skip_conditions=None
    ):
        if poll_interval_seconds <= 0:
            poll_interval_seconds = DEFAULT_POLL_INTERVAL_SECONDS
        if max_execution_minutes <= 0:
            max_execution_minutes = DEFAULT_MAX_EXECUTION_MINUTES
        self.poll_interval_seconds = poll_interval_seconds
        self.max_execution_minutes = max_execution_minutes
        if skip_conditions:
            if not isinstance(skip_conditions, list):
                skip_conditions = [skip_conditions]
            StepPolicy._check_init_info(skip_conditions)
        self.skip_conditions = skip_conditions

    def to_definition_json(self):
        result = {
            "poll_interval_seconds": self.poll_interval_seconds,
            "max_execution_minutes": self.max_execution_minutes
        }
        if self.skip_conditions:
            result["skip_conditions"] = [condition.ref() for condition in self.skip_conditions]
        return result

    @staticmethod
    def _check_init_info(skip_conditions):
        for element in skip_conditions:
            if not isinstance(element, Condition):
                raise TypeError("The type must be Condition, but provided: {}".format(type(element)))


class AbstractInput(Entity):

    def __init__(self, name: str):
        check_name(name)
        self.name = name

    @abc.abstractmethod
    def evaluate(self):
        pass

    @property
    @abc.abstractmethod
    def data(self):
        pass

    @abc.abstractmethod
    def extract_data_placeholder(self):
        pass


class AbstractOutput(Entity):
    def __init__(self, name: str):
        check_name(name)
        self.name = name
        self._data_type = ""
        self._step_name = ""
        self.variables = None

    @property
    def step_name(self):
        return self._step_name

    @step_name.setter
    def step_name(self, value):
        self._step_name = value

    def get_snapshot(self):
        return {
            "name": self.name,
            "data": self.as_input().consume().get_snapshot()
        }

    @abc.abstractmethod
    def as_input(self) -> AbstractDataConsumption:
        pass

    def get_output_variable(self, variable):
        return VariableConsumption(self, self.step_name, self.name, variable)

    @property
    def data_type(self):
        return self._data_type

    @data_type.setter
    def data_type(self, data_type):
        self._data_type = data_type

    @abc.abstractmethod
    def set_to_skip(self):
        pass


class StepNotReadyException(Exception):
    pass


class StepInputDict(collections.UserDict):

    def __init__(self, inputs: Sequence[AbstractInput]):
        super().__init__()
        if inputs:
            for i in inputs:
                if self.get(i.name) is not None:
                    raise ValueError("The input name <{}> already exists in the same input".format(i.name))
                self[i.name] = i
        self.data_placeholders = DataPlaceholdersDict()
        self.data_ = DataDict()
        self._extract_data_placeholders()
        self._extract_data()

    def to_definition_json(self) -> TransformType:
        inputs_json = []
        for step_input in self.values():
            inputs_json.append(step_input.to_definition_json())
        return inputs_json

    def get_snapshot(self):
        """
        get snapshot of step inputs
        Returns:

        """
        return [x.get_snapshot() for x in self.values()]

    def _extract_data_placeholders(self):
        """
            Extract DataPlaceholder from Inputs
        Returns:

        """
        for step_input in self.values():
            self.data_placeholders.add_data_placeholder(step_input.extract_data_placeholder())

    def _extract_data(self):
        """
            Extract Data from Inputs
        Returns:

        """
        for step_input in self.values():
            data = step_input.extract_data()
            if isinstance(data, AbstractData):
                self.data_.add_data(data=data)

    def check_ready(self):
        return self.data_placeholders.check_ready()

    def wait_input(self):
        for data_req in self.data_placeholders.values():
            if data_req.is_set():
                continue
            if isinstance(data_req, OBSPlaceholder):
                example = \
                    'for example:(1) Workflow object is workflow_test.\n' \
                    '            (2) The name of OBSPlaceholder is data_test\n' \
                    '            (3) The data you want to set is OBSPath(obs_path="***").\n' \
                    '        workflow_test.set_data(name=data_test, data=OBSPath(obs_path="***"))'
                logging.info("%s. Please use the 'set_data(name, data)' method  of Workflow, and 'name' must be '%s', "
                             "'data' is an instance object of 'OBSPath'. You can refer to the following examples:\n %s",
                             data_req, data_req.name, example)
            if isinstance(data_req, DatasetPlaceholder):
                example = \
                    'for example:(1) Workflow object is workflow_test.\n' \
                    '            (2) The name of DatasetPlaceholder is data_test\n' \
                    '            (3) The data you want to set is Dataset(dataset_name="**", version_name="**").\n' \
                    '        workflow_test.set_data(name=data_test, data=Dataset(dataset_name="**", version_name="**"))'
                logging.info("%s. Please use the 'set_data(name, data)' method  of Workflow, and name must be '%s', "
                             "data is an instance object of Dataset. You can refer to the following examples:\n %s",
                             data_req, data_req.name, example)
            if isinstance(data_req, ServiceInputPlaceholder):
                example = \
                    'for example:(1) Workflow object is workflow_test.\n' \
                    '            (2) The name of ServiceInputPlaceholder is data_test\n' \
                    '            (3) The data you want to set is ' \
                    'ServiceRunCfgDict([ServiceRunCfg(model_name="**", model_version="**")]).\n' \
                    '        workflow_test.set_data(name=data_test, data=' \
                    'ServiceRunCfgDict([ServiceRunCfg(model_name="**", model_version="**")]))'
                logging.info("%s. Please use the 'set_data(name, data)' method  of Workflow, and name must be '%s', "
                             "data is an instance object of ServiceRunCfgDict. "
                             "You can refer to the following examples:\n %s", data_req, data_req.name, example)

    def wait_cmd_input(self):
        for data_placeholder in self.data_placeholders.values():
            if data_placeholder.is_set():
                continue
            data_placeholder.get_data_from_command_line()

    def evaluate(self):
        for step_input in self.values():
            step_input.evaluate()


class StepOutputDict(collections.UserDict):

    def __init__(self, outputs: Sequence[AbstractOutput]):
        super().__init__()
        if outputs:
            for o in outputs:
                if self.get(o.name) is not None:
                    raise ValueError("The output name <{}> already exists in the same output".format(o.name))
                self[o.name] = o

    def to_definition_json(self) -> TransformType:
        outputs_json = []
        for step_output in self.values():
            outputs_json.append(step_output.to_definition_json())
        return outputs_json

    def get_snapshot(self):
        return [x.get_snapshot() for x in self.values()]


class StepProperties:

    def __init__(self, properties: dict):
        if not properties:
            properties = {}
        self.properties = properties

    @staticmethod
    def _convert_dict_to_json(d):
        if isinstance(d, dict):
            return {k: StepProperties._convert_dict_to_json(v) for k, v in d.items()}
        elif isinstance(d, list):
            return [StepProperties._convert_dict_to_json(e) for e in d]
        elif isinstance(d, (Placeholder, Storage, VariableConsumption)):
            return d.ref()
        else:
            return d

    def to_definition_json(self) -> TransformType:
        result_json = {}
        for k, v in self.properties.items():
            result_json[k] = StepProperties._convert_dict_to_json(v)
        return result_json


class StepPlaceholders:
    def __init__(self, properties: dict, outputs: Sequence[AbstractOutput], inputs: Sequence[AbstractInput], policy: StepPolicy):
        self.placeholders = PlaceholderDict()
        if properties:
            self._extract_placeholders(properties)
        if outputs:
            self._extract_placeholders(prepare_for_placeholders(*outputs))
        if inputs:
            extract_placeholder_inputs = []
            for step_input in inputs:
                if not isinstance(step_input.declared_data, AbstractDataConsumption):
                    extract_placeholder_inputs.append(step_input)
            self._extract_placeholders(prepare_for_placeholders(*extract_placeholder_inputs))
        if policy:
            self._extract_placeholders(prepare_for_placeholders(policy))

    def _extract_placeholders(self, dict_contains_placeholders):
        self.extract_placeholder_in_dict(dict_contains_placeholders, self.placeholders)

    @staticmethod
    def extract_placeholder_in_dict(value, step_placeholders):
        if isinstance(value, dict):
            for k, v in value.items():
                StepPlaceholders.extract_placeholder_in_dict(v, step_placeholders)
        elif isinstance(value, list):
            for e in value:
                StepPlaceholders.extract_placeholder_in_dict(e, step_placeholders)
        elif isinstance(value, Placeholder):
            step_placeholders.add_placeholder(value)
        else:
            return

    def check_ready(self):
        try:
            self.placeholders.check_ready()
        except PlaceholderNotReadyException as e:
            raise StepNotReadyException(str(e))

    def wait_input(self):
        for param in self.placeholders.values():
            if param.is_set():
                continue
            example = \
                'for example:(1) Workflow object is workflow_test.\n'\
                '            (2) The name of Placeholder is placeholder_test, type is int.\n'\
                '            (3) The value you want to set is 11.\n'\
                '            workflow_test.set_placeholder(placeholder_test, 11)'
            logging.info(
                "Please use 'set_placeholder(name, value)' method of Workflow set the value of the placeholder, "
                "and 'name' must be '%s', the type is '%s'. You can refer to the following examples:\n %s",
                param.name, param.placeholder_type, example)

    def wait_cmd_input(self):
        for param in self.placeholders.values():
            if param.is_set():
                continue
            param.get_value_from_command_line()


class Step(Entity):
    # max name length
    CONST_MAX_NAME_LENGTH = 128

    def __init__(self,
                 name: str,
                 step_type: StepTypeEnum,
                 title: str = None,
                 description: str = None,
                 inputs: (AbstractInput, Sequence[AbstractInput]) = None,
                 outputs: (AbstractInput, Sequence[AbstractOutput]) = None,
                 properties: dict = None,
                 depend_steps: list = None,
                 policy: StepPolicy = None
                 ):
        """

        Args:
            name (str): The name of step
            step_type (StepTypeEnum): step type
            title (str): step title info，when title is None, use name instead
            description (str): step description info
            inputs (AbstractInput, Sequence[AbstractInput]): step inputs list
            outputs (AbstractInput, Sequence[AbstractOutput]): step outputs list
            properties (dict): step properties info
            depend_steps(Union(Step, List[Step])): A or a list of step which this step depends on
            policy(StepPolicy): Step execution policy
        """
        if depend_steps is None:
            depend_steps = []
        if inputs and not isinstance(inputs, Sequence):
            inputs = [inputs]
        if outputs and not isinstance(outputs, Sequence):
            outputs = [outputs]
        if depend_steps and not isinstance(depend_steps, Sequence):
            depend_steps = [depend_steps]
        Step._check_init_info(name=name, step_type=step_type, inputs=inputs, outputs=outputs, depend_steps=depend_steps)
        self.name = name
        self.step_type = step_type
        self.title = title or name
        self.description = description
        self.inputs = StepInputDict(inputs)
        self.outputs = StepOutputDict(outputs)
        self.properties = StepProperties(properties)
        self._placeholders = StepPlaceholders(properties=properties, outputs=outputs, inputs=inputs, policy=policy)
        self.depend_steps = depend_steps
        self.policy = policy
        self._state = StepState.Init
        self.instance_id = None
        self.client = None
        self.obs_client = None
        self.state_timeline = StateTimeline(StepState.Init)
        self._snapshot_path = None
        self._take_snapshot = True

    @property
    def data_placeholders(self):
        return self.inputs.data_placeholders

    @property
    def placeholders(self):
        return self._placeholders.placeholders

    @placeholders.setter
    def placeholders(self, placeholder_dict):
        self._placeholders.placeholders.merge(placeholder_dict)

    @property
    def data_(self):
        return self.inputs.data_

    @property
    def state(self):
        return self._state

    def to_definition_json(self) -> TransformType:
        depend_steps_json = self.depend_step_names
        content = {
            "name": self.name,
            "type": self.step_type.value,
            "title": self.title,
            "inputs": self.inputs.to_definition_json(),
            "outputs": self.outputs.to_definition_json(),
            "properties": self.properties.to_definition_json(),
            "depend_steps": depend_steps_json,
        }
        if self.description:
            content["description"] = self.description
        if self.policy:
            content["policy"] = self.policy.to_definition_json()

        return content

    def start(self, debug=False, take_snapshot=True, snapshot_path=None):
        """
        Start run a step
        Args:
            debug (bool): whether use debug mode, in which user can set parameter and data with python code
            take_snapshot (bool): whether to take snapshot
            snapshot_path (Path): root logging path of this experiment
        """
        logging.info("start step %s ...", self.name)
        self._take_snapshot = take_snapshot
        if self._take_snapshot:
            self._snapshot_path = snapshot_path
            self._snapshot_path.mkdir(parents=True, exist_ok=True)
            (self._snapshot_path / "step.json").write_text(
                json.dumps(self.to_definition_json(), indent=JSON_INDENT_LEN))
        if self.state != StepState.Init and self.state != StepState.WaitInputs:
            logging.error("The status of the step(%s) is incorrect. status: %s", self.name, self.state.value[0])
            return
        is_ready, message = self.is_ready()
        if not is_ready:
            if self.state == StepState.WaitInputs:
                raise AttributeError
            if debug:
                self.set_state(StepState.WaitInputs)
                return
            else:
                self.wait_command_line_input()

        self.inputs.evaluate()

        if self.skip_conditions():
            self.set_state(StepState.Skipped)
            logging.info("step(%s) is skipped", self.name)
            return

        if take_snapshot:
            (self._snapshot_path / "inputs.json").write_text(
                json.dumps(self.inputs.get_snapshot(), indent=JSON_INDENT_LEN)
            )
        self.set_state(StepState.Creating)

        if self.instance_id:
            logging.info("step(%s) use a created instance. instance id: %s", self.name, self.instance_id)
            self.set_state(StepState.Created)
            return

        logging.info("step(%s) is creating instance", self.name)
        is_success, instance_id = self.create_instance()
        if not is_success:
            logging.error("step(%s) failed to create an instance. error message: %s", self.name, instance_id)
            self.set_state(StepState.CreateFailed)
            return
        logging.info("step(%s) successfully creates an instance. instance id: %s", self.name, instance_id)
        self.instance_id = instance_id
        self.set_state(StepState.Created)

    def stop(self):
        if self.state in (StepState.Creating, StepState.Pending, StepState.Running, StepState.Created):
            logging.info("stop step(%s) ...", self.name)
            is_success, message = self.stop_instance()
            if not is_success:
                logging.error("step(%s) failed to stop an instance. error message: %s", self.name, message)
                self.set_state(StepState.Failed)
        if self.state == StepState.WaitInputs:
            logging.info("cancel waiting for inputs, stop step(%s) ...", self.name)
            self.set_state(StepState.Stopped)

    def set_instance_id(self, instance_id: str):
        """
        Set step instance id
        Args:
            instance_id(str): need to be set instance id

        """
        if not instance_id:
            raise ValueError("instance_id is none")
        if not isinstance(instance_id, str):
            raise TypeError("instance_id must be type of str, but got type: {}".format(type(instance_id)))
        self.instance_id = instance_id

    def skip_conditions(self):
        if self.policy and self.policy.skip_conditions:
            result = True
            for condition in self.policy.skip_conditions:
                result = result and condition.is_satisfied(self.obs_client)
            return result

        if not self.depend_steps:
            return False

        for depend_step in self.depend_steps:
            if depend_step.state != StepState.Skipped:
                return False
        return True

    def build_client(self, session):
        """
        Initialize the client object and call other services through the client
        Args:
            session (Session): building interactions with cloud service.

        Returns:

        """
        self.obs_client = ObsClient(session)

    @abc.abstractmethod
    def create_instance(self) -> (bool, str):
        """
        Create an instance corresponding to a step, such as a training step, which will send a training job to the
        training management and return the corresponding instance id If it fails, return the corresponding error message

        :return: (bool, str)
        """

    @abc.abstractmethod
    def stop_instance(self) -> (bool, str):
        """
        Stop the instance corresponding to the step, if it fails, return the corresponding error message

        :return: (bool, str)
        """

    @abc.abstractmethod
    def update_instance_state(self):
        """
        Update step state according instance state
        """

    def is_ready(self) -> (bool, str):
        """
        Determine whether the step is ready to run, the default is true

        :return: (bool, str)
        """
        try:
            self.inputs.check_ready()
            self._placeholders.check_ready()
        except StepNotReadyException as e:
            return False, str(e)
        except DataPlaceholderNotSet as e:
            return False, str(e)
        return True, "ready"

    def wait_input(self):
        self._placeholders.wait_input()
        self.inputs.wait_input()

    def wait_command_line_input(self):
        self._placeholders.wait_cmd_input()
        self.inputs.wait_cmd_input()

    def set_state(self, state: StepState):
        """
        Set the state of the state, through this function, you can set the state and record the state change timeline
        Args:
            state (StepState): step state

        Returns:

        """
        if self._state != state:
            logging.info("step(%s) status changes from %s to %s.", self.name, self._state.value[0], state.value[0])
        t = round(time.time() * 1000)
        self._state = state
        self.state_timeline.add_new_state(state, t)

    def set_to_skip(self):
        for step_output in self.outputs.values():
            step_output.set_to_skip()

    @property
    def depend_step_names(self):
        """
        Returns the name list of dependent steps

        :return: List[str]
        """
        if self.depend_steps:
            return [depend_step.name for depend_step in self.depend_steps]
        return []

    @classmethod
    def _check_init_info(cls, name, step_type, inputs, outputs, depend_steps):
        check_name(name)
        Step._check_type(step_type)
        Step._check_list_element(inputs, AbstractInput, 'inputs')
        Step._check_list_element(outputs, AbstractOutput, 'outputs')
        Step._check_list_element(depend_steps, Step, 'depend_steps')
        Step._set_step_name(name, inputs)
        Step._set_step_name(name, outputs)

    @classmethod
    def _check_type(cls, step_type):
        if not step_type:
            raise ValueError('step type is empty or none')
        if not isinstance(step_type, StepTypeEnum):
            raise TypeError('step type is not StepTypeEnum')

    @classmethod
    def _check_list_element(cls, elements, element_type, elements_name):
        if not elements:
            return
        for element in elements:
            if not isinstance(element, element_type):
                raise TypeError('the element type in {} is not {}'.format(elements_name, element_type))

    @classmethod
    def _set_step_name(cls, name, elements):
        if not elements:
            return
        for element in elements:
            element.step_name = name

    def dump_output_data(self):
        if not self._take_snapshot:
            return
        output_logging_path = self._snapshot_path / "outputs"
        output_logging_path.mkdir(parents=True, exist_ok=True)
        (output_logging_path / "outputs.json").write_text(
            json.dumps(self.outputs.get_snapshot(), indent=JSON_INDENT_LEN))

    def check_valid_to_release(self):
        """
        Check step meets the conditions for publishing to AI Gallery
        Returns:

        """
        for step_input in self.inputs.values():
            if isinstance(step_input.declared_data, Condition):
                continue
            if not step_input.declared_data.is_need_consume():
                raise ValueError('The type of input data is {}, which does not support publishing to AI Gallery'.format(
                    type(step_input.declared_data))
                )
