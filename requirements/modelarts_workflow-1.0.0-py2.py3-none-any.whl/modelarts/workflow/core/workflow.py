import json
import re
import signal
import threading
import time
import logging
import uuid
import copy
from pathlib import Path
from abc import ABC
from typing import Sequence, Union

from modelarts.workflow.client.algorithm_client import AlgorithmClient
from modelarts.workflow.core.entities import Entity, TransformType
from modelarts.workflow.core.state import StepState, WorkflowState, WorkflowStateMapping
from modelarts.workflow.core.state_timeline import StateTimeline
from modelarts.workflow.core.steps import Step, StepTypeEnum
from modelarts.workflow.core.subgraph import Subgraph
from modelarts.workflow.dag.view_dag import view_dag
from modelarts.workflow.core.data import DataPlaceholdersDict, DataDict, AbstractData, AbstractDataPlaceholders
from modelarts.workflow.core.placeholder import PlaceholderDict, Placeholder
from modelarts.workflow.dag.dag import Dag
from modelarts.workflow.policy.policy import Policy
from modelarts.workflow.steps import JobStep
from modelarts.workflow.util.ci import get_ci_metadata
from modelarts.workflow.util.logging import setup_logging
from modelarts.workflow.steps.condition_step import ConditionStep
from modelarts.workflow.util.utils import get_next_version_name
from modelarts.workflow.util.validators import check_name, check_description
from modelarts.workflow.client.workflow_client import WorkflowClient
from modelarts.session import Session
from modelarts.workflow.client.dataset_client import DatasetClient
from modelarts.workflow.client.gallery_client import GalleryClient
from modelarts.workflow.data.dataset import Dataset, DatasetPlaceholder
from modelarts.workflow.data.storage import Storage, StorageManagement
from modelarts.workflow.data.label_task import LabelTask, LabelTaskPlaceholder
from modelarts.workflow.data.model import GalleryModel, GALLERY_MODEL_DATA_TYPE
from modelarts.workflow.resource.workspace import Workspace

JSON_INDENT_LEN = 4


class WorkflowNotInited(Exception):
    pass


class WorkflowNotDagException(Exception):
    def __init__(self, message=""):
        super().__init__()
        self.message = message

    def __str__(self):
        return "error message: {}".format(self.message)


def _trim_depend_steps(step_name, depend_steps):
    depend_step_names_set = set()
    result = []
    depend_step_names_set.add(step_name)
    for depend_step in depend_steps:
        if depend_step.name not in depend_step_names_set:
            result.append(depend_step.name)
        depend_step_names_set.add(depend_step.name)
    return result


def _init_gallery_client(session):
    if session is None:
        session = Session()
    return GalleryClient(session)


def add_whitelist_users(content_id, version_num, user_groups, session=None):
    """
    Add whitelist users for workflow and dependent assets
    Args:
        content_id (str): The content ID
        version_num (str): The content version num
        user_groups (Union(str, list[str])): User groups, only support domain ID
        session (Session): building interactions with cloud service

    Returns:

    """
    gallery_client = _init_gallery_client(session)
    if not isinstance(user_groups, list):
        user_groups = [user_groups]

    logging.info("start adding whitelist users %s for workflow content %s", user_groups, content_id)
    gallery_client.add_whitelist_users(content_id, user_groups)

    assets_info = gallery_client.get_workflow_assets_info(content_id, version_num)
    for asset in assets_info.values():
        logging.info("start adding whitelist users %s for dependent asset %s", user_groups, asset[0])
        gallery_client.add_whitelist_users(asset[0], user_groups)


def delete_whitelist_users(content_id, version_num, user_groups, session=None):
    """
    Delete whitelist users for workflow and dependent assets
    Args:
        content_id (str): The content ID
        version_num (str): The content version num
        user_groups (Union(str, list[str])): User groups, only support domain ID
        session (Session): building interactions with cloud service

    Returns:

    """
    gallery_client = _init_gallery_client(session)
    if not isinstance(user_groups, list):
        user_groups = [user_groups]

    logging.info("start deleting whitelist users %s for workflow content %s", user_groups, content_id)
    gallery_client.delete_whitelist_users(content_id, user_groups)

    assets_info = gallery_client.get_workflow_assets_info(content_id, version_num)
    for asset in assets_info.values():
        logging.info("start deleting whitelist users %s for dependent asset %s", user_groups, asset[0])
        gallery_client.delete_whitelist_users(asset[0], user_groups)


class Workflow(Entity, ABC):

    def __init__(self,
                 name: str,
                 desc: str,
                 steps: Sequence[Step],
                 session: Session = None,
                 storages: Union[Storage, Sequence[Storage]] = None,
                 policy: Policy = None,
                 subgraphs: Sequence[Subgraph] = None,
                 extend: dict = None,
                 workspace: Workspace = Workspace.instance()):
        check_name(name=name)
        check_description(desc)
        Workflow._check_names(steps=steps)
        self.name = name
        self.desc = desc
        self.workspace = workspace
        self.steps = steps
        self.subgraphs = subgraphs
        self.policy = policy
        self.extend = extend
        self._dag = None
        is_valid, dag, message = self.check_dag()
        if not is_valid:
            raise WorkflowNotDagException(message)
        Workflow._check_name_valid_with_condition_step(steps)
        self._dag = dag
        is_valid, message = self.check_sub_graph()
        if not is_valid:
            raise WorkflowNotDagException(message)
        self._execution = None
        self._session = session if session else Session()
        self._client = WorkflowClient(self._session)
        self._dataset_client = DatasetClient(self._session)
        self._gallery_client = GalleryClient(self._session)
        self._algorithm_client = AlgorithmClient(self._session)
        self._pretreatment_input_data()
        self._build_client_for_steps()
        self._storage_management = StorageManagement(self._session, storages) if storages else None
        setup_logging()

    def _extra_data_and_placeholders(self):
        data_placeholders = {}
        data_dict = {}
        placeholders = {}
        for step in self.steps:
            data_placeholders.update(step.data_placeholders)
            data_dict.update(step.data_)
            placeholders.update(step.placeholders)
        return data_placeholders, data_dict, placeholders

    def _pretreatment_input_data(self):
        data_placeholders, data_dict, _ = self._extra_data_and_placeholders()
        for data_placeholder in data_placeholders.values():
            if isinstance(data_placeholder, (DatasetPlaceholder, LabelTaskPlaceholder)):
                data_placeholder.dataset_client = self._dataset_client
        for data in data_dict.values():
            if isinstance(data, Dataset):
                data.fill_id_and_version_id(dataset_client=self._dataset_client)
            if isinstance(data, LabelTask):
                data.fill_dataset_and_task_id(dataset_client=self._dataset_client)
            if isinstance(data, GalleryModel):
                data.fill_content_id(self._gallery_client)

    def _build_client_for_steps(self):
        for step in self.steps:
            step.build_client(session=self._session)

    def check_dag(self) -> (bool, Dag, str):
        """
        Check whether the workflow structure is a DAG
        Returns (Boolean, message): check result and message

        """
        is_success, dag, message = self._create_dag_graph()
        if not is_success:
            return is_success, dag, message
        is_success, message = dag.validate()
        return is_success, dag, message

    def check_sub_graph(self) -> (bool, str):
        """
        Check  whether subgraph is valid
        Returns (Boolean, message): check result and message

        """
        if self.subgraphs is None:
            return True, "valid"
        is_success, message = self._check_subgraph_element()
        if not is_success:
            return is_success, message
        is_success, dag, message = self._create_dag_with_subgraph()
        if not is_success:
            return is_success, message
        return dag.validate()

    def _check_subgraph_element(self) -> (bool, str):
        """
        Check whether subgraph and subgraph element is valid
        Returns (Boolean, message): check result and message

        """
        workflow_step_name_set = set()
        for step in self.steps:
            workflow_step_name_set.add(step.name)
        subgraph_name_set = set()
        subgraph_step_name_set = set()
        for subgraph in self.subgraphs:
            if subgraph.name not in subgraph_name_set:
                subgraph_name_set.add(subgraph.name)
            else:
                return False, "subgraph name %s duplicatged" % subgraph.name

            if not subgraph_name_set.isdisjoint(workflow_step_name_set):
                return False, "subgraph name %s duplicated with workflow step name" % subgraph.name

            if subgraph.steps is None:
                return False, 'subGraph %s step element can\'t be empty' % subgraph.name

            for step in subgraph.steps:
                if step.name not in subgraph_step_name_set:
                    subgraph_step_name_set.add(step.name)
                else:
                    return False, "subgraph step name %s duplicated" % step.name

                if not subgraph_step_name_set.issubset(workflow_step_name_set):
                    return False, 'subGraph step element %s not found in workflow steps' % step.name
        return True, 'valid'

    @staticmethod
    def _add_ci_metadata(request_body, ci_metadata):
        if ci_metadata:
            if request_body.get("extend", None) is None:
                request_body["extend"] = ci_metadata
                return request_body
            for k, v in ci_metadata.items():
                request_body["extend"][k] = v
        return request_body

    def release(self):
        """
        Release a workflow instance

        Returns (str): The workflow instance ID

        """
        request_body = self.to_definition_json()
        ci_metadata = get_ci_metadata()
        request_body = Workflow._add_ci_metadata(request_body, ci_metadata)
        logging.debug("The request body is %s", request_body)
        workflow_id = self._client.get_workflow_id(self.name)
        if workflow_id is None:
            logging.info("start releasing Workflow %s", self.name)
            workflow_id = self._client.release_workflow(body=request_body)
        else:
            logging.info("start updating Workflow %s, workflow_id %s", self.name, workflow_id)
            workflow_id = self._client.update_workflow(workflow_id, body=request_body)
        logging.info("Workflow %s successfully released, and workflow ID is %s", self.name, workflow_id)
        return workflow_id

    def release_and_run(self):
        """
        Release a workflow instance,and run the workflow

        Returns (str): The workflow execution id
        """
        workflow_id = self.release()
        exec_body = {}
        ci_metadata = get_ci_metadata()
        exec_body = Workflow._add_ci_metadata(exec_body, ci_metadata)
        execution_id = self._client.run_workflow(workflow_id=workflow_id, request_body=exec_body)
        logging.info("Run the workflow, workflow id is %s, and the execution id is %s.", workflow_id, execution_id)
        return execution_id

    def _check_valid_to_release(self):
        """
        Check whether the workflow meets the conditions for publishing to the AI Gallery
        Returns:

        """
        for step in self.steps:
            step.check_valid_to_release()

    def _release_assets_to_gallery(self, cur_step_assets, visibility="private", group_users=None):
        """
        Release the assets to AIGallery
        Args:
            cur_step_assets(dict): step->(content_id, version_num)
            visibility (str): The visibility of the content supports three types: private, public, and groups.
                            The group requires an additional field group_users to specify which users are visible
            group_users (list): A list of domain Ids that can access the content
        Returns (dict): {step_name, (content id , version id)}
        """
        if cur_step_assets is None:
            cur_step_assets = {}
        step_assets = {}
        for step in self.steps:
            if not isinstance(step, JobStep) or not step.allowed_to_release_algorithm():
                continue
            logging.info("---------------------------------------------------------------------------")
            logging.info("  ++++Start publish the step %s dependent asset to the AI gallery++++", step.name)
            content_id, cur_version_num = cur_step_assets.get(step.name, (None, None))
            content_id, version_id = step.release_algorithm(content_id,
                                                            cur_version_num,
                                                            visibility,
                                                            group_users)
            logging.info("  ++++Step %s dependent asset successfully published to the AI gallery++++", step.name)
            logging.info("---------------------------------------------------------------------------")
            step_assets[step.name] = (content_id, version_id)
        return step_assets

    def _convert_json_to_metadata(self, step_assets):
        """
        Convert workflow's json information to metadata
        step_assets(dict): step->(content_id, version_num)
        Returns (str): the metadata

        """
        workflow_json = self.to_definition_json()
        assets = workflow_json.get("assets", [])
        for step_json in workflow_json.get("steps"):
            if StepTypeEnum.JOB.value == step_json.get("type"):
                Workflow._convert_job_json(step_json, step_assets, assets)
        workflow_json["assets"] = assets
        return json.dumps(workflow_json)

    @staticmethod
    def _convert_job_json(step_json, step_assets, assets):
        algorithm_json = step_json.get("properties", {}).get("algorithm", {})
        step_name = step_json.get("name")
        content_id, version_id = step_assets.get(step_name, (None, None))
        if not content_id or not version_id:
            return
        algorithm_json["item_version_id"] = version_id
        asset_name = Workflow._generate_asset_name()
        algorithm_json["subscription_id"] = '$ref/assets/{}'.format(asset_name)
        algorithm_json.pop("id", None)
        algorithm_json.pop("code_dir", None)
        algorithm_json.pop("boot_file", None)
        algorithm_json.pop("command", None)
        algorithm_json.pop("engine", None)
        algorithm_asset = {
            "name": asset_name,
            "type": "algorithm2",
            "content_id": content_id
        }
        assets.append(algorithm_asset)

    @staticmethod
    def _convert_model_json(step_json, data_list, assets):
        inputs_list = step_json.get("inputs", [])
        for input_index, input_json in enumerate(inputs_list):
            if input_json["type"] != GALLERY_MODEL_DATA_TYPE:
                continue
            inputs_list.pop(input_index)
            data_ref = input_json["data"]
            step_json.get("properties", {})["gallery_model"] = data_ref
            gallery_model_name = re.sub(r'\$ref/assets/', "", data_ref)
            for data_index, data_json in enumerate(data_list):
                if data_json["name"] == gallery_model_name:
                    data_list.pop(data_index)
                    data_json.pop("used_steps")
                    assets.append(data_json)

    @staticmethod
    def _generate_asset_name():
        return uuid.uuid4().hex

    def create_content(self, title, visibility, group_users=None):
        """
        Create a content to the AI Gallery
        Args:
            title (str): The name of the published content in the AI Gallery
            visibility (str): The visibility of the content supports three types: private, public, and groups.
                            The group requires an additional field group_users to specify which users are visible
            group_users (list): A list of domain Ids that can access the content

        Returns (str): The content ID in the AI Gallery

        """
        logging.info("Start create a workflow content to the AI Gallery.")
        content_id = self._gallery_client.publish_content(title=title, visibility=visibility, group_users=group_users)
        logging.info("The workflow content successfully created, and the title is %s, content ID is %s",
                     title,
                     content_id)
        return content_id

    def release_to_gallery(self, content_id=None,
                           version=None,
                           desc=None,
                           title=None,
                           visibility="private",
                           group_users=None):
        """
        Release a new version for content
        Args:
            content_id (str): content ID, if value is None,will create a content
            version (str): the content version name, for example 1.0.0;if value is None,
                            Use the default value(1.0.0) or auto-increment of the content version.
            desc (str): the description of content version
            title(str) : the title of the content, if title is None, title equals the workflow name.
                        The title is used only when the content_id is None.
            visibility (str): The visibility of the content supports three types: private, public, and groups.
                The group requires an additional field group_users to specify which users are visible
            group_users (list): A list of domain Ids that can access the content

        Returns:
        examples:
            # Create a new workflow asset, and create the workflow depends assets.
            workflow.release_to_gallery(content_id=None)
            workflow.release_to_gallery(content_id=None, version="2.0.1")
            workflow.release_to_gallery(content_id=None, version="2.0.1", title="test1123")

            # Reuse existing workflow assets, and create the workflow depends assets version.
            workflow.release_to_gallery(content_id="XXXXX")
            workflow.release_to_gallery(content_id="XXXXX", version="2.0.0")
        """
        self._check_valid_to_release()
        cur_step_assets = {}
        latest_version_num = None
        if not content_id:
            if title is None:
                title = self.name
            content_id = self.create_content(title, visibility, group_users)
        else:
            latest_version_id, latest_version_num = self._gallery_client.get_latest_version(content_id)
            if latest_version_id is not None:
                cur_step_assets = self._gallery_client.get_workflow_assets_info(content_id, latest_version_id)

        if version:
            version_num = version
        else:
            version_num = "1.0.0" if latest_version_num is None else get_next_version_name([latest_version_num])

        logging.info("====Start publish Workflow %s to the AI gallery, and content id %s, version num is %s====",
                     self.name,
                     content_id,
                     version_num)
        logging.info("----Start publish the dependent assets to the AI gallery----")
        step_assets = self._release_assets_to_gallery(cur_step_assets, visibility, group_users)
        logging.info("----The dependent assets published to the AI gallery----")
        metadata = self._convert_json_to_metadata(step_assets)
        self._gallery_client.publish_content_version(
            content_id=content_id, version_num=version_num, metadata=metadata, desc=desc)
        logging.info("====Workflow version %s successfully published to the AI gallery====", version_num)

    def run(self, steps: Sequence[Step], experiment_id: str, take_snapshot=True, snapshot_path=None):
        """
        Start to run the workflow, support run part or all of steps

        Args:
            steps (Sequence[Step]): steps to run, can be part or all of workflow steps
            experiment_id (str): experiment id
            take_snapshot (bool): whether to take snapshot
            snapshot_path (str): snapshot path of this experiment, use <current directory>/<experiment_id> as default
        """
        logging.info("start running workflow...")
        exit_flag = threading.Event()
        self.create_signal_handlers(exit_flag)
        execution_id = uuid.uuid4().hex
        if self._storage_management:
            self._storage_management.register_directories(run_id=execution_id)
        experiment_snapshot_path = self.prepare_experiment_snapshot(
            take_snapshot, experiment_id, snapshot_path, execution_id)
        self._execution = WorkflowExecution(steps, experiment_id, self._dag, False, exit_flag,
                                            take_snapshot=take_snapshot,
                                            snapshot_path=experiment_snapshot_path,
                                            storage_management=self._storage_management)
        self._execution.run()

    def debug(self, steps: Sequence[Step], experiment_id: str, take_snapshot=True, snapshot_path=None):
        """
        Start to debug run the workflow, support run part or all of steps, and need to be used with next function

        Args:
            steps (Sequence[Step]): steps to run, can be part or all of workflow steps
            experiment_id (str): experiment id
            take_snapshot (bool): whether to take snapshot
            snapshot_path (str): snapshot path of this experiment, use <current directory>/<experiment_id> as default
        """
        logging.info("start debugging workflow...")
        execution_id = uuid.uuid4().hex
        if self._storage_management:
            self._storage_management.register_directories(run_id=execution_id)
        experiment_snapshot_path = self.prepare_experiment_snapshot(
            take_snapshot, experiment_id, snapshot_path, execution_id)
        self._execution = WorkflowExecution(steps, experiment_id, self._dag, True,
                                            take_snapshot=take_snapshot,
                                            snapshot_path=experiment_snapshot_path,
                                            storage_management=self._storage_management)
        self._execution.run()

    def next(self):
        """
        After the start of the debug mode, the execution of each step is paused by default and the next() call is
        required to proceed to the next step
        """
        if self._execution:
            self._execution.next()
        else:
            raise WorkflowNotInited()

    def to_definition_json(self) -> TransformType:
        steps_json = []
        for step in self.steps:
            steps_json.append(step.to_definition_json())
        data_placeholders, data_dict, placeholders = self._extra_data_and_placeholders()

        result = {
            "name": self.name,
            "description": self.desc,
            "steps": steps_json,
            "data_requirements": self._process_global_data_to_definition_json(global_data=data_placeholders),
            "data": self._process_global_data_to_definition_json(global_data=data_dict),
            "parameters": self._process_global_data_to_definition_json(global_data=placeholders),
            "storages": self._storage_management.to_definition_json() if self._storage_management else [],
            "policy": self.policy.to_definition_json() if self.policy else {},
        }

        if self.subgraphs is not None:
            subgraphs_json = []
            for subgraph in self.subgraphs:
                subgraphs_json.append(subgraph.to_definition_json())
            result["sub_graphs"] = subgraphs_json

        if self.extend:
            result["extend"] = self.extend

        assets = []
        for step_json in result["steps"]:
            if step_json.get("type") == StepTypeEnum.MODEL.value:
                Workflow._convert_model_json(step_json, result["data"], assets)

        if assets:
            result["assets"] = assets

        return result

    def _process_global_data_to_definition_json(self, global_data):
        result_json = []
        for name, data in global_data.items():
            definition_json = data.to_definition_json()
            used_steps = []
            for step in self.steps:
                if isinstance(data, AbstractData) and name in step.data_:
                    used_steps.append(step.name)
                if isinstance(data, AbstractDataPlaceholders) and name in step.data_placeholders:
                    used_steps.append(step.name)
                if isinstance(data, Placeholder) and name in step.placeholders:
                    used_steps.append(step.name)
            definition_json["used_steps"] = used_steps
            result_json.append(definition_json)
        return result_json

    def _create_dag_graph(self):
        """
        Create a dag graph according workflow steps
        Returns (Boolean, dag, message):

        """
        dag = Dag()
        for step in self.steps:
            is_success, message = dag.add_step(step.name, step.depend_step_names)
            if not is_success:
                return is_success, dag, message
        return True, dag, "success"

    def _create_dag_with_subgraph(self):
        """
        Create a dag with subgraph
        Returns (Boolean, dag, message):

        """
        step_to_subgraph_name_map = dict()
        for subgraph in self.subgraphs:
            for step in subgraph.steps:
                step_to_subgraph_name_map[step.name] = subgraph.name

        step_depends_map = dict()
        for s in self.steps:
            step = copy.deepcopy(s)
            for depend_step in step.depend_steps:
                if step_to_subgraph_name_map.get(depend_step.name) is not None:
                    depend_step.name = step_to_subgraph_name_map.get(depend_step.name)

            subgraph_name = step_to_subgraph_name_map.get(step.name)
            if subgraph_name is None:
                step_depends_map[step.name] = step.depend_steps
            else:
                subgraph_depends = step_depends_map.get(subgraph_name)
                if subgraph_depends is None:
                    step_depends_map[subgraph_name] = step.depend_steps
                else:
                    subgraph_depends.extend(step.depend_steps)
                    step_depends_map[subgraph_name] = subgraph_depends
        dag = Dag()
        for step_name, depends in step_depends_map.items():
            dep_step_names = _trim_depend_steps(step_name, depends)
            is_success, message = dag.add_step(step_name, dep_step_names)
            if not is_success:
                return is_success, dag, message
        return True, dag, "success"

    def set_placeholder(self, name, value):
        return self._execution.set_placeholder(name, value)

    def set_data(self, name, data):
        return self._execution.set_data(name, data)

    @classmethod
    def create_signal_handlers(cls, exit_flag):
        def signal_handler(sig, frame):
            logging.info("signal %s detected", sig)
            exit_flag.set()

        signal.signal(signal.SIGINT, signal_handler)
        signal.signal(signal.SIGTERM, signal_handler)

    def prepare_experiment_snapshot(self, take_snapshot, experiment_id, snapshot_path, execution_id):
        if not take_snapshot:
            return
        if snapshot_path:
            experiment_snapshot = Path(snapshot_path)
        elif experiment_id:
            experiment_snapshot = Path.cwd() / experiment_id
        else:
            raise RuntimeError("both experiment id and snapshot path is empty")
        experiment_snapshot.mkdir(parents=True, exist_ok=True)
        experiment_snapshot_path = experiment_snapshot / execution_id
        experiment_snapshot_path.mkdir(parents=True, exist_ok=True)
        wf_file = experiment_snapshot_path / "workflow.json"
        wf_file.write_text(json.dumps(self.to_definition_json(), indent=4))
        return experiment_snapshot_path

    @staticmethod
    def _check_names(steps):
        """
        Check names of the Placeholder, DataPlaceholder and Data ars unique
        Args:
            steps (list[Step]): steps list

        Returns:

        """
        placeholders = PlaceholderDict()
        data_placeholders = DataPlaceholdersDict()
        data = DataDict()
        for step in steps:
            data_placeholders.merge(step.inputs.data_placeholders)
            data.merge(step.inputs.data_)
            placeholders.merge(step.placeholders)

    @staticmethod
    def _check_name_valid_with_condition_step(steps):
        steps_name = {step.name for step in steps}
        for step in steps:
            if not isinstance(step, ConditionStep):
                continue
            if step.if_then_steps:
                Workflow._check_if_or_else_then_steps(step, step.if_then_steps, steps_name)
            if step.else_then_steps:
                Workflow._check_if_or_else_then_steps(step, step.else_then_steps, steps_name)

    @staticmethod
    def _check_if_or_else_then_steps(condition_step, if_or_else_then_steps, all_step_names):
        if condition_step.name in if_or_else_then_steps:
            raise ValueError(
                'ConditionStep name {} can not be in the if_then_steps or else_then_steps'.format(condition_step.name))
        if set(if_or_else_then_steps).difference(all_step_names):
            raise ValueError(
                'The steps named {} are not defined'.format(set(if_or_else_then_steps).difference(all_step_names)))

    def _check_policy(self):
        self.policy.check()


class WorkflowExecution:

    def __init__(self, steps, experiment_id, dag, debug=False, exit_flag=None, take_snapshot=True, snapshot_path=None,
                 storage_management=None):
        self.debug = debug
        self.steps = steps
        if not experiment_id:
            experiment_id = str(uuid.uuid1())
        self.experiment_id = experiment_id
        self._take_snapshot = take_snapshot
        self.snapshot_path = None
        self._storage_management = storage_management
        if self._take_snapshot:
            self._init_snapshot_path(snapshot_path)
        self.placeholders = PlaceholderDict()
        self.data_placeholders = DataPlaceholdersDict()
        self.dag = dag
        self._state = WorkflowState.Init
        self.state_timeline = StateTimeline(WorkflowState.Init)
        self.exit_flag = exit_flag
        for step in steps:
            self.placeholders.merge(step.placeholders)
            self.data_placeholders.merge(step.data_placeholders)

    def _init_snapshot_path(self, snapshot_path):
        if snapshot_path:
            self.snapshot_path = snapshot_path
        else:
            self.snapshot_path = Path.cwd() / self.experiment_id / str(uuid.uuid1())

    def set_placeholder(self, name, value):
        if name not in self.placeholders:
            raise KeyError
        self.placeholders[name].set_value(value)

    def set_data(self, name, data):
        if name not in self.data_placeholders:
            raise KeyError
        self.data_placeholders[name].set_data(data)

    def need_input(self):
        for step in self.steps:
            is_ready, message = step.is_ready()
            if step.state == StepState.WaitInputs and not is_ready:
                step.wait_input()
                return True
        return False

    @property
    def state(self):
        return self._state

    def _set_steps_state_for_cache(self, state: StepState):
        """
        Get the dependencies of the steps and set the status to completed if they are not in the steps to be run,
        for the case of running partial steps
        Args:
            state (StepState): target step state

        Returns:

        """
        step_names = set()
        for step in self.steps:
            step_names.add(step.name)

        for step in self.steps:
            depend_steps = step.depend_steps
            if not depend_steps:
                continue
            for depend_step in depend_steps:
                if depend_step.name in step_names:
                    continue
                depend_step.set_state(state)

    def _set_state(self, state: WorkflowState):
        """
        Set the status of the workflow and record the status change timeline
        Args:
            state (WorkflowState): workflow state

        Returns:

        """
        t = round(time.time() * 1000)
        if self._state != state:
            logging.info("workflow status changes from %s to %s.", self._state.value[0], state.value[0])
        self._state = state
        self.state_timeline.add_new_state(state, t)

    def run(self):
        """
        Start to run part steps
        1. get the dependencies of steps, and if it is not in the steps to be run, set the status to completed
        2. while true:
            a.step execution logic
                whether the state of the step is init
                whether the state of the depend step is completed
            b. update step state
            c. update workflow state
            d. if step state changes： save
            e. if workflow state changes：save
            f. failure policy
        3.save: workflow and step
        Returns:

        """
        if not self.steps:
            return
        if self._take_snapshot:
            (self.snapshot_path / "steps").mkdir(parents=True)
        self._set_state(WorkflowState.Running)
        self._set_steps_state_for_cache(StepState.Completed)
        if not self.debug:
            self.next()
        else:
            step_state_colors = self.get_step_state_colors(self.steps)
            view_dag(self.dag, step_state_colors)

    def next(self):
        """
        Used in debug mode for single step debugging
        Returns:

        """
        final_state = [WorkflowState.Completed, WorkflowState.Stopped, WorkflowState.Failed]
        while not self.exit_flag or not self.exit_flag.is_set():
            if self.state in final_state:
                logging.info("workflow running has ended. status: %s", self.state.value[0])
                break
            if self.debug and self.need_input():
                break
            self._run_steps()
            is_change = self._update_steps_state()
            self._update_workflow_state()
            if self.debug and is_change:
                step_state_colors = self.get_step_state_colors(self.steps)
                view_dag(self.dag, step_state_colors)
                break
            time.sleep(1)

        if self.exit_flag and self.exit_flag.is_set():
            logging.info("stopping workflow...")
            self._stop_steps()
            time.sleep(3)
            self._update_workflow_state()
            # Wait for a period of time, and set the status of workflow to Stopped
            if self.state not in [WorkflowState.Completed, WorkflowState.Failed]:
                self._set_state(WorkflowState.Stopped)
            logging.info("workflow stopped.")

    def _run_steps(self):
        """
        Run the steps that can be run by judging the status of the step
        Returns:

        """
        for step in self.steps:
            if step.state not in (StepState.Init, StepState.WaitInputs):
                continue
            is_success = True
            if step.depend_steps is not None:
                for depend_step in step.depend_steps:
                    if depend_step.state not in (StepState.Completed, StepState.Skipped):
                        is_success = False
                        break

            if not is_success:
                continue
            step_snapshot_path = self.snapshot_path / "steps" / step.name if self._take_snapshot else None
            step.start(self.debug,
                       take_snapshot=self._take_snapshot,
                       snapshot_path=step_snapshot_path)
            if isinstance(step, ConditionStep):
                self._process_skip_steps(step)

    def _stop_steps(self):
        for step in self.steps:
            step.stop()

    def _process_skip_steps(self, step):
        skip_steps = step.get_skip_steps()
        if not skip_steps:
            return
        for single_step in self.steps:
            if single_step.name not in skip_steps:
                continue
            if single_step.state != StepState.Init:
                raise Exception("The step {} is not allowed to skip, "
                                "please make sure that this step has not been run".format(single_step.name))
            single_step.set_state(StepState.Skipped)
            single_step.set_to_skip()

    @classmethod
    def get_step_states(cls, steps: Sequence[Step]):
        """
        Get step state
        Args:
            steps (list[Step]): steps list

        Returns (StepState): step state

        """
        states = {}
        for step in steps:
            states[step.name] = step.state
        return states

    @classmethod
    def get_step_state_colors(cls, steps: Sequence[Step]):
        """
        Get step state color
        Args:
            steps (list[Step]): steps list

        Returns (dict): step name -> step state color

        """
        states = {}
        for step in steps:
            states[step.name] = step.state.value[1]
        return states

    def _update_steps_state(self) -> bool:
        # Return True if step state changes, otherwise returns False
        # The step of the init or stopped state does not need to be updated
        running_state = [StepState.Created, StepState.Pending, StepState.Running, StepState.Stopping]
        is_change = False
        for step in self.steps:
            if step.state in running_state:
                old_state = step.state
                step.update_instance_state()
                if old_state != step.state:
                    is_change = True
            if step.state == StepState.Completed:
                step.dump_output_data()
        return is_change

    def _update_workflow_state(self):
        """
        Update workflow state according to steps state
        Returns:

        """
        workflow_state_counts = dict()
        for step in self.steps:
            step_to_workflow_state = WorkflowStateMapping.get_state(step.state)
            workflow_state_counts[step_to_workflow_state] = workflow_state_counts.get(step_to_workflow_state, 0) + 1
        if WorkflowState.Failed in workflow_state_counts.keys():
            self._set_state(WorkflowState.Failed)
            self._take_config_snapshot()
            return
        if WorkflowState.Completed in workflow_state_counts.keys() and \
                workflow_state_counts[WorkflowState.Completed] == len(self.steps):
            self._set_state(WorkflowState.Completed)
            self._take_config_snapshot()
            return
        if not self.exit_flag or not self.exit_flag.is_set():
            if WorkflowState.Stopped in workflow_state_counts.keys():
                logging.error("workflow has failed step.")
                self._set_state(WorkflowState.Failed)
                return
        return

    def _take_config_snapshot(self):
        if not self._take_snapshot:
            return
        config_logging_path = self.snapshot_path / "config"
        config_logging_path.mkdir()
        (config_logging_path / "parameters.json").write_text(
            json.dumps(self.placeholders.get_snapshot(), indent=JSON_INDENT_LEN))
        (config_logging_path / "data_requirements.json").write_text(
            json.dumps(self.data_placeholders.get_snapshot(), indent=JSON_INDENT_LEN)
        )
        if self._storage_management:
            (config_logging_path / "storages.json").write_text(
                json.dumps(self._storage_management.get_snapshot(), indent=JSON_INDENT_LEN)
            )
