import logging
from logging.config import dictConfig
from logging.config import fileConfig
import os


def _reset_logger():
    logger = logging.getLogger()
    if logger and hasattr(logger, 'handlers'):
        while logger.handlers:
            logger.handlers.pop()


def setup_logging(logging_config=None,
                  default_logging_level=logging.INFO,
                  env_logging_path='WORKFLOW_LOG_CFG',
                  is_reset=False):
    """
    Set the configuration of logging, which can be set through dictConfig or fileConfig;
    dictconfig can override the content of fileconfig; if both are none, set the default handler
    Args:
        logging_config (dict): dictConfig
        default_logging_level (int): logging level, default is logging.INFO
        env_logging_path (str): logging path, default is 'WORKFLOW_LOG_CFG'
        is_reset (bool): config is whether need reset, default is False

    Returns:

    """
    if is_reset:
        _reset_logger()
    if logging_config:
        dictConfig(logging_config)
        return

    logging_config_filename = os.getenv(env_logging_path, None)
    if logging_config is None and logging_config_filename and os.path.exists(logging_config_filename):
        fileConfig(logging_config_filename)
        return
    logging.basicConfig(level=default_logging_level,
                        format='%(asctime)s %(name)-12s %(levelname)-8s in %(module)s: %(message)s')


if __name__ == "__main__":
    log_config = dict(
        version=1,
        formatters={
            'f': {'format': '%(asctime)s %(name)-12s %(levelname)-8s %(message)s'}
        },
        handlers={
            'h': {'class': 'logging.StreamHandler',
                  'formatter': 'f',
                  'level': logging.DEBUG}
        },
        root={
            'handlers': ['h'],
            'level': logging.DEBUG,
        },
    )
    # set by dict
    setup_logging(log_config)
    logging.debug('often makes a very good meal of %s', 'visiting tourists')
    # set default value
    setup_logging()
    logging.getLogger().info('often makes a very good meal of %s', 'visiting tourists')
    logging.getLogger().info('often makes a very good meal of %s', 'visiting tourists')

    # set by file
    os.environ['WORKFLOW_LOG_CFG'] = ".\\logging_config.ini"
    setup_logging()
    logging.getLogger().debug('often makes a very good meal of %s', 'visiting tourists')
