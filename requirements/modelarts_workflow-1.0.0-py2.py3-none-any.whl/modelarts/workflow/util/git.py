import os
import sys


class GitInfo(object):

    def __init__(self, work_dir):
        path = work_dir
        if os.path.isfile(work_dir):
            path = os.path.dirname(work_dir)
        try:
            import git
        except ImportError:
            self.repo = None
            return
        try:
            self.repo = git.Repo(path, search_parent_directories=True)
        except git.GitError:
            self.repo = None

    def get_commit_id(self):
        if self.repo is None:
            return None
        return self.repo.head.commit.hexsha

    def get_repo_url(self):
        if self.repo is None:
            return None
        remote_urls = [remote.url for remote in self.repo.remotes]
        if len(remote_urls) == 0:
            return None
        return remote_urls[0]

    def get_active_branch(self):
        if self.repo is None:
            return None
        return self.repo.active_branch.path


def _get_main_file():
    if len(sys.argv) > 0:
        return sys.argv[0]
    return None


def get_source_version():
    main_file = _get_main_file()
    if main_file is not None:
        git_info = GitInfo(main_file)
        return git_info.get_commit_id()
    return None


def get_source_repo_url():
    main_file = _get_main_file()
    if main_file is not None:
        git_info = GitInfo(main_file)
        return git_info.get_repo_url()
    return None


def get_source_branch():
    main_file = _get_main_file()
    if main_file is not None:
        git_info = GitInfo(main_file)
        branch = git_info.get_active_branch()
        if branch is None:
            return branch
        pattern = "refs/heads/"
        if not branch.startswith(pattern):
            return None
        return branch[len(pattern):]
    return None
