import ast
import uuid

from modelarts.workflow.core.entities import TransformType
from modelarts.workflow.core.data import (
    AbstractData,
    AbstractDataPlaceholders,
)


SWR_IMAGE_DATA_TYPE = "swr"


class SWRImage(AbstractData):
    """
    A class for representing the container image in the SoftWare Repository for Container
    """

    def __init__(self, swr_path):
        """

        Args:
            swr_path: The container image path in the SoftWare Repository for Container
        """
        self._check_init(swr_path)
        super(SWRImage, self).__init__(name=uuid.uuid4().hex)
        self.swr_path = swr_path

    def get_snapshot(self) -> TransformType:
        return {
            "swr_url": self.swr_path
        }

    def to_definition_json(self) -> TransformType:
        result = {
            "name": self.name,
            "type": "swr",
            "value": {
                "swr_url": self.swr_path
            }
        }
        return result

    def _set_name(self, name):
        self.name = name

    @staticmethod
    def _check_init(swr_path):
        if not isinstance(swr_path, str):
            raise TypeError('The type of swr_path must be str. But provided: {}'.format(type(swr_path)))

    def type(self):
        return SWR_IMAGE_DATA_TYPE


class SWRImagePlaceholder(AbstractDataPlaceholders):
    """
    A SWRImagePlaceholder for a SWRImage that will be always fed.

    **Important**: Its Instance Attributes '_swr_path' must be fed using the `set_data` instance method.

    """

    def __init__(self, name, delay=False):
        """

        Args:
            name (str): the name of the SWRImagePlaceholder
            delay (bool): represent whether the SWRImagePlaceholder is input at runtime, default False
        """
        super(SWRImagePlaceholder, self).__init__(name)
        self.delay = delay
        self._swr_path = None

    def set_data(self, string):
        swr_param = ast.literal_eval(string)
        self._verify_format(swr_param)
        self._swr_path = SWRImage(swr_param.get("swr_path"))

    def to_definition_json(self) -> TransformType:
        result = {
            "name": self.name,
            "type": "swr",
            "delay": self.delay
        }
        return result

    def __repr__(self):
        return "SWRImagePlaceholder <{}> need to be set".format(self.name)

    @property
    def data(self):
        return self._swr_path

    def consume(self):
        return self._swr_path

    def get_data_from_command_line(self):
        string = self._get_input_data()
        return self.set_data(string)

    def _get_input_data(self):
        swr_input_format = "{'swr_path': 'swr.***.com/***/***:***'}"
        param = input('Please feed the SWRImagePlaceholder "{}" in the following format: "{}" \n'.format(self.name,
                                                                                                    swr_input_format))
        return param

    @staticmethod
    def _verify_format(swr_param):
        if not isinstance(swr_param, dict):
            raise TypeError("The value type fed to the SWRImagePlaceholder must be dict. But provided type: {}".format(
                type(swr_param)))
        swr_path = swr_param.get("swr_path")
        if not swr_path:
            raise KeyError("'swr_path' key is not found in value:{} fed to the SWRImagePlaceholder".format(swr_param))
        if not isinstance(swr_path, str):
            raise TypeError("The type of swr_path of value fed to the SWRImagePlaceholder must be str. But "
                            "provided type: {}".format(type(swr_path)))

    def is_set(self):
        return self._swr_path is not None

    def type(self):
        return SWR_IMAGE_DATA_TYPE
