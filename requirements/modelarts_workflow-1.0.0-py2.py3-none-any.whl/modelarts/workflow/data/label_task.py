import ast
import uuid
import logging
from enum import Enum

from modelarts.workflow.core.entities import TransformType
from modelarts.workflow.core.data import (
    AbstractDataConsumption,
    AbstractData,
    AbstractDataPlaceholders,
)
from modelarts.workflow.client.dataset_client import DatasetClient
from modelarts.workflow.core.data import AbstractOutputConfig


LABEL_TASK_DATA_TYPE = "label_task"


class LabelTaskTypeEnum(Enum):
    """
    Label task type enum
    """
    IMAGE_CLASSIFICATION = 0
    OBJECT_DETECTION = 1
    IMAGE_SEGMENTATION = 3
    TEXT_CLASSIFICATION = 100
    NAMED_ENTITY_RECOGNITION = 101
    TEXT_TRIPLE = 102
    AUDIO_CLASSIFICATION = 200
    SPEECH_CONTENT = 201
    SPEECH_SEGMENTATION = 202
    TABLE = 400
    VIDEO_ANNOTATION = 600


class LabelTask(AbstractData):
    """
    Represents a labeling task
    """

    def __init__(self, dataset_name, task_name):
        """

        Args:
           dataset_name (str): dataset name
           task_name (str): label task name
        """
        super(LabelTask, self).__init__(name=uuid.uuid4().hex)
        self.dataset_name = dataset_name
        self.task_name = task_name
        self._dataset_id = None
        self._task_id = None

    def fill_dataset_and_task_id(self, dataset_client):
        logging.debug("The LabelTask is getting ID information by dataset name %s and task name %s",
                      self.dataset_name, self.task_name)
        if not isinstance(dataset_client, DatasetClient):
            raise TypeError('The dataset_client type must be DatasetClient. But provided: {}'.format(
                type(dataset_client)))
        if self.dataset_id is None:
            self.dataset_id = dataset_client.get_dataset_id(self.dataset_name)
        if self.task_id is None:
            self.task_id = dataset_client.get_label_task_id(self.dataset_id, self.task_name)

    def to_definition_json(self) -> TransformType:
        if self.dataset_id is None or self.task_id is None:
            raise ValueError("The dataset ID or task ID is None")
        result = {
            "name": self.name,
            "type": "label_task",
            "value": {
                "dataset_id": self.dataset_id,
                "task_id": self.task_id,
            }
        }
        return result

    def get_snapshot(self) -> TransformType:
        """

        :return: TransformType
        """
        return {
            "dataset_name": self.dataset_name,
            "task_name": self.task_name,
            "dataset_id": self.dataset_id if self.dataset_id else "",
            "task_id": self.task_id if self.task_id else "",
        }

    @property
    def dataset_id(self):
        return self._dataset_id

    @dataset_id.setter
    def dataset_id(self, dataset_id):
        self._dataset_id = dataset_id

    @property
    def task_id(self):
        return self._task_id

    @task_id.setter
    def task_id(self, task_id):
        self._task_id = task_id

    def type(self):
        return LABEL_TASK_DATA_TYPE


class LabelTaskPlaceholder(AbstractDataPlaceholders):

    def __init__(self, name, task_type=None, delay=False):
        """

        Args:
            name (str): the name of LabelTaskPlaceholder
            task_type (LabelTaskTypeEnum): the label task type
            delay (bool): represent whether the LabelTaskPlaceholder is input at runtime, default False
        """
        super().__init__(name)
        self.task_type = task_type
        self.delay = delay
        self._label_task = None
        self._dataset_client = None

    @property
    def dataset_client(self):
        return self._dataset_client

    @dataset_client.setter
    def dataset_client(self, dataset_client):
        self._dataset_client = dataset_client

    def _get_condition_json(self) -> TransformType:
        result = [{
            "attribute": "task_type",
            "operator": "equal",
            "value": self.task_type.value,
        }]
        return result

    def to_definition_json(self) -> TransformType:
        result = {
            "name": self.name,
            "type": "label_task",
            "delay": self.delay
        }
        if self.task_type is not None:
            result["conditions"] = self._get_condition_json()
        return result

    def set_data(self, data):
        if self.dataset_client is None:
            raise ValueError('The dataset_client is None of LabelTaskPlaceholder {}'.format(self.name))
        data.fill_dataset_and_task_id(dataset_client=self.dataset_client)
        self._label_task = data

    def __repr__(self):
        return "LabelTask placeholder <{}> need to be set".format(self.name)

    @property
    def data(self):
        return self._label_task

    def consume(self):
        return self._label_task

    def get_data_from_command_line(self):
        input_format = "{'dataset_name': '******', 'task_name': '******'}"
        param = input(
            "Choose LabelTask placeholder <{}>, input format is <{}>: ".format(self.name, input_format))
        task_param = ast.literal_eval(param)
        dataset_name = task_param.get("dataset_name")
        if dataset_name is None:
            raise KeyError("The LabelTask placeholder <{}> has no dataset_name input, "
                           "please input in the correct format".format(self.name))
        task_name = task_param.get("task_name")
        if task_name is None:
            raise KeyError("The LabelTask placeholder <{}> has no task_name input, "
                           "please input in the correct format".format(self.name))
        return self.set_data(LabelTask(dataset_name, task_name))

    def is_set(self) -> bool:
        return self._label_task is not None

    def type(self):
        return LABEL_TASK_DATA_TYPE


class LabelTaskConfig(AbstractOutputConfig):
    """
    """

    def __init__(self):
        super(LabelTaskConfig, self).__init__()
        self._data = None

    @property
    def data(self):
        return self._data

    @data.setter
    def data(self, label_task):
        self._data = label_task

    def data_consumption(self, step_name, output_name):
        return LabelTaskConsumption(self, step_name, output_name)


class LabelTaskConsumption(AbstractDataConsumption):

    def __init__(self, config, step_name, output_name):
        super(LabelTaskConsumption, self).__init__(config=config, step_name=step_name, output_name=output_name)

    def consume(self) -> AbstractData:
        return self.config.data

    def type(self):
        return LABEL_TASK_DATA_TYPE
