from modelarts.workflow.core.data import AbstractDataConsumption, AbstractInputData


class DataConsumptionSelector(AbstractInputData):
    """
    Select a data from data_list as output, data_list only support AbstractDataConsumption type
    """
    def __init__(self, data_list):
        """
        Args:
            data_list (list[AbstractDataConsumption]): input AbstractDataConsumption list
        """
        DataConsumptionSelector._check_data_list(data_list)
        self.data_list = data_list

    def consume(self):
        for data in self.data_list:
            if not data.config.is_skipped:
                return data.consume()
        raise Exception("DataConsumptionSelector all input data are None")

    def type(self):
        return self.data_list[0].type()

    @staticmethod
    def _check_data_list(data_list):
        if not isinstance(data_list, list):
            raise TypeError('data_list only support list type, but provided: {}'.format(type(data_list)))
        data_type = None
        for data in data_list:
            if not isinstance(data, AbstractDataConsumption):
                raise TypeError('only support AbstractDataConsumption type, but provided: {}'.format(type(data)))
            if not data_type:
                data_type = data.type()
                continue
            if data_type != data.type():
                raise TypeError('data_list only supports the same data type')

    def is_need_consume(self):
        return True

    def to_definition_json(self):
        pass

    def ref(self):
        ref_list = ['{}/{}'.format(data.step_name, data.output_name) for data in self.data_list]
        return "$ref/consumptions/{}".format('[{}]'.format(','.join(ref_list)))
