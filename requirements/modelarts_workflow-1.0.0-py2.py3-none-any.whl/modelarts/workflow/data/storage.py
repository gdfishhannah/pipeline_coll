import collections
import logging
from typing import Sequence
from enum import Enum

from modelarts.workflow.client.obs_client import ObsClient
from modelarts.workflow.core.entities import Entity, TransformType
from modelarts.workflow.util.validators import check_name, check_description


class StorageTypeEnum(Enum):
    """
    Storage type enum
    """
    OBS = "obs"


class Storage(Entity):
    """
    Unified storage object
    """

    def __init__(self,
                 name,
                 title='',
                 description='',
                 storage_type=StorageTypeEnum.OBS,
                 default=None,
                 directory='',
                 with_execution_id=False,
                 create_dir=False,
                 parent=None):
        """

        Args:
            name (str): The name of storage, and must be unique
            title (str): The title message of Storage
            description (str): The description message
            storage_type (StorageTypeEnum): The storage type
            default (str): The default path value, which is mainly used for run locally
            directory (str): directory path need to be joined
            with_execution_id (bool): Whether the uniform storage path needs to be spliced with execution_id
            create_dir (bool): Whether create the dir for user
            parent (Storage): the parent storage
        """
        check_name(name)
        check_description(description)
        self.name = name
        self.title = title or name
        self.description = description
        self.type = storage_type
        self.default = default
        self.directory = directory
        self.with_execution_id = with_execution_id
        self.create_dir = create_dir
        self.parent = parent
        self._path = default or None
        self._children = []
        self._storage_consumption_list = None

        if self.parent is not None:
            self.parent.add_children(self)

    def join(self, directory, with_execution_id=None, create_dir=None):
        """
        Join the directory and return a new storage
        Args:
            directory (str): directory path need to be joined
            with_execution_id (bool): Whether the uniform storage path needs to be spliced with execution_id
            create_dir (bool): Whether create the dir for user

        Returns (Storage): A new Storage

        """
        if not directory:
            raise ValueError("the directory can not be empty")
        if self.directory:
            directory = '{}/{}'.format(self.directory.rstrip("/"), directory.lstrip("/"))
        if with_execution_id is None:
            with_execution_id = self.with_execution_id
        if create_dir is None:
            create_dir = self.create_dir
        return Storage(name=self.name,
                       storage_type=self.type,
                       default=self.default,
                       directory=directory,
                       with_execution_id=self.with_execution_id or with_execution_id,
                       create_dir=create_dir,
                       parent=self)

    def add_children(self, child_storage):
        self._children.append(child_storage)

    def get_children_recursively(self):
        children_list = []
        for c in self._children:
            children_list.append(c)
            children_list.extend(c.get_children_recursively())

        return children_list

    @property
    def storage_consumption_list(self):
        if self._storage_consumption_list is None:
            if self.parent is not None:
                raise ValueError('only root storage is allowed to get consumption list')

            self._storage_consumption_list = [self] + self.get_children_recursively()

        return self._storage_consumption_list

    def ref(self):
        if self.directory:
            return '$ref/storages(with_execution_id={},create_dir={})/{}/{}'.format(
                self.with_execution_id, self.create_dir, self.name, self.directory.lstrip("/"))
        else:
            return '$ref/storages(with_execution_id={},create_dir={})/{}'.format(
                self.with_execution_id, self.create_dir, self.name)

    def to_definition_json(self):
        result = {
            "name": self.name,
            "type": self.type.value,
            "title": self.title,
            "description": self.description,
        }
        if self.path is not None:
            result["path"] = self.path
        return result

    def get_snapshot(self) -> TransformType:
        return {
            "name": self.name,
            "type": self.type.value,
            "title": self.title,
            "description": self.description,
            "path": "" if self.path is None else self.path
        }

    @property
    def path(self):
        return self._path

    @path.setter
    def path(self, path):
        self._path = path

    def get_data_from_command_line(self):
        """
        Get input data from the command line
        Returns:

        """
        if self.path is not None:
            return
        path = input('Please input the path of Storage "{}":'.format(self.name))
        self._path = path

    def __repr__(self):
        return 'Storage(name={}, type={})'.format(self.name, self.type)


class InputStorage(Storage):
    """
    InputStorage inherits from Storage and is only used for path splicing
    """
    def __init__(self,
                 name,
                 title='',
                 description='',
                 storage_type=StorageTypeEnum.OBS,
                 default=None,
                 directory="",
                 parent=None,
                 ):
        super(InputStorage, self).__init__(
            name=name,
            title=title,
            description=description,
            storage_type=storage_type,
            default=default,
            directory=directory,
            with_execution_id=False,
            create_dir=False,
            parent=parent
        )

    def join(self, directory, with_execution_id=False, create_dir=False):
        if not directory:
            raise ValueError("the directory can not be empty")
        if self.directory:
            directory = '{}/{}'.format(self.directory.rstrip("/"), directory.lstrip("/"))
        return InputStorage(
            name=self.name,
            storage_type=self.type,
            default=self.default,
            directory=directory,
            parent=self
        )


class OutputStorage(Storage):
    """
    OutputStorage inherits from Storage and is only used to create directories
    """
    def __init__(self,
                 name,
                 title='',
                 description='',
                 storage_type=StorageTypeEnum.OBS,
                 default=None,
                 directory="",
                 parent=None,
                 create_dir=True,
                 ):
        super(OutputStorage, self).__init__(
            name=name,
            title=title,
            description=description,
            storage_type=storage_type,
            default=default,
            directory=directory,
            with_execution_id=True,
            create_dir=create_dir,
            parent=parent
        )

    def join(self, directory, with_execution_id=True, create_dir=True):
        if not directory:
            raise ValueError("the directory can not be empty")
        if self.directory:
            directory = '{}/{}'.format(self.directory.rstrip("/"), directory.lstrip("/"))
        return OutputStorage(
            name=self.name,
            storage_type=self.type,
            default=self.default,
            directory=directory,
            parent=self,
            create_dir=create_dir
        )


class DuplicateStorage(Exception):
    pass


class StorageManagement(collections.UserDict):
    """
    Class for unified management of Storage
    """
    def __init__(self, session, storages):
        """

        Args:
            session (Session): building interactions with cloud service.
            storages (Union[Storage, Sequence[Storage]]): A Storage object or collection of Storage objects
        """
        super(StorageManagement, self).__init__()
        self.obs_client = ObsClient(session)
        if not isinstance(storages, Sequence):
            storages = [storages]
        for storage in storages:
            self.add_storage(storage)

    def add_storage(self, storage):
        """
        Add a new Storage object and verify whether the name is duplicated
        Returns:

        """
        if not storage:
            return
        if storage.name in self:
            raise DuplicateStorage('Storage {} is repeated declared'.format(storage.name))
        self[storage.name] = storage

    def to_definition_json(self):
        return [storage.to_definition_json() for storage in self.values()]

    def register_directories(self, run_id):
        """
        Create directories for all storages
        Args:
            run_id (str): run ID, and randomly generated every time the workflow runs

        Returns:

        """
        for storage in self.values():
            if not storage.path:
                storage.get_data_from_command_line()
            if storage.type == StorageTypeEnum.OBS:
                self._register_for_obs_storage(storage, run_id)
            else:
                raise TypeError('Storage only supports OBS type. But provided: {}'.format(storage.type))

    def _register_for_obs_storage(self, storage, run_id):
        storage_root_path = storage.path
        for storage_consumption in storage.storage_consumption_list:
            storage_consumption.path = StorageManagement._get_format_path(
                with_execution_id=storage_consumption.with_execution_id,
                create_dir=storage_consumption.create_dir,
                storage_path=storage_root_path,
                directory=storage_consumption.directory,
                run_id=run_id
            )
            if storage_consumption.create_dir:
                bucket, object_key = StorageManagement._format_obs_url(storage_consumption.path)
                logging.info("Start to create a directory '%s' under the bucket path '%s'", object_key, bucket)
                self.obs_client.create_directory(bucket, object_key)

    @staticmethod
    def _get_format_path(with_execution_id, create_dir, storage_path, directory, run_id):
        url_path = storage_path
        if with_execution_id:
            url_path = '/{}/{}'.format(url_path.strip("/"), run_id)
        if directory:
            url_path = '/{}/{}'.format(url_path.strip("/"), directory.lstrip("/"))
        if create_dir and not url_path.endswith("/"):
            url_path = url_path + "/"
        return url_path

    @staticmethod
    def _format_obs_url(path):
        if path.startswith("obs://"):
            path = path[len("obs://"):]
        if path.startswith("/"):
            path = path[1:]
        url_parts = path.split("/")
        bucket_name = url_parts[0]
        if len(url_parts) == 1:
            object_key = ''
        else:
            object_key = '/'.join(url_parts[1:])
        return bucket_name, object_key

    def get_snapshot(self) -> TransformType:
        return [storage.get_snapshot() for storage in self.values()]
