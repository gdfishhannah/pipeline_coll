import ast
import uuid

from modelarts.workflow.core.placeholder import Placeholder
from modelarts.workflow.core.entities import TransformType
from modelarts.workflow.core.data import (
    AbstractDataConsumption,
    AbstractData,
    AbstractDataPlaceholders,
)
from modelarts.workflow.data.storage import Storage
from modelarts.workflow.core.data import AbstractOutputConfig


OBS_DATA_TYPE = "obs"


class OBSPath(AbstractData):
    def __init__(self, obs_path):
        """

        Args:
            obs_path (Union[str, Storage]): obs path
        """
        super(OBSPath, self).__init__(name=uuid.uuid4().hex)
        self.obs_path = obs_path

    def get_snapshot(self) -> TransformType:
        return {
            "obs_url": self.obs_path
        }

    def to_definition_json(self) -> TransformType:
        result = {
            "name": self.name,
            "type": "obs",
            "value": {
                "obs_url": self.obs_path.ref() if isinstance(self.obs_path, Storage) else self.obs_path
            }
        }
        return result

    def _set_name(self, name):
        self.name = name

    def is_placeholder(self):
        if isinstance(self.obs_path, Storage):
            return True
        return False

    def type(self):
        return OBS_DATA_TYPE

    def is_need_consume(self):
        if isinstance(self.obs_path, Storage):
            return True
        return False


class OBSPlaceholder(AbstractDataPlaceholders):

    def __init__(self, name, object_type, delay=False, default=None):
        """

        Args:
            name (str): the name of the OBSPlaceholder
            object_type (str): the object type, only "file" and "directory" are supported
            delay (bool): represent whether the OBSPlaceholder is input at runtime, default False
            default(OBSPath): default value
        """
        OBSPlaceholder._check_object_type(object_type)
        super().__init__(name)
        self.object_type = object_type
        self.delay = delay
        if default is not None and (not isinstance(default, OBSPath) or not isinstance(default.obs_path, str)):
            raise TypeError("The type of default value must be OBSPath, "
                            "and the type of OBSPath.obs_path must be string")
        self._default = default
        self._obs_path = None

    def set_data(self, data):
        self._obs_path = data

    def _get_condition_json(self) -> TransformType:
        result = [{
            "attribute": "object_type",
            "operator": "equal",
            "value": self.object_type,
        }]
        return result

    def to_definition_json(self) -> TransformType:
        result = {
            "name": self.name,
            "type": "obs",
            "delay": self.delay,
            "conditions": self._get_condition_json()
        }
        if self._default:
            obs_path = self._default.obs_path
            result["value"] = {"obs_url": obs_path}

        return result

    def __repr__(self):
        return "OBSPath placeholder <{}> need to be set".format(self.name)

    @property
    def data(self):
        return self._obs_path

    def consume(self):
        return self._obs_path

    def get_data_from_command_line(self):
        obs_input_format = "{'obs_path': '******'}"
        param = input(
            "Choose OBSPath placeholder <{}>, and object_type is <{}>; input format is <{}>: ".format(
                self.name, self.object_type, obs_input_format))
        obs_param = ast.literal_eval(param)
        return self.set_data(OBSPath(obs_param["obs_path"]))

    def is_set(self):
        return self._obs_path is not None

    @staticmethod
    def _check_object_type(object_type):
        if object_type not in ("file", "directory"):
            raise ValueError("The object_type of OBSPlaceholder must be file or directory")

    def type(self):
        return OBS_DATA_TYPE


class OBSOutputConfig(AbstractOutputConfig):
    def __init__(self, obs_path, metric_file=None):
        super(OBSOutputConfig, self).__init__()
        """

        Args:
            obs_path (Union[str, Placeholder, Storage]): obs path
            metric_file (Union[str, Placeholder]): metric file name
        """
        self.obs_path = obs_path
        self.metric_file = metric_file

    def to_definition_json(self):
        result = {}
        if isinstance(self.obs_path, (Placeholder, Storage)):
            result["obs_url"] = self.obs_path.ref()
        else:
            result["obs_url"] = self.obs_path
        if self.metric_file:
            result["metric_file"] = \
                self.metric_file.ref() if isinstance(self.metric_file, Placeholder) else self.metric_file
        return result

    def data_consumption(self, step_name, output_name):
        return OBSConsumption(self, step_name, output_name)


class OBSConsumption(AbstractDataConsumption):

    def __init__(self, config, step_name, output_name):
        super(OBSConsumption, self).__init__(config=config, step_name=step_name, output_name=output_name)

    def consume(self) -> AbstractData:
        if isinstance(self.config.obs_path, Placeholder):
            return OBSPath(self.config.obs_path.value)
        elif isinstance(self.config.obs_path, Storage):
            return OBSPath(self.config.obs_path.path)
        return OBSPath(self.config.obs_path)

    def type(self):
        return OBS_DATA_TYPE
