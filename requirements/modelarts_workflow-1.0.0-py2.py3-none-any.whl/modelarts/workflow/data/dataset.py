import attr
import ast
from attr import validators
import logging
from enum import Enum
import collections
from typing import List
import uuid

from modelarts.workflow.core.placeholder import Placeholder
from modelarts.workflow.core.entities import TransformType
from modelarts.workflow.core.state import StepState
from modelarts.workflow.core.serialize import serialize
from modelarts.workflow.core.data import (
    AbstractData,
    AbstractDataPlaceholders,
    AbstractDataConsumption,
)
from modelarts.workflow.core.data import AbstractOutputConfig
from modelarts.workflow.util.utils import to_int_greater_than_zero
from modelarts.workflow.constant import MODEL_WEIGHT_SUM
from modelarts.workflow.client.dataset_client import DatasetClient


DATASET_DATA_TYPE = "dataset"
SERVICE_DATA_TYPE = "service"
MODEL_LIST_DATA_TYPE = "model_list"

DATASET_STATE_MAPPING = {
    # 0: the dataset is creating
    "0": StepState.Running,
    # 1: the dataset is normal
    "1": StepState.Completed,
    # 4: the dataset is abnormal
    "4": StepState.Failed,
    # 5: the dataset is synchronizing
    "5": StepState.Running,
    # 6: the dataset is publishing
    "6": StepState.Running,
    # 7: the dataset is switching
    "7": StepState.Running,
    # 8: the dataset is importing
    "8": StepState.Running
}


class DatasetTypeEnum(Enum):
    """
    Dataset type enum
    """
    IMAGE_CLASSIFICATION = 0
    OBJECT_DETECTION = 1
    IMAGE_SEGMENTATION = 3
    TEXT_CLASSIFICATION = 100
    NAMED_ENTITY_RECOGNITION = 101
    TEXT_TRIPLE = 102
    AUDIO_CLASSIFICATION = 200
    SPEECH_CONTENT = 201
    SPEECH_SEGMENTATION = 202
    DATASET_TABULAR = 400
    VIDEO_ANNOTATION = 600
    FREE_FORMAT = 900


class DataTypeEnum(Enum):
    """
    Data type enum
    """
    IMAGE = 0
    TEXT = 1
    AUDIO = 2
    TABULAR = 4
    VIDEO = 6
    FREE_FORMAT = 9


class Dataset(AbstractData):
    def __init__(self, dataset_name: str, version_name: str = None):
        """

        Args:
            dataset_name: the name of dataset
            version_name: the version name of dataset, default is None
        """
        super(Dataset, self).__init__(name='{}_{}'.format(dataset_name, uuid.uuid4().hex))
        self.dataset_name = dataset_name
        self.version_name = version_name
        self._id = None
        self._version_id = None

    def fill_id_and_version_id(self, dataset_client):
        if not isinstance(dataset_client, DatasetClient):
            raise TypeError('The dataset_client type must be DatasetClient. But provided: {}'.format(
                type(dataset_client)))
        if self.id is None:
            self.id = dataset_client.get_dataset_id(self.dataset_name)
        if self.version_id is None and self.version_name is not None:
            self.version_id = dataset_client.get_dataset_version_id(self.id, self.version_name)

    def to_definition_json(self) -> TransformType:
        if self.id is None:
            raise ValueError('The id of the dataset {} cannot be empty'.format(self.dataset_name))
        result = {
            "name": self.name,
            "type": "dataset",
            "value": {
                "dataset_id": self.id,
                "version_id": self.version_id if self.version_id else "",
            }
        }
        return result

    def get_snapshot(self) -> TransformType:
        """

        :return: TransformType
        """
        return {
            "dataset_name": self.dataset_name,
            "version_name": self.version_name if self.version_name else "",
            "dataset_id": self.id if self.id else "",
            "version_id": self.version_id if self.version_id else "",
        }

    @property
    def id(self):
        return self._id

    @id.setter
    def id(self, dataset_id):
        self._id = dataset_id

    @property
    def version_id(self):
        return self._version_id

    @version_id.setter
    def version_id(self, version_id):
        self._version_id = version_id

    def type(self):
        return DATASET_DATA_TYPE


class ServiceData(AbstractData):
    def __init__(self, service_id):
        """
        Args:
            service_id (str): service id
        """
        if not isinstance(service_id, str):
            raise TypeError("service_id must be type of str , but got {}".format(type(service_id)))
        super(ServiceData, self).__init__(uuid.uuid4().hex)
        self.service_id = service_id

    def to_definition_json(self):
        result = {
            "name": self.name,
            "type": "service",
            "value": {
                "service_id": self.service_id
            }
        }
        return result

    def get_snapshot(self) -> TransformType:
        """

        Returns:

        """
        return {
            "name": self.name,
            "service_id": self.service_id
        }

    def type(self):
        return SERVICE_DATA_TYPE


class ServiceUpdatePlaceholder(AbstractDataPlaceholders):

    def __init__(self, name, delay=False):
        """

        Args:
            name (str): the name of the ServiceUpdatePlaceholder
            delay (bool): represent whether the ServiceUpdatePlaceholder is input at runtime, default False
        """
        super().__init__(name)
        self.delay = delay
        self._service = None

    def set_data(self, data):
        self._service = data

    def to_definition_json(self) -> TransformType:
        result = {
            "name": self.name,
            "type": "service",
            "delay": self.delay
        }
        return result

    def __repr__(self):
        return "Service placeholder <{}> need to be set".format(self.name)

    @property
    def data(self):
        return self._service

    def consume(self):
        return self._service

    def get_data_from_command_line(self):
        input_format = "{'service_id': '******'}"
        param = input(
            "Choose Service placeholder <{}>, input format is <{}>: ".format(self.name, input_format))
        input_param = ast.literal_eval(param)
        return self.set_data(ServiceData(input_param["service_id"]))

    def is_set(self):
        return self._service is not None

    def type(self):
        return SERVICE_DATA_TYPE


@attr.s
class ServiceRunCfg:
    """
    Run Config for deploy or update service

    Args:
        model_name (str): model name
        model_version (str): model version
        weight (int): weight distribution
        pool_name (str): default None, OS dedicated resource pool name,
                         when dedicated resource pool used, this parameter and specification should be set
        cluster_id (str): default None, dedicated resource pool cluster_id,
                          only when dedicated resource pool used can this parameter set
        specification (str): default None, specification for deploy or update service,
                             it should be set to "custom" when used for custom specification
        custom_spec (dict): default None, custom specification like,
                            {"cpu": 2.5, "memory":2048, "gpu_p4":2, "ascend_a310":2},
                            only when custom specification used can this parameter set
        instance_count (int): count of instance
        envs (dict): default None, environment variable
        id (str): model id
    """

    model_name = attr.ib(validator=validators.instance_of(str))
    model_version = attr.ib(validator=validators.instance_of(str))
    weight = attr.ib(default=MODEL_WEIGHT_SUM, converter=to_int_greater_than_zero)
    specification = attr.ib(default=None, validator=validators.instance_of(str))
    pool_name = attr.ib(default=None, validator=validators.instance_of((str, type(None))))
    cluster_id = attr.ib(default=None, validator=validators.instance_of((str, type(None))))
    custom_spec = attr.ib(default=None, validator=validators.instance_of((dict, type(None))))
    instance_count = attr.ib(default=1, converter=to_int_greater_than_zero)
    envs = attr.ib(default=None, validator=validators.instance_of((dict, type(None))))
    id = attr.ib(default=None, validator=validators.instance_of((str, type(None))))

    def to_request(self):
        """
        Returns (dict) for constructing request body
        """
        result = {"model_id": self.id,
                  "model_name": self.model_name,
                  "model_version": self.model_version,
                  "weight": self.weight,
                  "specification": self.specification,
                  "instance_count": self.instance_count}
        if self.envs:
            result["envs"] = self.envs
        if self.pool_name:
            result["pool_name"] = self.pool_name
        if self.cluster_id:
            result["cluster_id"] = self.cluster_id
        if self.custom_spec:
            result["custom_spec"] = self.custom_spec
        return result

    def get_snapshot(self):
        pass


class ServiceRunCfgDict(collections.UserDict):
    def __init__(self, service_run_cfg_list: (ServiceRunCfg, List[ServiceRunCfg])):
        super(ServiceRunCfgDict, self).__init__()
        if not isinstance(service_run_cfg_list, list):
            service_run_cfg_list = [service_run_cfg_list]

        if service_run_cfg_list:
            for cfg in service_run_cfg_list:
                if not isinstance(cfg, ServiceRunCfg):
                    raise TypeError(
                        "The type of element of service_run_cfg_list must be ServiceRunCfg. "
                        "But provided type: {}".format(type(cfg)))
                name = "{}_{}".format(cfg.model_name, cfg.model_version)
                if self.get(name) is not None:
                    raise ValueError('The name "{}" already exists in the same '
                                     'ServiceRunCfgDict.'.format(name))
                self[name] = cfg

    def get_snapshot(self):
        return [x.get_snapshot() for x in self.values()]


class ServiceInputPlaceholder(AbstractDataPlaceholders):

    def __init__(self, name, model_name, model_version=None, envs=None, delay=True):
        """

        Args:
            name (str): The name of ServiceInputPlaceholder
            model_name (Union[str, Placeholder]): The model name
            model_version (str): The model version
            envs (dict): environment variables
            delay (bool): represent whether the ServiceInputPlaceholder is input at runtime, default True
        """
        super(ServiceInputPlaceholder, self).__init__(name)
        self.model_name = model_name
        self.model_version = model_version
        self.envs = envs
        self.delay = delay
        self._data = None

    def _get_condition_json(self) -> TransformType:
        condition_list = []
        if self.model_name:
            condition_list.append({
                "attribute": "model_name",
                "operator": "equal",
                "value": self.model_name.ref() if isinstance(self.model_name, Placeholder) else self.model_name
            })
        if self.model_version:
            condition_list.append({
                "attribute": "model_version",
                "operator": "equal",
                "value": self.model_version
            })
        if self.envs:
            condition_list.append({
                "attribute": "envs",
                "operator": "equal",
                "value": self.envs
            })
        return condition_list

    def to_definition_json(self) -> TransformType:
        result = {
            "name": self.name,
            "type": "model_list",
            "delay": self.delay,
            "conditions": self._get_condition_json(),
        }
        return result

    def is_set(self) -> bool:
        return self._data is not None

    def set_data(self, data):
        self._data = self._filtered_data_meets_conditions(data)

    def __repr__(self):
        return " ServiceInput placeholder <{}> need to be set".format(self.name)

    @property
    def data(self):
        return self._data

    def consume(self):
        return self._data

    def get_data_from_command_line(self):
        param = self.get_input_data()
        param = self._add_prefix_suffix(param)
        dataset_param = ast.literal_eval(param)
        service_run_cfg_dict = self._verify_format_and_convert_to_cfg_dict(dataset_param)
        return self.set_data(service_run_cfg_dict)

    def get_input_data(self):
        input_format = \
            "[{'model_name': '******', 'model_version': '*.*.*', " \
            "'specification':'modelarts.vm.cpu.2u', 'weight': 50}, " \
            "{'model_name': '******', 'model_version': '*.*.*', " \
            "'specification':'******', 'weight': 30, 'envs':{'k1': 'v1', 'k2': 'v2'}}," \
            "{'model_name': '******', 'model_version': '*.*.*', " \
            "'specification':'******', 'weight': 20, 'envs':{'******': '******', '******': '******'}}" \
            "]"
        dedicated_resource_pool_custom_format = \
            "[{'model_name': '******', 'model_version': '*.*.*', " \
            "'weight': 100, 'specification':'custom', 'cluster_id':'******'," \
            "'custom_spec':{'cpu':2.5, 'memory':1024},'envs':{'******': '******', '******': '******'}}" \
            "]"
        dedicated_resource_pool_format = \
            "[{'model_name': '******', 'model_version': '*.*.*', " \
            "'weight': 100, 'specification':'modelarts.vm.cpu.2u', 'cluster_id':'******'," \
            "'envs':{'******': '******', '******': '******'}}" \
            "]"
        os_dedicated_resource_pool_format = \
            "[{'model_name': '******', 'model_version': '*.*.*', " \
            "'weight': 100, , 'pool_name':'******', 'specification':'modelarts.vm.cpu.2u'," \
            "'envs':{'******': '******', '******': '******'}}" \
            "]"
        param = input(
            'Please enter the ServiceInputPlaceholder "{}" in the following format:\n'
            '"{}"\n\n'
            'os dedicated resource pool use following format:\n'
            '"{}"\n\n'
            'dedicated resource pool use following format:\n'
            '"{}"\n\n'
            'dedicated resource pool custom spec use following format:\n'
            '"{}"\n\n'
            'Note that:(1) The "[" at the beginning and "]" at the end are required.\n'
            '          (2) The sum of the weights must be equal to {}.\n'
            '          (3) All model must have the same model name. Two model versions cannot be '
            'the same.\n'.format(self.name, input_format, os_dedicated_resource_pool_format,
                                 dedicated_resource_pool_format,
                                 dedicated_resource_pool_custom_format, MODEL_WEIGHT_SUM))
        return param

    @classmethod
    def _add_prefix_suffix(cls, s):
        prefix = '['
        suffix = ']'
        if not s.startswith(prefix):
            s = prefix + s
        if not s.endswith(suffix):
            s += suffix
        return s

    @classmethod
    def _verify_format_and_convert_to_cfg_dict(cls, dataset_param):
        if not isinstance(dataset_param, list):
            raise TypeError("The type of dataset_param must be list. But provided type: {}".format(
                type(dataset_param)))
        service_run_cfg_list = []
        for dict_item in dataset_param:
            if not isinstance(dict_item, dict):
                raise TypeError("The type of element of dataset_param must be dict. But provided "
                                "type: {}".format(type(dict_item)))
            service_run_cfg_list.append(
                ServiceRunCfg(id=dict_item.get("model_id"),
                              model_name=dict_item.get("model_name"),
                              model_version=dict_item.get("model_version"),
                              weight=dict_item.get("weight", MODEL_WEIGHT_SUM),
                              specification=dict_item.get("specification"),
                              custom_spec=dict_item.get("custom_spec"),
                              cluster_id=dict_item.get("cluster_id"),
                              pool_name=dict_item.get("pool_name"),
                              instance_count=dict_item.get("instance_count", 1),
                              envs=dict_item.get("envs")))
        return ServiceRunCfgDict(service_run_cfg_list)

    def _filtered_data_meets_conditions(self, service_run_cfg_dict):
        for key in list(service_run_cfg_dict.keys()):
            model_name = self.model_name.value if isinstance(self.model_name, Placeholder) else self.model_name
            if service_run_cfg_dict[key].model_name != model_name:
                logging.warning("The provided model_name %s which does not meet the model_name condition %s will "
                                "not be used.", service_run_cfg_dict[key].model_name, model_name)
                service_run_cfg_dict.pop(key)
                continue
            if self.model_version and service_run_cfg_dict[key].model_version != self.model_version:
                logging.warning("The provided model_version %s which does not meet the model_version condition %s will "
                                "not be used.", service_run_cfg_dict[key].model_version, self.model_version)
                service_run_cfg_dict.pop(key)
        return service_run_cfg_dict

    def type(self):
        return MODEL_LIST_DATA_TYPE


class DatasetPlaceholder(AbstractDataPlaceholders):

    def __init__(self, name, data_type=None, delay=False, default=None):
        """

        Args:
            name (str): The name of DatasetPlaceholder
            data_type (DataTypeEnum): The data type of dataset
            delay (bool): represent whether the DatasetPlaceholder is input at runtime, default False
            default(Dataset):default value
        """
        super(DatasetPlaceholder, self).__init__(name)
        self.data_type = data_type
        self.delay = delay
        self._default = default
        self._dataset = None
        self._dataset_client = None

    @property
    def dataset_client(self):
        return self._dataset_client

    @dataset_client.setter
    def dataset_client(self, dataset_client):
        self._dataset_client = dataset_client

    def _get_condition_json(self) -> TransformType:
        condition_list = []
        if self.data_type is not None:
            condition_list.append({
                "attribute": "data_type",
                "operator": "equal",
                "value": self.data_type.value
            })
        return condition_list

    def to_definition_json(self) -> TransformType:
        result = {
            "name": self.name,
            "type": "dataset",
            "delay": self.delay
        }
        if self._default:
            self._default.fill_id_and_version_id(self.dataset_client)
            result["value"] = {
                "dataset_id": self._default.id,
                "version_id": self._default.version_id
            }

        condition_json = self._get_condition_json()
        if condition_json:
            result["conditions"] = condition_json
        return result

    def set_data(self, data):
        if self.dataset_client is None:
            raise ValueError('The dataset_client is None of DatasetPlaceholder {}'.format(self.name))
        data.fill_id_and_version_id(dataset_client=self.dataset_client)
        self._dataset = data

    def __repr__(self):
        return "Dataset placeholder <{}> need to be set".format(self.name)

    @property
    def data(self):
        return self._dataset

    def consume(self):
        return self._dataset

    def get_data_from_command_line(self):
        dataset_input_format = "{'dataset_name': '******', 'version_name': '******'}"
        param = input(
            'Choose dataset placeholder <{}>; input format is "{}", '
            'and the version_name of the dataset can be input on demand: '.format(self.name, dataset_input_format))
        dataset_param = ast.literal_eval(param)
        dataset_name = dataset_param.get("dataset_name")
        if dataset_name is None:
            raise KeyError("The dataset placeholder <{}> has no dataset_name input, "
                           "please input in the correct format".format(self.name))
        if dataset_param.get("version_name") is None:
            return self.set_data(Dataset(dataset_name=dataset_name))
        else:
            return self.set_data(Dataset(dataset_name=dataset_name, version_name=dataset_param.get("version_name")))

    def is_set(self) -> bool:
        return self._dataset is not None

    def type(self):
        return DATASET_DATA_TYPE


class DatasetConfig(AbstractOutputConfig):

    def __init__(self):
        super(DatasetConfig, self).__init__()
        self._data = None

    @property
    def data(self):
        return self._data

    @data.setter
    def data(self, dataset):
        self._data = dataset

    def data_consumption(self, step_name, output_name):
        return DatasetConsumption(config=self, step_name=step_name, output_name=output_name)


@serialize
class DatasetVersionConfig(AbstractOutputConfig):
    def __init__(
        self,
        version_name=None,
        version_format="Default",
        train_evaluate_sample_ratio="1.00",
        clear_hard_property=True,
        remove_sample_usage=True,
        label_task_id=None,
        label_task_type=None,
        description=None
    ):
        """

        Args:
            version_name (Union[str, Placeholder]): version name, if not config, the version will be automatically increased
            version_format (str): version format, default is 'Default'
            train_evaluate_sample_ratio (Union(str, Placeholder)): train evaluate sample ratio, default is '1.0.0'
            clear_hard_property (Union(bool, Placeholder)): whether clear hard property, default is True
            remove_sample_usage (bool): whether clear usage info，default is True
            label_task_id (str): label task ID
            label_task_type (LabelTaskTypeEnum): label task type
            description (str): description info
        """
        super(DatasetVersionConfig, self).__init__()
        self.version_name = version_name
        self.version_format = version_format
        self.train_evaluate_sample_ratio = train_evaluate_sample_ratio
        self.clear_hard_property = clear_hard_property
        self.remove_sample_usage = remove_sample_usage
        self.label_task_id = label_task_id
        self.label_task_type = label_task_type
        self.description = description
        self._dataset = None

    def data_consumption(self, step_name, output_name):
        return DatasetConsumption(config=self, step_name=step_name, output_name=output_name)

    def set_dataset(self, data):
        self._dataset = data

    @property
    def data(self):
        return self._dataset


class DatasetConsumption(AbstractDataConsumption):

    def __init__(self, config, step_name, output_name):
        super(DatasetConsumption, self).__init__(config=config, step_name=step_name, output_name=output_name)

    def consume(self) -> AbstractData:
        return self.config.data

    def type(self):
        return DATASET_DATA_TYPE
