# coding=utf-8
"""
A ModelArts Service can deploy APP service, get APP list
"""
import os
import sys
from modelarts import constant
from modelarts.config.auth import auth_by_apig
from json import JSONEncoder

sys.path.append(os.getcwd())


class Service(object):
    """
    ModelArts service management class, which is used to deploy and query services.
    """

    @staticmethod
    def list(session, query_dict):
        """
        query service job list
        :param session: modelarts session
        :param query_dict: query dictionary
        :return: service list
        """
        # get project_id from session
        project_id = session.project_id
        request_url = "/v1/" + project_id + "/services"
        return auth_by_apig(session, constant.HTTPS_GET, request_url, query=query_dict)

    @staticmethod
    def deploy(session, service_name, model_id, weight, instance_count, specification,
               envs=None, deploy_config=None, cluster_id=None, infer_type='real-time', save_log=False):
        """
        deploy model
        :param session: modelarts session
        :param model_id: model id
        :param weight: weight percentage, the traffic weight assigned to this model
        :param instance_count: number of deployed models, the maximum number of instances is 5 currently
        :param specification:resource specification
        :param envs: key-value pair of environment variables required for running the model
        :param deploy_config: model deploy config
        :param cluster_id: cluster id
        :param infer_type: infer type
        :return: deploy result
        """
        project_id = session.project_id
        request_url = "/v1/" + project_id + "/services"
        configs = []
        config = {
            "model_id": model_id,
            "instance_count": instance_count,
            "specification": specification,
            "weight": weight,
            "envs": envs
        }
        configs.append(config)
        body = {
            "service_name": service_name,
            "config": configs,
            "infer_type": infer_type
        }
        if deploy_config:
            body["deploy_config"] = deploy_config
        if cluster_id:
            body["cluster_id"] = cluster_id
            body["cluster_id_list"] = [cluster_id]
        if save_log:
            body["additional_properties"] = {"log_report_channels": [{"type": "LTS"}]}
        request_body = JSONEncoder().encode(body).encode("utf8")
        return auth_by_apig(session, constant.HTTPS_POST, request_url, body=request_body)

    @staticmethod
    def get(session, service_id):
        """
        Query deploy service details
        :param session: modelarts session
        :param service_id:service ID
        :return: service details
        """
        project_id = session.project_id
        request_url = "/v1/" + project_id + "/services/" + service_id
        return auth_by_apig(session, constant.HTTPS_GET, request_url)

    @staticmethod
    def get_service_models(session, service_id, request_mode):
        """
        Query model service details
        :param session: modelarts session
        :param service_id:service ID
        :return: service details
        """
        request_url = "/v1/" + session.project_id + "/services/" + service_id + "/models"
        query_dict = {}
        if request_mode == "async":
            query_dict["request_mode"] = "async"
        return auth_by_apig(session, constant.HTTPS_GET, request_url, query=query_dict)
