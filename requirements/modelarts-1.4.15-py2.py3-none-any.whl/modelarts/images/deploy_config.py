"""
Description: Provide some functions describing the Deployment configuration of image debug feature
Author: ModelArts SDK Team
"""

import os

from enum import Enum


class RegionCategory(Enum):
    HWC = "hwc"
    HCSO = "hcso"

    @staticmethod
    def list():
        return [x.value for x in RegionCategory]


class UserCategory(Enum):
    EXTERNAL = "external"
    INTERNAL = "internal"

    @staticmethod
    def list():
        return [x.value for x in UserCategory]


REGION_PROMPT_INFO = {
    RegionCategory.HWC.value: {
        # For hwc external user who can only visit production environment
        UserCategory.EXTERNAL.value: "region(1:Beijing4, 2:Shanghai1, 3:Guangzhou)",
        # For hwc internal user who can visit test environment
        UserCategory.INTERNAL.value: "region(1:Beijing4, 2:Shanghai1, 3:Guangzhou, 100:Ulanqab203, 101:Ulanqab201)"
    }
}
INDEX_OF_REGIONS_MAP = {
    RegionCategory.HWC.value: {
        UserCategory.EXTERNAL.value: {
            "1": "cn-north-4",
            "2": "cn-east-3",
            "3": "cn-south-1"
        },
        UserCategory.INTERNAL.value: {
            "1": "cn-north-4",
            "2": "cn-east-3",
            "3": "cn-south-1",
            "100": "cn-north-7",
            "101": "cn-north-5"
        }
    }
}
# Sdk read configuration information like 'region name' from this config file in hcso.
# For cloud, the configuration information is hardcoded.
DEPLOY_CONFIG_PATH = os.path.join(os.path.expanduser("~"), ".modelarts/deploy_config.txt")
DEFAULT_DEPLOY_CONFIG_PATH = os.path.join(os.path.dirname(os.path.realpath(__file__)), "deploy_config.txt")


class ImageBuildDeployConfig(object):
    """
    This class reads the deployment config from 'deploy_config.txt' which was written by deployment pipeline.
    """

    deploy_config = dict()

    @classmethod
    def _check_config(cls, deploy_config):
        cls._check_choice_param(deploy_config["region_category"], RegionCategory.list())
        cls._check_choice_param(deploy_config["user_category"], UserCategory.list())

    @staticmethod
    def _check_choice_param(param, choices):
        if param not in choices:
            raise ValueError(f"The config {param} is not in {choices}")

    @staticmethod
    def _get_image_mgmt_config():
        if os.path.exists(DEPLOY_CONFIG_PATH):
            config_file = DEPLOY_CONFIG_PATH
        else:
            config_file = DEFAULT_DEPLOY_CONFIG_PATH
        with open(config_file, 'r') as f:
            return f.readlines()

    @classmethod
    def _get_deploy_config(cls):
        lines = cls._get_image_mgmt_config()
        deploy_config = dict()
        for line in lines:
            line_arr = line.split("=")
            deploy_config[line_arr[0]] = line_arr[1].strip()
        cls._check_config(deploy_config)
        return deploy_config

    @classmethod
    def get_region_prompt_info(cls):
        cls.deploy_config = cls._get_deploy_config() if not cls.deploy_config else cls.deploy_config
        if cls.deploy_config["region_category"] == RegionCategory.HWC.value:
            return REGION_PROMPT_INFO[RegionCategory.HWC.value][cls.deploy_config["user_category"]]
        # Except for cloud, other scenarios are hcso, for now, it is pengcheng
        region_name = cls.deploy_config["region_name"]
        return f"region(1:{region_name})"

    @classmethod
    def get_index_of_regions_map(cls):
        cls.deploy_config = cls._get_deploy_config() if not cls.deploy_config else cls.deploy_config
        if cls.deploy_config["region_category"] == RegionCategory.HWC.value:
            return INDEX_OF_REGIONS_MAP[RegionCategory.HWC.value][cls.deploy_config["user_category"]]
        # Except for cloud, other scenarios are hcso, for now, it is pengcheng
        return {"1": cls.deploy_config["region"]}

    @classmethod
    def get_region_category(cls):
        cls.deploy_config = cls._get_deploy_config() if not cls.deploy_config else cls.deploy_config
        return cls.deploy_config["region_category"]

    @classmethod
    def get_release_image_version(cls):
        cls.deploy_config = cls._get_deploy_config() if not cls.deploy_config else cls.deploy_config
        return cls.deploy_config["release_image_version"]

    @classmethod
    def get_region(cls):
        cls.deploy_config = cls._get_deploy_config() if not cls.deploy_config else cls.deploy_config
        return cls.deploy_config["region"]

    @classmethod
    def get_service_domains(cls):
        cls.deploy_config = cls._get_deploy_config() if not cls.deploy_config else cls.deploy_config
        return {"S3_ENDPOINT": cls.deploy_config["OBS_DOMAIN"],
                "IAM_ENDPOINT": cls.deploy_config["IAM_DOMAIN"],
                "MODELARTS_ENDPOINT": cls.deploy_config["MODELARTS_DOMAIN"],
                "SWR_ENDPOINT": cls.deploy_config["SWR_DOMAIN"]}
