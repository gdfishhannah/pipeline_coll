"""
Description: Define how to display the image query results
Author: ModelArts SDK Team
Date: 2021/11/01 - 2021/12/30
"""
import abc
import logging
from enum import Enum
import textwrap

from six import with_metaclass
import prettytable

from .image_def import ImageType, ImageVisibility, ModelArtsService
from ..util import string_util

root_logger = logging.getLogger()
for h in root_logger.handlers:
    root_logger.removeHandler(h)
logging.basicConfig(level=logging.INFO, format='')


class Display(with_metaclass(abc.ABCMeta, object)):

    @abc.abstractmethod
    def display(self, image_list):
        pass


class ShortTableDisplay(Display):
    """Display only name and swr_path of image.
    """

    def display(self, image_list):
        table = prettytable.PrettyTable()
        table.field_names = \
            ["", "name", "swr_path"]
        table.hrules = prettytable.ALL
        for idx, row_data in enumerate(image_list):
            table.add_row([idx + 1, row_data["name"], row_data["swr_path"]])
        logging.info(table)


class WideTableDisplay(Display):
    """Display 8 fields of image.
    """

    def display(self, image_list):
        table = prettytable.PrettyTable()
        table.field_names = \
            ["", "name", "id", "swr_path", "arch", "service", "resource_category", "visibility", "description"]
        table._max_width = {"": 10, "name": 20, "id": 20, "swr_path": 40, "arch": 10, "service": 20,
                            "resource_category": 20, "visibility": 10, "description": 40}
        table.hrules = prettytable.ALL
        for idx, row_data in enumerate(image_list):
            if "visibility" in row_data:
                visibility = row_data["visibility"]
            elif row_data["type"] == ImageType.BUILDIN.value:
                visibility = ImageVisibility.PUBLIC.value
            else:
                visibility = ImageVisibility.PRIVATE.value
            description = row_data["description"] if "description" in row_data else ""
            description_wrap = textwrap.fill(description, width=20) \
                if string_util.contains_zh(description) else description
            # In authoring-service database, 'modelbox' is saved as 'ai_flow', so we convert 'ai_flow' to 'modelbox'
            # before showing it to users
            services = [ModelArtsService.MODELBOX.value if service.upper() == "AI_FLOW" else service
                        for service in row_data["dev_services"]]
            table.add_row(
                [idx + 1, row_data["name"], row_data["id"], row_data["swr_path"], row_data["arch"],
                 services, row_data["resource_categories"], visibility, description_wrap]
            )
        logging.info(table)
        logging.info("If you choose an image whose 'visibility' is 'PRIVATE', please visit SWR service to get "
                     "the login command before pulling this image.")


class DisplayFactory(object):
    """Decide how to display the image list.
    """

    @staticmethod
    def get_display_instance(output_format):
        if output_format == OutputFormat.WIDE.value:
            return WideTableDisplay()
        return ShortTableDisplay()


class OutputFormat(Enum):
    WIDE = "wide"  # show 8 field when querying images in the format of table
    SHORT = "default"  # only show name and swr_path
    NO_SHOW = None

    @staticmethod
    def list():
        return [x.value for x in OutputFormat if x.value]
