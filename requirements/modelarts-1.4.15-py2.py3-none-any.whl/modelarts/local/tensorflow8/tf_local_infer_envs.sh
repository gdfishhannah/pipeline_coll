#!/bin/bash

is_gpu=$1
current_path=$(
    cd $(dirname $0)
    pwd
)

# choose obs gpu server url
if [ $REGION_NAME = cn-north-4  ]; then
    tf_gpu_url=https://cnnorth4-modelarts-sdk.obs.cn-north-4.myhuaweicloud.com/tensorflow_model_server_gpu_1.8.0
    tf_cpu_url=https://cnnorth4-modelarts-sdk.obs.cn-north-4.myhuaweicloud.com/tensorflow_model_server_cpu
else
    tf_gpu_url=https://cnnorth1-modelarts-sdk.obs.cn-north-1.myhuaweicloud.com/tensorflow_model_server_gpu_1.8.0
    tf_cpu_url=https://cnnorth1-modelarts-sdk.obs.cn-north-1.myhuaweicloud.com/tensorflow_model_server_cpu
fi


tf_target_server_path=${PATH%%:*}/tensorflow_model_server
tf_middle_server_size=$((1024 * 1024 * 500))

# gpu server branch process
if [ $is_gpu = GPU ]; then
    if [ -f $tf_target_server_path ]; then
        filesize=$(ls -l ${tf_target_server_path} | awk '{print $5}')
        if [ $tf_middle_server_size -gt $filesize ]; then
            wget $tf_gpu_url --no-check-certificate
            mv tensorflow_model_server_gpu_1.8.0 tensorflow_model_server
        fi
    else
        wget $tf_gpu_url  --no-check-certificate
        mv tensorflow_model_server_gpu_1.8.0 tensorflow_model_server
    fi

# cpu server branch process
else
    if [ -f $tf_target_server_path ]; then
        filesize=$(ls -l ${tf_target_server_path} | awk '{print $5}')
        if [ $filesize  -gt $tf_middle_server_size ]; then
            wget $tf_cpu_url  --no-check-certificate
            mv tensorflow_model_server_cpu tensorflow_model_server
        fi
    else
        wget $tf_cpu_url  --no-check-certificate
        mv tensorflow_model_server_cpu tensorflow_model_server
    fi
fi

if [ -f tensorflow_model_server ]; then
    mv tensorflow_model_server ${PATH%%:*}
    chmod 777 ${PATH%%:*}/tensorflow_model_server
fi

#add flag
echo "configure tensorflow local inference environment over." > ${current_path}/.configure.flag
