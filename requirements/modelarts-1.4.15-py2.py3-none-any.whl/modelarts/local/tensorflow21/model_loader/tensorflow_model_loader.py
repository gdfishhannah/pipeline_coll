from model_service.tfserving_model_service import TfServingBaseService

from modelarts.local.commons.model_loader import ModelLoader, load_service_class


class TensorflowModelLoader(ModelLoader):

    def load(self, model):
        service_class = load_service_class(model, TfServingBaseService)
        return service_class(model.name, model.path)

    def unload(self, model):
        pass
