"""`ModelService` defines an API for base model service.
"""
from __future__ import print_function

import os
import sys
import time
import traceback
from abc import ABCMeta, abstractmethod

from . import log

logger = log.getLogger(__name__)


class ModelService(object):
    '''封装模型推理逻辑，整体对外提供推理接口
    '''
    __metaclass__ = ABCMeta

    def __init__(self, model_name, model_path):
        self.model_name = model_name
        self.model_path = model_path
        self.ctx = None

    @abstractmethod
    def inference(self, data):
        pass


class SingleNodeService(ModelService):
    '''SingleNodeModel defines abstraction for model service which loads a
    single model.
    '''

    def inference(self, data):
        '''
        封装预处理，推理和后处理等函数

        Parameters
        ----------
        data : 外部http接口输入

        Returns
        -------
        http接口输出
        '''
        pre_start_time = time.time()
        data = self._preprocess(data)
        infer_start_time = time.time()

        # preprocess latency
        pre_time_in_ms = (infer_start_time - pre_start_time) * 1000
        logger.info('preprocess time: ' + str(pre_time_in_ms) + 'ms')

        data = self._inference(data)
        infer_end_time = time.time()
        infer_in_ms = (infer_end_time - infer_start_time) * 1000

        # infer latency
        logger.info('infer time: ' + str(infer_in_ms) + 'ms')
        data = self._postprocess(data)

        # postprocess latency
        post_time_in_ms = (time.time() - infer_end_time) * 1000
        logger.info('postprocess time: ' + str(post_time_in_ms) + 'ms')

        # e2e latency
        logger.info('latency: ' + str(pre_time_in_ms + infer_in_ms + post_time_in_ms) + 'ms')
        return data

    @abstractmethod
    def _inference(self, data):
        '''
        模型推理过程

        Parameters
        ----------
        data : _preprocess函数的返回值

        Returns
        -------
        模型的预测值
        '''
        return data

    @abstractmethod
    def _preprocess(self, data):
        '''
        处理用户接口的输入数据

        Parameters
        ----------
        data : https两种请求形式
        1. form-data文件格式的请求对应：data = {"请求key值":{"文件名":<文件io>}}
        2. json格式对应：data = json.loads("接口传入的json体")

        Returns
        -------
        返回值作为_inference函数的入参
        '''
        return data

    @abstractmethod
    def _postprocess(self, data):
        '''
        处理_inference函数的返回值，封装为接口的返回

        Parameters
        ----------
        data : _inference函数的返回值

        Returns
        -------
        可以json序列化的数据类型
        '''
        return data


def load_service(path, name=None):
    try:
        if not name:
            name = os.path.splitext(os.path.basename(path))[0]

        module = None
        if sys.version_info[0] > 2:
            import importlib
            spec = importlib.util.spec_from_file_location(name, path)
            module = importlib.util.module_from_spec(spec)
            spec.loader.exec_module(module)

        else:
            import imp
            module = imp.load_source(name, path)

        return module
    except Exception:
        traceback.print_exc()
        raise Exception('Incorrect or missing service file: ' + path)
