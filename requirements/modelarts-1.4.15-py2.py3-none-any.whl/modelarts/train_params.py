"""
Description: Define some structures for training.
Author: ModelArts SDK Team
Date: 2020/05/14 - 2021/06/30
"""
import logging
import os
import shutil
import tempfile
import uuid
from enum import Enum

from . import constant
from .obs_mgmt import OBSApiBase
from .util import file_utils
from .util import notebook_util

ZIP_FILE_SUFFIX = ".zip"
logging.getLogger().setLevel(logging.INFO)


class TrainingFiles(object):
    """
    This class is used to organize training files.
    """

    REMOTE_TRAINING_JOB_WORKING_DIR = "/home/ma-user/modelarts/user-job-dir"

    def __init__(self, code_dir, boot_file, obs_path=None):
        """
        Initialize training files object.
        :param code_dir: the directory of training files
        :param boot_file: the code startup file of the training job
        :param obs_path: training files will be uploaded to this obs path for local train
        """
        if code_dir is None or boot_file is None:
            raise ValueError("code dir and boot file are both required.")
        self.__is_obs_source = code_dir.startswith(constant.OBS_HEAD_FORMAT) \
                               or code_dir.startswith(constant.S3_HEAD_FORMAT)
        self.__init_obs_path(obs_path)
        self.__init_code_dir(code_dir)
        self.obs_code_dir = self.__code_dir
        # boot file can be relative path under code dir or abs path
        self.__init_boot_file(boot_file)
        self.code_dir_name = None
        self.__is_efs = notebook_util.is_mount_efs()
        self.tmp_code_dir = None

    def compress_upload(self, session):
        """
        Compress local code files and upload to obs.
        :param session: session with authentication information
        """
        self.code_dir_name = os.path.basename(self.__code_dir[:-1])
        with tempfile.TemporaryDirectory() as tmp:
            zip_file_path = os.path.join(tmp, self.code_dir_name + ZIP_FILE_SUFFIX)
            if self.__obs_path is None:
                raise Exception("Parameter obs_path is required in TrainingFiles.")
            try:
                file_utils.compress_dir_to_zip(zip_file_path, self.__code_dir, self.code_dir_name + '/')
                session.obs.upload_file(zip_file_path, self.__obs_path)
            except Exception as e:
                raise Exception("Error happens when compress and upload code files, error={}".format(e))
        self.obs_code_dir = self.__obs_path + self.code_dir_name + ZIP_FILE_SUFFIX

    def __is_efs_source(self):
        """
        If training files are saved in efs.
        :return: True or False
        """
        return self.__is_efs and self.__code_dir.startswith(constant.MOUNT_DIR)

    def get_code_dir(self, local_run=True):
        """
        Get the path where the training files are saved. When we want to submit a remote training job in evs
        and code files are saved locally, obs_code_dir is the a zip file. For other cases, obs_code_dir equals code_dir
        :param local_run: if run the training job locally.
        :return: a path
        """
        if local_run:
            return self.__code_dir
        elif self.__is_efs_source():
            return "file:/" + self.__code_dir
        else:
            return self.obs_code_dir

    def get_boot_file(self, local_run=True):
        """
        Get path of boot file when submit training job according to code dir.
        If the code directory is in devcontainer, sdk will compresses code dir and boot file should be a relative path
        If user submits training job without debug, boot_file should be absolute path and start with obs
        :param local_run: if run the training job locally.
        :return: the path of boot file
        """
        if self.__boot_file is None:
            return self.__boot_file
        code_dir = self.get_code_dir(local_run)
        return self.__boot_file if code_dir.endswith(ZIP_FILE_SUFFIX) else os.path.join(code_dir, self.__boot_file)

    def need_upload(self):
        """
        If need to upload the training files.
        :return: True or False
        """
        return not (self.__is_efs_source() or self.__is_obs_source)

    def __init_obs_path(self, obs_path):
        """
        Check if obs_path is in correct format.
        :param obs_path: training files will be uploaded to this obs path for local train
        """
        if obs_path is None:
            self.__obs_path = None
            return
        if self.__is_obs_source:
            raise ValueError("obs_path is not required when code dir is in obs.")
        OBSApiBase.check_obs_dir_head_tail(obs_path)
        self.__obs_path = obs_path

    def __init_code_dir(self, code_dir):
        """
        Check if code dir is in correct format.
        :param code_dir: the directory of training files
        """
        if self.__is_obs_source:
            OBSApiBase.check_obs_dir_head_tail(code_dir)
            self.__code_dir = code_dir
        else:
            OBSApiBase.check_local_path_legal(code_dir, constant.UPLOAD_MODE, constant.DIR_MODE)
            self.__code_dir = os.path.abspath(code_dir) + '/'

    def __init_boot_file(self, boot_file):
        """
        Check if code_dir and boot file exist.
        :param boot_file: the code startup file of the training job
        """
        if boot_file is None:
            self.__boot_file = None
            return
        boot_file_relative_path = \
            boot_file[len(self.__code_dir):] if boot_file.startswith(self.__code_dir) else boot_file
        boot_file_abs_path = os.path.join(self.__code_dir, boot_file_relative_path)
        if not self.__is_obs_source and not os.path.exists(boot_file_abs_path):
            raise ValueError("The boot file {} does not exist.".format(boot_file_abs_path))
        self.__boot_file = boot_file_relative_path

    def copy_code_dir(self):
        """
        The work directory of remote training job is /home/ma-user/modelarts/user-job-dir. Copy the files in code dir
        into working directory in order to simulate the remote training job.
        """
        if not os.path.exists(self.REMOTE_TRAINING_JOB_WORKING_DIR):
            os.makedirs(self.REMOTE_TRAINING_JOB_WORKING_DIR, exist_ok=True)
            self.tmp_code_dir = self.REMOTE_TRAINING_JOB_WORKING_DIR
        code_dir_name = os.path.basename(os.path.abspath(self.get_code_dir()))
        new_code_dir = os.path.join(self.REMOTE_TRAINING_JOB_WORKING_DIR, code_dir_name)
        if os.path.exists(new_code_dir):
            new_code_dir = os.path.join(self.REMOTE_TRAINING_JOB_WORKING_DIR, str(uuid.uuid4()))
        self.tmp_code_dir = new_code_dir if self.tmp_code_dir is None else self.tmp_code_dir
        shutil.copytree(self.get_code_dir(), new_code_dir)

    def clear_tmp_code_dir(self):
        if self.tmp_code_dir is not None and os.path.exists(self.tmp_code_dir):
            shutil.rmtree(self.tmp_code_dir)


class InputData(object):
    """
    Input data object.
    """

    def __init__(self, obs_path=None, local_path=None, is_local_source=False, name=None):
        """
        Initialize data object.
        :param is_local_source: if source data is in local path.
        :param obs_path: if is_local_source=False, it is the location where data is saved;
                         if is_local_source=True, the data will be uploaded to this location from local_path
        :param local_path: if is_local_source=True, it is the location where the data is saved;
                           if is_local_source=False, the data will be downloaded to this location from obs_path
        :param name: input dataset name
        """
        self.train_data_zip_file_name = "dataset"
        self.__is_local_source = is_local_source
        # input data will be taken as boot_file parameters like
        # "--$name=$local_path" if name is not None
        if name and local_path:
            logging.info('This input data will be passed as boot file parameter as "--%s=%s"', name, local_path)
        self.__name = name
        self.__compress_data_obs_path = None
        self.__init_local_path(local_path)
        self.__init_obs_path(obs_path)
        self.__is_efs = notebook_util.is_mount_efs()

    def __init_local_path(self, local_path):
        """
        Init local path.
        :param local_path: a path in notebook(devcontainer) or user workstation.
        If user wants to submit a remote training job, local path is not necessary. Without this parameter,
        the training service will generate a directory automatically.
        """
        self.__local_path = None
        if self.__is_local_source:
            if local_path is None:
                raise ValueError("Parameter local_path is required.")
            if not os.path.exists(local_path):
                raise ValueError("Local path {} does not exist.".format(local_path))
        if local_path:
            self.train_data_zip_file_name = os.path.basename(os.path.abspath(local_path))
            self.__local_path = os.path.abspath(local_path) + "/"

    def __init_obs_path(self, obs_path):
        """
        Init obs path.
        :param obs_path: obs path where data is saved
        """
        if self.__is_local_source:
            self.__obs_path = obs_path
            return
        if obs_path is None:
            raise ValueError("Parameter obs_path is required.")
        if obs_path.endswith('/'):
            OBSApiBase.check_obs_dir_head_tail(obs_path)
        else:
            OBSApiBase.check_obs_file_head_tail(obs_path)
        self.__obs_path = obs_path

    def need_upload(self, session, local_training=False):
        """
        1. If the training data is not in local path, no need to upload data.
        2. For efs, no need to upload data to obs from local source.
        3. If user runs the training job locally, no need to upload data to obs.
        3. If the dataset already exists in obs, no need to upload data to obs from local source.
        :param session: session with authentication information
        :param local_training: if the training job runs locally
        :return: True or False
        """
        if not self.__is_local_source:
            return False
        if self.__is_efs and self.__local_path.startswith(constant.MOUNT_DIR):
            return False
        if local_training or self.__obs_path is None:
            return False
        file_path = os.path.join(self.__obs_path, self.train_data_zip_file_name + ZIP_FILE_SUFFIX)
        if session.obs.is_obs_path_exists(file_path):
            logging.warning(f"Found existed {self.train_data_zip_file_name + ZIP_FILE_SUFFIX} "
                            f"in {self.__obs_path}, which will be used.")
            self.__compress_data_obs_path = file_path
            return False
        return True

    def compress_training_data(self):
        """
        Compress training data into a zip file
        :return: zip file path
        """
        zip_file_path = os.path.join(tempfile.mkdtemp(), self.train_data_zip_file_name + ZIP_FILE_SUFFIX)
        file_utils.compress_dir_to_zip(zip_file_path, self.__local_path, '')
        return zip_file_path

    def upload_training_data(self, path, session):
        """
        Upload training data to obs.
        :param path: the file path or folder path which will be uploaded to obs
        :param session: session with authentication information
        """
        if self.__obs_path is None:
            raise Exception("Parameter obs_path is required in TrainingFiles.")
        session.obs.upload_file(path, self.__obs_path)
        self.__compress_data_obs_path = self.__obs_path + os.path.basename(path)
        logging.info("upload training data to %s successfully.", self.__obs_path)

    def compress_and_upload(self, session):
        """
        Compress training data to a zip file and upload it to obs.
        :param session: session with authentication information
        """
        file_path = self.compress_training_data()
        self.upload_training_data(file_path, session)
        self.__clear_tmp_dir(os.path.dirname(file_path))

    def is_compress_file(self):
        """
        If training data is a compressed file.
        :return: True or False
        """
        return file_utils.is_supported_compress_file(self.get_obs_path())

    def drop_this_input(self):
        """
        1. This training data is not needed if it is saved in efs.
        2. This training data is not needed if it is in local path and self.__obs_path is None
            which results in self.__compress_data_obs_path is None.
        :return True means this training data will be downloaded from obs to local path.
        """
        return self.__is_local_source and (self.__is_efs and self.__local_path.startswith(constant.MOUNT_DIR) or
                                           self.__compress_data_obs_path is None)

    @staticmethod
    def __clear_tmp_dir(temp_dir):
        """
        Clear temporary directory generated when compressing local training dataset.
        :param temp_dir: the temporary directory which will be deleted
        """
        if not os.path.exists(temp_dir):
            return
        shutil.rmtree(temp_dir)

    def get_obs_path(self):
        """
        Only when the training data is in local directory and compressed to a zip file,
        __compress_data_obs_path is not none
        :return: obs path.
        """
        return self.__compress_data_obs_path if self.__compress_data_obs_path is not None else self.__obs_path

    @property
    def local_path(self):
        return self.__local_path

    @property
    def name(self):
        return self.__name


class OutputData(object):
    """
    Output data object, including model file, etc.
    """

    def __init__(self, local_path="", obs_path="", name=""):
        """
        Initialize the output data object
        :param local_path: local path where the output of training task are saved
        :param obs_path: obs path where the data is uploaded to
        :param name: name of output
        """
        self.__local_path = None
        # If user wants to submit a remote training job, local path is not necessary. Without this parameter,
        # the training service will generate a directory automatically.
        if local_path:
            self.__local_path = os.path.abspath(local_path) + '/'
            if notebook_util.is_mount_efs() and self.__local_path.startswith(constant.MOUNT_DIR):
                logging.info("the local path is in efs, therefore obs_path is not required.")
            elif not obs_path:
                raise ValueError("obs_path is required.")
        self.__obs_path = obs_path
        self.__name = name
        # output data will be taken as boot_file parameters like
        # "--$name=$local_path" if name is not None
        if name and local_path:
            logging.info('This output data will be passed as boot file parameter as "--%s=%s"', name, local_path)

    @property
    def obs_path(self):
        return self.__obs_path

    @obs_path.setter
    def obs_path(self, value):
        # If the user submits the same training job multiple times in a row, this parameter must be modified
        # because ROMA will verify it.
        self.__obs_path = value

    @property
    def local_path(self):
        return self.__local_path

    @local_path.setter
    def local_path(self, value):
        self.__local_path = value

    @property
    def name(self):
        return self.__name

    @name.setter
    def name(self, value):
        self.__name = value


def prepare_params_input(input_list=None, dataset_id=None, dataset_version_id=None, data_source=None, local_run=True):
    """
    Organize input according to training API.
    :param input_list: dataset for training
    :param dataset_id: dataset_id of ModelArts
    :param dataset_version_id: dataset_version_id of ModelArts
    :param data_source: data_source of ModelArts
    :param local_run: True: training job runs locally in notebook(devcontainer)
                      False: training job runs in training service
    :return: structured input
    """
    if input_list and dataset_id and dataset_version_id and data_source:
        raise ValueError('Pass either inputs or dataset_name and dataset_version_id or data_source.')
    if (dataset_id and not dataset_version_id) or (not dataset_id and dataset_version_id):
        raise ValueError('dataset_id and dataset_version_id are all needed.')
    if input_list:
        return _convert_to_inputs_parameters(input_list, local_run)
    if dataset_id and dataset_version_id:
        return [
            {
                "name": "data_url",
                "remote": {
                    "dataset": {
                        "id": dataset_id,
                        "version_id": dataset_version_id
                    }
                }
            }
        ]
    logging.info('Set config by using other inputs or dataset.')
    return []


def _convert_to_inputs_parameters(input_list, local_run=True):
    """
    Organize inputs data which is saved in OBS, EVS or EFS.
    :param local_run: True: training job runs locally in notebook(devcontainer)
                      False: training job runs in training service
    :return _inputs: structured inputs according to training API
    """
    _inputs = []
    for data in input_list:
        if not isinstance(data, InputData):
            raise TypeError("each element of inputs should be of type InputData")
        if local_run and not data.local_path:
            raise ValueError("If the training job runs locally, local_path is needed in InputData.")
        if data.drop_this_input():
            continue
        cur_input = {
            "remote": {
                "obs": {
                    "obs_url": data.get_obs_path(),
                    "config": {
                        "need_extract": data.is_compress_file()
                    }
                }
            }
        }
        if data.local_path:
            cur_input["local_dir"] = data.local_path
        if data.name:
            cur_input["name"] = data.name
        _inputs.append(cur_input)
    return _inputs


def prepare_params_output(output_data=None, local_run=True):
    """
    Organize output according to training API.
    :param output_data: output data.
    :param local_run: True: training job runs locally in notebook(devcontainer)
                      False: training job runs in training service
    :return: structured output
    """
    _outputs = []
    for data in output_data:
        if local_run and not data.local_path:
            raise ValueError("If the training job runs locally, local_path is needed in OutputData.")
        if not data.obs_path:
            continue
        _output = {"remote": {"obs": {"obs_url": data.obs_path}},
                   "mode": "upload_periodically",
                   "period": constant.TRAIN_OUTPUT_DATA_SYNC_PERIOD}
        if data.local_path:
            _output["local_dir"] = data.local_path
        if data.name:
            _output["name"] = data.name
        _outputs.append(_output)
    return _outputs


class TrainPolicy(Enum):
    REG = "regular"  # for public pool and dedicated pool
    ECO = "economic"  # only for public pool
    TUR = "turbo"  # only for public pool
    AUT = "auto"  # only for dedicated pool

    @staticmethod
    def list():
        return [x.value for x in TrainPolicy]
