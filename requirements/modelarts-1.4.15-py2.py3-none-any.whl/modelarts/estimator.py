"""An estimator class for training of modelarts sdk."""
import json
import logging
import time
from datetime import datetime, timedelta
from json import JSONEncoder

import requests

from . import constant
from .config.auth import auth_by_apig
from .estimator_base import EstimatorBase, TrainingJobBase
from .exception.roma_exception import RomaException
from .util.secret_util import auth_expired_handler

logging.getLogger().setLevel(logging.INFO)
JOB_STATE = constant.JOB_STATE
HTTPS_GET = constant.HTTPS_GET
HTTPS_POST = constant.HTTPS_POST
HTTPS_DELETE = constant.HTTPS_DELETE
HTTPS_PUT = constant.HTTPS_PUT


class Estimator(EstimatorBase):

    def __init__(self, modelarts_session, train_instance_count=None,
                 train_instance_type=None,
                 output_path=None, base_job_name=None, code_dir=None,
                 boot_file=None, hyperparameters=None,
                 framework_type=None, framework_version=None, model_name=None,
                 log_url=None, user_image_url=None,
                 user_command=None, create_version=None, job_description=None,
                 job_id=None, version_id=None,
                 config_name=None, nas_type=None, nas_share_addr=None,
                 nas_mount_path=None,
                 job_type=None,
                 config_path=None,
                 autosearch_path=None,
                 environment=None,
                 pool_id=None,
                 workspace_id=None):
        """
        Initialize a ModelArts Estimator Object.
        """
        super(Estimator, self).__init__(modelarts_session, train_instance_count, train_instance_type,
                                        base_job_name, hyperparameters, framework_type,
                                        framework_version, log_url, user_image_url,
                                        user_command, job_description, job_id, job_type, workspace_id)
        self.code_dir = code_dir
        self.boot_file = boot_file
        self.output_path = output_path
        self.autosearch_path = autosearch_path
        self.config_path = config_path
        self.model_name = model_name
        self.nas_type = nas_type
        self.nas_share_addr = nas_share_addr
        self.nas_mount_path = nas_mount_path
        self.create_version = create_version
        self.version_id = version_id
        self.config_name = config_name
        self.trainingJob = TrainingJob(self.session)
        self.pool_id = pool_id
        self.env_target = self.__init_environment_target(
            environment=environment)
        logging.warning("Training job `Estimator v1` is deprecated and will "
                        "be removed in a future release. Please use `Estimator v2` instead.")

    def __init_environment_target(self, environment=None):
        """
        Initialize a compute environment including local and V1
        :param environment: conda or docker environment
        """
        if environment is None:
            return None

        from .compute import RunConfig, LocalCompute, TrainV1Compute
        run_config = RunConfig(
            source_directory=self.code_dir,
            boot_file=self.boot_file,
            args=self.parameters,
            instance_count=self.train_instance_count,
            instance_type=self.train_instance_type,
            framework=self.framework_type)

        if self.train_instance_type == constant.LOCAL_TRAIN_TYPE:
            return LocalCompute(run_config=run_config,
                                environment=environment)
        else:
            return TrainV1Compute(run_config=run_config,
                                  environment=environment,
                                  estimator=self)

    def fit(self, inputs=None, dataset_id=None, dataset_version_id=None,
            data_source=None, wait=False, job_name=None,
            priority=constant.ROMA_TRAIN_JOB_DEFAULT_PRIORITY):
        """
        Train a model using the input training dataset.
        :param inputs: dataset from obs
        :param dataset_id: dataset_id of ModelArts
        :param dataset_version_id: dataset_version_id of ModelArts
        :param data_source: data_source of ModelArts
        :param wait: whether wait the job completed or not
        :param job_name: job name
        :param priority: train job priority for roma, 3 2 1 is high middle low
        :return: job object
        """
        self._gen_job_name(job_name=job_name)

        job_train_resp = self.submit_task(inputs, dataset_id, dataset_version_id,
                                          data_source, priority)
        job_train_resp_content = self.trainingJob._transform_roma_response(job_train_resp)

        if self.train_instance_type and self.train_instance_type in constant.LOCAL_TRAIN_TYPE:
            return
        elif not job_train_resp_content['is_success']:
            raise Exception(
                'Failed to create the job with the error_code %s and error_msg %s .'
                % (job_train_resp_content['error_code'], job_train_resp_content['error_msg']))

        job_info = self.get_waiting_job_state(job_train_resp_content, wait)
        # no job-name in job_train_resp when it is from waiting status query interface
        if 'job_name' not in job_info:
            job_info['job_name'] = self._current_job_name

        self.save_training_output(inputs, dataset_id, dataset_version_id, data_source, wait, job_info)
        self.trainingJob.job_id = job_info['job_id']
        self.trainingJob.version_id = job_info['version_id']
        return self.trainingJob

    def prepare_config(self, inputs, dataset_id, dataset_version_id,
                       data_source, priority=constant.ROMA_TRAIN_JOB_DEFAULT_PRIORITY):
        """
        Organize all needed parameters to a dict.
        :param inputs: dataset from obs
        :param dataset_id: dataset_id of ModelArts
        :param dataset_version_id: dataset_version_id of ModelArts
        :param data_source: data_source of ModelArts
        :param priority: priority of train job
        :return: job config
        """
        _config = dict()

        # train job priority for roma, 3 2 1 is high middle low
        _config["priority"] = priority

        if self.train_instance_count:
            _config['worker_server_num'] = self.train_instance_count
        else:
            raise ValueError('Parameter train_instance_count is needed')

        if self.model_name and (self.code_dir or self.boot_file):
            raise ValueError(
                'Pass either model_name or app_url and boot_file.')

        if self.model_name and (self.framework_type or self.framework_version):
            raise ValueError('Pass either model_name or '
                             'framework_type and framework_version.')

        if self.nas_type:
            _config['nas_type'] = self.nas_type
        if self.nas_share_addr:
            _config['nas_share_addr'] = self.nas_share_addr
        if self.nas_mount_path:
            _config['nas_mount_path'] = self.nas_mount_path

        if self.code_dir:
            _config['app_url'] = self.code_dir

        if self.boot_file:
            _config['boot_file_url'] = self.boot_file

        if self.output_path:
            _config['train_url'] = self.output_path

        _config = self._prepare_params_spec_id(_config)

        _config['parameter'] = self.parameters

        if self.framework_version or self.framework_type:
            _config = self._prepare_params_engine(_config)

        if self.model_name:
            _config = self._prepare_params_model_id(_config)

        if self.log_url:
            _config['log_url'] = self.log_url

        if self.user_image_url:
            _config['user_image_url'] = self.user_image_url

        if self.user_command:
            _config['user_command'] = self.user_command

        if self.create_version:
            _config['create_version'] = self.create_version

        _config = self._prepare_params_input(inputs, dataset_id,
                                             dataset_version_id, data_source,
                                             _config)

        return _config

    def _prepare_params_engine(self, _config):
        """
        Set engine for job config.
        :param _config: check engine_id
        :return: _config['engine_id']
        """
        if self.framework_version and self.framework_type is None or \
                self.framework_version is None and self.framework_type:
            raise ValueError(
                'both framework_version and framework_type are needed')
        else:
            res = self.trainingJob.get_engine_list(
                self.session, job_type=self.job_type)
            res = self.trainingJob._transform_roma_response(res)
            engines = res['engines']
            for engine in engines:
                if engine['engine_name'] == self.framework_type and \
                        engine['engine_version'] == self.framework_version:
                    _config['engine_id'] = engine['engine_id']
        return _config

    def _prepare_params_model_id(self, _config):
        """
        Set model id for job config.
        :param _config: check model id
        :return: _config['model_id']
        """
        model_list = []
        model_id = ""
        res = self.trainingJob.get_built_in_algorithms(self.session)
        res = self.trainingJob._transform_roma_response(res)
        models = res['models']
        for model in models:
            model_list.append(model['model_name'])
            if model['model_name'] == self.model_name:
                model_id = model['model_id']
                break
        if self.model_name in model_list:
            _config['model_id'] = model_id
        else:
            raise ValueError('Invalid model_name')

        return _config

    def _prepare_params_spec_id(self, _config):
        """
        Set spec id for job config. There are three conditions:
        1. Only train_instance_type is provided, training job will be submitted to public pool
        2. Only pool_id is provided, training job will be submitted to dedicated pool and use the default specification
        3. Both pool_id and train_instance_type are provided, training job will be submitted to dedicated pool
           and use the specification specified by train_instance_type
        :param _config: check spec_id
        :return: _config['spec_id']
        """
        if not self.train_instance_type and not self.pool_id:
            raise ValueError('Parameter train_instance_type or pool_id is needed')

        if self.pool_id and not self.train_instance_type:
            _config['poolId'] = self.pool_id
            return _config

        flavor_list = []
        flavor_chosen = None
        res = self.trainingJob.get_flavor_list(self.session)
        res = self.trainingJob._transform_roma_response(res)
        flavors = res.get('flavors', [])
        for flavor in flavors:
            flavor_code = flavor.get("flavor_code")
            flavor_list.append(flavor_code)
            if flavor_code == self.train_instance_type:
                flavor_chosen = {"code": flavor_code}

        spec_list = []
        if flavor_chosen is None:
            spec_id = ""
            res = self.trainingJob.get_spec_list(self.session)
            res = self.trainingJob._transform_roma_response(res)
            specs = res['specs']
            for spec in specs:
                spec_list.append(spec['spec_code'])
                if spec['spec_code'] == self.train_instance_type:
                    spec_id = spec['spec_id']
            if self.train_instance_type in spec_list:
                _config['spec_id'] = spec_id
        else:
            if self.train_instance_type in flavor_list:
                _config['flavor'] = flavor_chosen

        if self.pool_id:
            if self.session.auth == constant.ROMA_AUTH:
                _config['flavor_code'] = self.train_instance_type
            else:
                _config['flavor'] = {'code': self.train_instance_type}
            _config['poolId'] = self.pool_id

        return _config

    def _prepare_params_input(self, inputs, dataset_id, dataset_version_id,
                              data_source, _config):
        """
        Set input path for job config.
        :param inputs: dataset from obs
        :param dataset_id: dataset_id of ModelArts
        :param dataset_version_id: dataset_version_id of ModelArts
        :param data_source: data_source of ModelArts
        :param _config: _config['data_url'] or _config['dataset_id'] and _config['dataset_id'] or _config['data_source']
        :return:
        """
        if inputs and dataset_id and dataset_version_id and data_source:
            raise ValueError('Pass either inputs or dataset_name and '
                             'dataset_version_id or data_source.')

        if (dataset_id and not dataset_version_id) or (
                not dataset_id and dataset_version_id):
            raise ValueError(
                'dataset_name and dataset_version_id are all needed.')

        if inputs:
            _config['data_url'] = inputs
        elif dataset_id and dataset_version_id:
            _config['dataset_id'] = dataset_id
            _config['dataset_version_id'] = dataset_version_id
        elif data_source:
            for source in data_source:
                if 'type' not in source:
                    raise ValueError(
                        'Parameter type is needed in data_source.')
            _config['data_source'] = data_source
        else:
            _config['enable_check'] = False

        return _config

    def start_new(self, inputs, dataset_id, dataset_version_id, data_source,
                  priority=constant.ROMA_TRAIN_JOB_DEFAULT_PRIORITY):
        """
        Create a new training job from the estimator.
        :param inputs: dataset from obs
        :param dataset_id: dataset_id of ModelArts
        :param dataset_version_id: dataset_version_id of ModelArts
        :param data_source: data_source of ModelArts
        :param priority: priority of train job
        :return: training job object
        """
        if self.train_instance_type and \
                self.train_instance_type in constant.LOCAL_TRAIN_TYPE:
            if inputs:
                self.local_train(inputs)
                return
            else:
                raise ValueError('Local train only supports parameter inputs.')
        _config = self.prepare_config(inputs, dataset_id, dataset_version_id,
                                      data_source, priority)

        _autosearch_config = dict()
        self.config_path = "" if self.config_path is None else self.config_path
        self.autosearch_path = "" if self.autosearch_path is None else self.autosearch_path
        _autosearch_config['config_path'] = self.config_path
        _autosearch_config['autosearch_path'] = self.autosearch_path

        body = {
            "job_name": self._current_job_name,
            "job_desc": self.job_description,
            "job_type": self.job_type,
            "autosearch_config": _autosearch_config,
            "config": _config
        }
        if self.workspace_id is not None:
            body["workspace_id"] = str(self.workspace_id)
        return self.trainingJob.create_training_job(body)

    def print_job_middle_state(self, job_train_resp):
        """
        Print Training Job Middle State.
        :param job_train_resp: contains job_name job_id and version_id
        :return: None
        """
        job_name = job_train_resp['job_name']
        job_id = job_train_resp['job_id']
        version_id = job_train_resp['version_id']

        count_init = 0
        count_running = 0
        count_waiting = 0
        count_deploying = 0
        while True:
            response, duration = self.get_job_state(job_id=job_id,
                                                    version_id=version_id)
            if response == 'JOBSTAT_COMPLETED':
                self.process_job_completed(response, duration, job_name)
                break
            elif response == 'JOBSTAT_INIT':
                count_init = self.process_job_uncompleted(response, count_init)
            elif response == 'JOBSTAT_WAITING':
                count_waiting = self.process_job_uncompleted(response, count_waiting)
            elif response == 'JOBSTAT_DEPLOYING':
                count_deploying = self.process_job_uncompleted(response, count_deploying)
            elif response == 'JOBSTAT_RUNNING':
                count_running = self.process_job_uncompleted(response, count_running)
            else:
                logging.info("Job [ %s ] status is %s, please check log", job_name, response)
                break

            count_total = count_init + count_running + count_waiting + count_deploying
            if count_total > int(
                    constant.MAXIMUM_RETRY_TIMES):
                logging.info("Reach the maximum start times, "
                             "the current status is %s", response)
                break

    @classmethod
    def get_job_list(cls, modelarts_session, **kwargs):
        """
        Get Training Job List.
        :param modelarts_session: session
        :param kwargs: support 'status', 'per_page', 'page', 'sortBy', 'order', 'search_content'
        :return:
        """
        training_job = cls(modelarts_session=modelarts_session).trainingJob
        return training_job._transform_roma_response(training_job.get_job_list(modelarts_session, **kwargs))

    def get_job_info(self):
        return self.trainingJob.get_job_info(self.job_id, self.version_id)

    def update_job_description(self, description):
        return self.trainingJob.update_job_description(description,
                                                       self.job_id)

    def get_job_log_file_list(self):
        return self.trainingJob.get_job_log_file_list(self.job_id,
                                                      self.version_id)

    def get_job_log(self, **kwargs):
        return self.trainingJob.get_job_log(self.job_id, self.version_id,
                                            **kwargs)

    def get_job_pool_list(self):
        return self.trainingJob.get_job_pool_list()

    def create_job_version(self, job_id, pre_version_id, inputs=None,
                           dataset_id=None, dataset_version_id=None,
                           data_source=None,
                           wait=False, job_desc=None,
                           priority=constant.ROMA_TRAIN_JOB_DEFAULT_PRIORITY):
        """
        Create Training Job Version for Specified job_id.
        :param job_id: job id
        :param pre_version_id: previous version id of training job
        :param inputs: dataset from obs
        :param dataset_id: dataset_id of ModelArts
        :param dataset_version_id: dataset_version_id of ModelArts
        :param data_source: data_source of ModelArts
        :param wait: whether wait the job completed or not
        :param job_desc: job description
        :param priority: train job priority for roma, 3 2 1 is high middle low
        :return:
        """
        _config = self.prepare_config(inputs, dataset_id, dataset_version_id,
                                      data_source, priority)
        _config['pre_version_id'] = pre_version_id
        body = {
            "config": _config
        }
        if job_desc:
            body['job_desc'] = job_desc
        create_response = self.trainingJob.create_job_version(job_id, body)
        response = self.trainingJob._transform_roma_response(create_response)
        if wait:
            self.print_job_middle_state(response)
        if not response['is_success']:
            raise Exception('Failed to create job version %s for %s' % (
                job_id, response['error_msg']))
        self.trainingJob.job_id = response['job_id']
        self.trainingJob.version_id = response['version_id']
        return self.trainingJob

    def get_job_version_info(self):
        """
        Get Training Job Version Info of Specified job_id.
        :param job_id: job id
        :return:
        """
        return self.trainingJob.get_job_version_info(self.job_id)

    def get_job_version_object_list(self, is_show=True):
        """
        Get Training Job Version List of Specified job_id.
        :param job_id: job id
        :return:
        """
        job_version_info_resp = self.trainingJob.get_job_version_info(
            self.job_id)
        training_job_object_list = []
        job_version_info_resp = self.trainingJob._transform_roma_response(
            job_version_info_resp)
        for job_version in job_version_info_resp['versions']:
            version_id = job_version['version_id']
            train_url = job_version['train_url']
            inputs = job_version['data_url']
            dataset_id = job_version['dataset_id']
            dataset_version_id = job_version['dataset_version_id']
            data_source = job_version['data_source']
            training_job_object_list.append(
                TrainingJob(modelarts_session=self.session,
                            job_id=self.job_id,
                            version_id=version_id,
                            train_url=train_url,
                            inputs=inputs,
                            dataset_id=dataset_id,
                            dataset_version_id=dataset_version_id,
                            data_source=data_source))
        if is_show:
            print(job_version_info_resp)

        return training_job_object_list

    def stop_job_version(self):
        """
        Stop Training Job Version of Specified job_id and version_id.
        """
        return self.trainingJob.stop_job_version(self.job_id, self.version_id)

    def delete_job_version(self):
        return self.trainingJob.delete_job_version(self.job_id,
                                                   self.version_id)

    def get_job_state(self, job_id, version_id):
        """
        Get Specified Training Job State of job_id and version_id.
        :param job_id: job id
        :param version_id: version id
        :return:
        """
        res = self.trainingJob.get_job_info(job_id, version_id)
        status_id = res['status']
        status = JOB_STATE[status_id]
        duration = res['duration']
        return status, duration

    @classmethod
    def get_engine_list(cls, modelarts_session, **kwargs):
        """
        Get Supported Engine List.
        :param modelarts_session: session
        :return:
        """
        return cls(
            modelarts_session=modelarts_session).trainingJob.get_engine_list(
            modelarts_session, **kwargs)

    @classmethod
    def get_framework_list(cls, modelarts_session, **kwargs):
        """
        Get Supported Framework List.
        :param modelarts_session: session
        :return:For example: [{'framework_type': 'TensorFlow', 'framework_version': 'TF-1.4.0-python2.7'},
                              {'framework_type': 'TensorFlow', 'framework_version': 'TF-1.4.0-python3.6'},
                              ...
                              {'framework_type': 'PyTorch', 'framework_version': 'PyTorch-1.0.0-python3.6'}]
        """
        return cls(
            modelarts_session=modelarts_session).trainingJob.get_framework_list(
            modelarts_session, **kwargs)

    @classmethod
    def get_built_in_algorithms(cls, modelarts_session):
        """
        Get Supported Built_in Algorithms.
        :param modelarts_session: session
        :return:
        """
        return cls(modelarts_session=modelarts_session).trainingJob. \
            get_built_in_algorithms(modelarts_session)

    def create_job_configs(self, config_name=None, inputs=None,
                           dataset_id=None, dataset_version_id=None,
                           data_source=None, config_desc=None):
        """
        Create Training Job Configs.
        :param config_name: config name
        :param inputs: dataset from obs
        :param config_desc: config description
        :return: job object
        """
        if not config_name:
            beijing_date = (datetime.now() + timedelta(hours=8)).strftime(
                constant.ISO_TIME_FORMAT)
            config_name = 'config-' + beijing_date
        _config = self.prepare_config(inputs, dataset_id, dataset_version_id,
                                      data_source)
        body = {"config_name": config_name}
        body.update(_config)
        if config_desc:
            body['config_desc'] = config_desc
        self.trainingJob.config_name = config_name
        response = self.trainingJob.create_job_configs(body)
        if not response['is_success']:
            raise Exception('Failed to create job configs %s for %s' % (
                config_name, response['error_msg']))
        return self.trainingJob

    def update_job_configs(self, config_name, inputs=None, dataset_id=None,
                           dataset_version_id=None, data_source=None,
                           config_desc=None):
        """
        Update Specified Training Job Configs.
        :param config_name: config name
        :param inputs: dataset from obs
        :param dataset_id: dataset_id of ModelArts
        :param dataset_version_id: dataset_version_id of ModelArts
        :param data_source: data_source of ModelArts
        :param config_desc: config description
        :return: whether success
        """
        _config = self.prepare_config(inputs, dataset_id, dataset_version_id,
                                      data_source)
        body = {}
        if config_desc:
            body = {'config_desc': config_desc}
        body.update(_config)
        return self.trainingJob.update_job_configs(config_name, body)

    def get_job_configs_info(self):
        return self.trainingJob.get_job_configs_info(self.config_name)

    def delete_job_configs(self):
        return self.trainingJob.delete_job_configs(self.config_name)

    @classmethod
    def get_job_configs_list(cls, modelarts_session, **kwargs):
        """
        Get Training Job Configs List.
        :param modelarts_session: session
        :param kwargs: support 'per_page', 'page', 'sortBy', 'order', 'search_content'
        :return:
        """
        return cls(modelarts_session=modelarts_session).trainingJob. \
            get_job_configs_list(modelarts_session, **kwargs)

    @classmethod
    def get_job_configs_object_list(cls, modelarts_session, is_show=True,
                                    **kwargs):
        """
        Get Training Job Configs List.
        :param modelarts_session: session
        :param kwargs: support 'per_page', 'page', 'sortBy', 'order', 'search_content'
        :return:
        """
        response = cls(modelarts_session=modelarts_session).trainingJob. \
            get_job_configs_list(modelarts_session, **kwargs)

        if not response['is_success']:
            raise Exception('Failed to get job configs list for %s' % (
                response['error_msg']))
        if is_show:
            print(response)
        configJob_list = []
        for config in response['configs']:
            config_name = config['config_name'] if config[
                'config_name'] else None
            configJob_list.append(
                TrainingJob(modelarts_session=modelarts_session,
                            config_name=config_name))
        return configJob_list

    @classmethod
    def get_train_instance_types(cls, modelarts_session):
        """
        Get Supported Train Instance Types.
        """
        return cls(modelarts_session=modelarts_session).trainingJob.get_train_instance_types(modelarts_session)

    @classmethod
    def get_spec_list(cls, modelarts_session):
        """
        Get Supported Spec List.
        """
        return cls(modelarts_session=modelarts_session).trainingJob.get_spec_list(modelarts_session)

    @classmethod
    def get_flavor_list(cls, modelarts_session):
        """
        Get Supported Spec List.
        """
        return cls(modelarts_session=modelarts_session).trainingJob.get_flavor_list(modelarts_session)

    @classmethod
    def get_predefined_flavors_dict(cls, modelarts_session):
        """
        Get Supported flavors dict.
        """
        return cls(modelarts_session=modelarts_session).trainingJob.get_predefined_flavors_dict(modelarts_session)

    @classmethod
    @DeprecationWarning
    def get_datasets(cls, modelarts_session, **kwargs):
        """
        Get Supported dataset.
        """
        return cls(modelarts_session=modelarts_session).trainingJob.get_datasets(modelarts_session, **kwargs)

    @classmethod
    def delete_job_by_id(cls, modelarts_session, job_id):
        return cls(modelarts_session=modelarts_session).trainingJob.delete_job(job_id)


class TrainingJob(TrainingJobBase):

    def __init__(self, modelarts_session, job_id=None, version_id=None,
                 train_url=None, inputs=None, dataset_id=None,
                 dataset_version_id=None, data_source=None, config_name=None):
        """
        Initialize a ModelArts Training Job instance.
        """
        super(TrainingJob, self).__init__(modelarts_session, job_id, train_url, inputs, dataset_id,
                                          dataset_version_id, data_source)
        self.version_id = version_id
        self.config_name = config_name
        self._training_job = _TrainingJobApiAKSKImpl(modelarts_session) \
            if modelarts_session.auth == constant.AKSK_AUTH else _TrainingJobApiRomaImpl(modelarts_session)

    def _transform_roma_response(self, response):
        return json.loads(response.content) \
            if self.modelarts_session.auth == constant.ROMA_AUTH else response

    def _check_version_id(self, version_id):
        """
        :param version_id: version id
        :return:
        """
        if not version_id and not self.version_id:
            raise ValueError('Parameter version_id is needed')
        return version_id if version_id else self.version_id

    def _check_config_name(self, config_name):
        """
        :param config_name: config name
        :return:
        """
        if not config_name and not self.config_name:
            raise ValueError('Parameter config_name is needed')
        return config_name if config_name else self.config_name

    @classmethod
    def get_job_list(cls, modelarts_session, **kwargs):
        """
        Get Training Job List.
        :param modelarts_session: session
        :param kwargs: support 'status', 'per_page', 'page', 'sortBy', 'order', 'search_content'
        :return:
        """
        return cls(
            modelarts_session=modelarts_session)._training_job.get_job_list(
            modelarts_session, **kwargs)

    def get_job_info(self, job_id=None, version_id=None):
        """
        Get Training Job Info of Specified job_id and version_id.
        :param job_id: job id
        :param version_id: version id
        :return:
        """
        job_id = self._check_job_id(job_id)
        version_id = self._check_version_id(version_id)
        response = self._training_job.get_job_info(job_id, version_id)
        response = self._transform_roma_response(response)
        if not response['is_success']:
            raise Exception('Failed to get job info with the job_id %s and '
                            'version_id %s for'
                            ' %s' % (job_id, version_id, response['error_msg']))
        return response

    def get_waiting_job_info(self, version_uid=None):
        """
        Get waiting job info
        :param version_uid: version uid
        :return:
        """
        version_uid = self._check_version_id(version_uid)
        response = self._training_job.get_waiting_job_info(version_uid)
        response_content = self._transform_roma_response(response)
        if not response_content['is_success']:
            raise Exception('Failed to get waiting job info with version_uid %s for'
                            ' %s' % (version_uid, response_content['error_msg']))
        return response_content

    def create_job_version(self, job_id, body):
        """
        Create Training Job Version for Specified job_id.
        :param job_id: job id
        :param body: body for create job version
        :return:
        """
        job_id = self._check_job_id(job_id)
        return self._training_job.create_job_version(job_id, body)

    def get_job_version_info(self, job_id=None):
        """
        Get Training Job Version Info of Specified job_id.
        :param job_id: job id
        :return:
        """
        job_id = self._check_job_id(job_id)
        job_version_info_resp = self._training_job.get_job_version_info(job_id)

        return job_version_info_resp

    def stop_job_version(self, job_id=None, version_id=None):
        """
        Stop Training Job Version of Specified job_id and version_id.
        :param job_id: job id
        :param version_id: version id
        :return:
        """
        job_id = self._check_job_id(job_id)
        version_id = self._check_version_id(version_id)
        response = self._training_job.stop_job_version(job_id, version_id)
        response = self._transform_roma_response(response)
        if response['is_success']:
            logging.info('Successfully stop the job version with the job_id %s and '
                         'version_id %s', job_id, version_id)
        else:
            raise Exception('Failed to stop the job version with the job_id %s '
                            'and version_id %s for %s' % (
                                job_id, version_id, response['error_msg']))
        return response

    def delete_job_version(self, job_id=None, version_id=None):
        """
        Delete Training Job Version of Specified job_id and version_id.
        :param job_id: job id
        :param version_id: version id
        :return:
        """
        job_id = self._check_job_id(job_id)
        version_id = self._check_version_id(version_id)
        response = self._training_job.delete_job_version(job_id, version_id)
        response = self._transform_roma_response(response)
        if response['is_success']:
            logging.info('Successfully delete the job version with the job_id %s and '
                         'version_id %s', job_id, version_id)
        else:
            raise Exception('Failed to delete the job version with the '
                            'job_id %s and version_id %s for %s' % (
                                job_id, version_id, response['error_msg']))
        return response

    def update_job_description(self, description, job_id=None):
        """
        Update Training Job Description for Specified job_id.
        :param description: job description
        :param job_id: job_id
        :return:
        """
        job_id = self._check_job_id(job_id)
        body = {'job_desc': description}
        response = self._training_job.update_job_description(job_id, body)
        response = self._transform_roma_response(response)
        if response['is_success']:
            logging.info('Successfully update the job %s description', job_id)
        else:
            raise Exception(
                'Failed to update the job %s description for %s' % (
                    job_id, response['error_msg']))
        return response

    def get_job_log_file_list(self, job_id=None, version_id=None):
        """
        Get Training Job Log File List of Specified job_id and version_id.
        :param job_id: job_id
        :param version_id: version_id
        :return:
        """
        job_id = self._check_job_id(job_id)
        version_id = self._check_version_id(version_id)
        return self._training_job.get_job_log_file_list(job_id, version_id)

    def get_job_log(self, job_id=None, version_id=None, **kwargs):
        """
        Get Training Job Log of Specified job_id and version_id.
        :param job_id: job_id
        :param version_id: version_id
        :param kwargs: support 'start_byte', 'offset'
        :return:
        """
        job_id = self._check_job_id(job_id)
        version_id = self._check_version_id(version_id)
        return self._training_job.get_job_log(job_id, version_id, **kwargs)

    def get_job_pool_list(self):
        """
        Get training job pool list.
        """
        if self.modelarts_session.auth == constant.ROMA_AUTH:
            return self._training_job.get_job_pool_list()
        else:
            logging.info("Only roma supports querying dedicated resource pools.")

    @classmethod
    def get_engine_list(cls, modelarts_session, **kwargs):
        """
        Get Supported Engine List.
        """
        return cls(
            modelarts_session=modelarts_session)._training_job.get_engine_list(
            modelarts_session, **kwargs)

    @classmethod
    def get_framework_list(cls, modelarts_session, **kwargs):
        """
        Get Supported Framework List.
        """
        session = cls(modelarts_session=modelarts_session)
        engine_list = session._training_job.get_engine_list(
            modelarts_session, **kwargs)
        return session._training_job.get_framework_list(modelarts_session,
                                                        engine_list)

    @classmethod
    def get_built_in_algorithms(cls, modelarts_session):
        """
        Get Supported Built_in Algorithms.
        :param modelarts_session: session
        :return:
        """
        return cls(
            modelarts_session=modelarts_session)._training_job.get_built_in_algorithms(
            modelarts_session)

    def delete_job(self, job_id=None):
        """
        Delete Specified Training Job.
        :param job_id: job id
        :return:
        """
        job_id = self._check_job_id(job_id)
        self._training_job.delete_job(job_id)
        count = 0
        while True:
            job_list = self._training_job.get_job_list(self.modelarts_session)
            if job_id in job_list:
                count = count + 1
                time.sleep(3)
            else:
                logging.info('Successfully delete the job %s', job_id)
                break
            if count == int(constant.JOB_DELETE_RETRY_TIMES):
                logging.info('Job %s is not deleted after 15s, please check it '
                             'from UI', job_id)
                break
        if job_id is None:
            self.job_id = None

    def create_job_configs(self, body):
        """
        Create Training Job Configs.
        :param body: request body param
        :return:
        """
        self.config_name = body['config_name']
        response = self._training_job.create_job_configs(body)
        self._transform_roma_response(response)
        if response['is_success']:
            logging.info('Successfully create the job config %s', self.config_name)
        else:
            raise Exception('Failed to create the job config %s for %s' % (
                self.config_name, response['error_msg']))
        return response

    @classmethod
    def get_job_configs_list(cls, modelarts_session, **kwargs):
        """
        Get Training Job Configs List.
        :param modelarts_session: session
        :param kwargs: support 'per_page', 'page', 'sortBy', 'order', 'search_content'
        :return:
        """
        return cls(modelarts_session=modelarts_session)._training_job. \
            get_job_configs_list(modelarts_session, **kwargs)

    def get_job_configs_info(self, config_name=None):
        """
        Get Specified Training Job Configs Info.
        :param config_name: config name
        :return:
        """
        config_name = self._check_config_name(config_name)
        return self._training_job.get_job_configs_info(config_name)

    def update_job_configs(self, config_name, body):
        """
        Update Specified Training Job Configs.
        :param config_name: config name
        :param body:
        :return:
        """
        response = self._training_job.update_job_configs(config_name, body)
        self._transform_roma_response(response)
        if response['is_success']:
            logging.info('Successfully update the job config %s', config_name)
        else:
            raise Exception('Failed to update the job config %s for %s' % (
                config_name, response['error_msg']))
        return response

    def delete_job_configs(self, config_name=None):
        """
        Delete Specified Training Job Configs.
        :param config_name: config name
        :return:
        """
        config_name = self._check_config_name(config_name)
        response = self._training_job.delete_job_configs(config_name)
        self._transform_roma_response(response)
        if response['is_success']:
            logging.info('Successfully delete the job config %s', config_name)
        else:
            raise Exception('Failed to delete the job config %s for %s' % (
                config_name, response['error_msg']))
        return response

    @classmethod
    def get_train_instance_types(cls, modelarts_session):
        """
        Get Supported Train Instance Types.
        """
        session = cls(modelarts_session=modelarts_session)
        flavor_list = session._training_job.get_flavor_list(modelarts_session)
        return session._training_job.get_train_instance_types(modelarts_session, flavor_list)

    @classmethod
    def get_spec_list(cls, modelarts_session):
        """
        Get Supported Spec List.
        """
        return cls(modelarts_session=modelarts_session)._training_job.get_spec_list(modelarts_session)

    @classmethod
    def get_flavor_list(cls, modelarts_session):
        """
        Get Supported Spec List.
        """
        return cls(modelarts_session=modelarts_session)._training_job.get_flavor_list(modelarts_session)

    @classmethod
    def get_pools_list(cls, modelarts_session):
        """
        Get Supported pools List.
        """
        return cls(modelarts_session=modelarts_session)._training_job.get_pools_list(modelarts_session)

    @classmethod
    def get_predefined_flavors_dict(cls, modelarts_session):
        """
        Get Supported Predefined Flavors List.
        """
        session = cls(modelarts_session=modelarts_session)
        pools_list = session._training_job.get_pools_list(modelarts_session)
        return session._training_job.get_predefined_flavors_dict(modelarts_session, pools_list)

    @classmethod
    @DeprecationWarning
    def get_datasets(cls, modelarts_session, **kwargs):
        """
        Get Supported dataset.
        """
        return cls(
            modelarts_session=modelarts_session)._training_job.get_datasets(
            modelarts_session, **kwargs)


class _TrainingJobApiAKSKImpl(TrainingJob):

    def __init__(self, modelarts_session):
        """
        Initialize a ModelArts Training Job instance when using AKSK auth.
        """
        self.modelarts_session = modelarts_session

    @classmethod
    @auth_expired_handler
    def get_job_list(cls, modelarts_session, **kwargs):
        """
        Get Training Job List.
        :param modelarts_session: session
        :param kwargs: support 'status', 'per_page', 'page', 'sortBy', 'order', 'search_content'
        :return:
        """
        request_url = '/v1/' + modelarts_session.project_id + '/training-jobs'
        variable_name = locals()['kwargs']
        params = {'status', 'per_page', 'page', 'sortBy', 'order',
                  'search_content'}
        query = {}
        for param in params:
            if param in variable_name and variable_name[param]:
                query[param] = str(variable_name[param])
        return auth_by_apig(modelarts_session, HTTPS_GET, request_url, query=query)

    @auth_expired_handler
    def get_job_info(self, job_id, version_id):
        """
        Get Training Job Info of Specified job_id and version_id.
        :param job_id: job id
        :param version_id: version id
        :return:
        """
        request_url = '/v1/{}/training-jobs/{}/versions/{}'.format(
            self.modelarts_session.project_id,
            str(job_id), str(version_id))
        return auth_by_apig(self.modelarts_session, HTTPS_GET, request_url)

    @auth_expired_handler
    def delete_job_version(self, job_id, version_id):
        """
        Delete Training Job Version of Specified job_id and version_id.
        :param job_id: job id
        :param version_id: version id
        :return:
        """
        request_url = '/v1/' + self.modelarts_session.project_id + \
                      '/training-jobs/' + \
                      str(job_id) + '/versions/' + str(version_id)
        return auth_by_apig(self.modelarts_session, HTTPS_DELETE, request_url)

    @auth_expired_handler
    def get_job_version_info(self, job_id):
        """
        Get Training Job Version Info of Specified job_id.
        :param job_id:job id
        :return:
        """
        request_url = '/v1/' + self.modelarts_session.project_id + \
                      '/training-jobs/' + str(job_id) + '/versions'
        return auth_by_apig(self.modelarts_session, HTTPS_GET, request_url)

    @auth_expired_handler
    def create_job_version(self, job_id, body):
        """
        Create Training Job Version for Specified job_id.
        :param job_id: job id
        :param body: request body
        :return:
        """
        request_url = '/v1/' + self.modelarts_session.project_id + \
                      '/training-jobs/' + str(job_id) + '/versions'
        body_encode = JSONEncoder().encode(body)
        return auth_by_apig(
            self.modelarts_session, HTTPS_POST, request_url, body=body_encode)

    @auth_expired_handler
    def stop_job_version(self, job_id, version_id):
        """
        Stop Training Job Version of Specified job_id and version_id.
        :param job_id: job id
        :param version_id: version id
        :return:
        """
        request_url = '/v1/' + self.modelarts_session.project_id + '/training-jobs/' + \
                      str(job_id) + '/versions/' + str(version_id) + '/stop'
        return auth_by_apig(self.modelarts_session, HTTPS_POST, request_url)

    @auth_expired_handler
    def update_job_description(self, job_id, body):
        """
        Update Training Job Description for Specified job_id.
        :param job_id: job id
        :param body: request body
        :return:
        """
        request_url = '/v1/' + self.modelarts_session.project_id + \
                      '/training-jobs/' + str(job_id)
        body_encode = JSONEncoder().encode(body)
        return auth_by_apig(
            self.modelarts_session, HTTPS_PUT, request_url, body=body_encode)

    @auth_expired_handler
    def get_job_log_file_list(self, job_id, version_id):
        """
        Get Training Job Log File List of Specified job_id and version_id.
        :param job_id: job id
        :param version_id: version id
        :return:
        """
        request_url = '/v1/' + self.modelarts_session.project_id + \
                      '/training-jobs/' + str(job_id) + '/versions/' + \
                      str(version_id) + '/log/file-names'
        return auth_by_apig(self.modelarts_session, HTTPS_GET, request_url)

    @auth_expired_handler
    def get_job_log(self, job_id, version_id, **kwargs):
        """
        Get Training Job Log of Specified job_id and version_id.
        :param job_id: job id
        :param version_id: version id
        :param kwargs: support 'start_byte', 'offset'
        :return:
        """
        variable_name = locals()['kwargs']
        if 'log_file' not in variable_name:
            raise ValueError('Parameter log_file is needed')

        request_url = '/v1/' + self.modelarts_session.project_id + \
                      '/training-jobs/' + \
                      str(job_id) + '/versions/' + str(version_id) + '/aom-log'
        query = {}
        params = {'base_line', 'lines', 'log_file', 'order'}
        for param in params:
            if param in variable_name and variable_name[param]:
                query[param] = str(variable_name[param])

        return auth_by_apig(self.modelarts_session, HTTPS_GET, request_url, query=query)

    @classmethod
    @auth_expired_handler
    def get_spec_list(cls, modelarts_session):
        """
        Get Supported Spec List.
        :param modelarts_session: session
        :return:
        """
        request_url = '/v1/' + modelarts_session.project_id + \
                      '/job/resource-specs'
        return auth_by_apig(modelarts_session, HTTPS_GET, request_url)

    @classmethod
    @auth_expired_handler
    def get_flavor_list(cls, modelarts_session):
        """
        Get Supported Flavors List.
        :param modelarts_session: session
        :return:
        """
        request_url = '/v1/' + modelarts_session.project_id + \
                      '/flavors'
        return auth_by_apig(modelarts_session, HTTPS_GET, request_url)

    @classmethod
    @auth_expired_handler
    def get_pools_list(cls, modelarts_session):
        """
        Get Supported Spec List.
        :param modelarts_session: session
        :return:
        """
        request_url = '/v1/' + modelarts_session.project_id + \
                      '/pools'
        return auth_by_apig(modelarts_session, HTTPS_GET, request_url)

    @classmethod
    def get_predefined_flavors_dict(cls, modelarts_session, pools_info):
        """
        Get Supported Predefined Flavors list.
        :param modelarts_session: session
        :param pools_info:
        :return: For example:
                     {'poolxxxxx' : ['modelarts.bm.gpu.v100.4.predefined', 'modelarts.bm.gpu.v100.2.predefined'],
                      'poolxxxxx' : ['modelarts.bm.gpu.v100.predefined', 'modelarts.bm.gpu.8v100.predefined']}
        """
        predefined_flavors_dict = dict()
        for pool_info in pools_info['pools']:
            pool_id = pool_info['pool_id']
            supported_flavors = []
            for predefined_flavors in pool_info['predefined_flavors']:
                supported_flavors.append(predefined_flavors['flavor_code'])
            predefined_flavors_dict[pool_id] = supported_flavors
        return predefined_flavors_dict

    @classmethod
    def get_train_instance_types(cls, modelarts_session, flavor_info):
        """
        Get Supported Train Instance Types.
        :param modelarts_session: session
        :param flavor_info: flavor info
        :return: For example: ['modelarts.vm.cpu.2u', 'modelarts.vm.gpu.v100NV32']
        """
        flavor_list = []
        flavors = flavor_info['flavors']
        for flavor in flavors:
            flavor_list.append(flavor['flavor_code'])
        return flavor_list

    @classmethod
    @auth_expired_handler
    def get_engine_list(cls, modelarts_session, **kwargs):
        """
        Get Supported Engine List.
        :param modelarts_session: session
        :return:
        """
        request_url = '/v1/' + modelarts_session.project_id + '/job/ai-engines'

        variable_name = locals()['kwargs']
        params = {'job_type'}
        query = {}
        for param in params:
            if param in variable_name and variable_name[param]:
                query[param] = str(variable_name[param])
        return auth_by_apig(modelarts_session, HTTPS_GET, request_url, query=query)

    @classmethod
    def get_framework_list(cls, modelarts_session, engine_list):
        """
        Get Supported Framework List.
        :param modelarts_session: session
        :param engine_list: engine list
        :return: For example: [{'framework_type': 'TensorFlow', 'framework_version': 'TF-1.4.0-python2.7'},
                               {'framework_type': 'TensorFlow', 'framework_version': 'TF-1.4.0-python3.6'},
                               ...
                               {'framework_type': 'PyTorch', 'framework_version': 'PyTorch-1.0.0-python3.6'}]
        """
        framework_list = []
        engines = engine_list['engines']
        for engine in engines:
            framework = {'framework_type': engine['engine_name'],
                         'framework_version': engine['engine_version']}
            framework_list.append(framework)
        return framework_list

    @classmethod
    @auth_expired_handler
    def get_built_in_algorithms(cls, modelarts_session):
        """
        Get Supported Built_in Algorithms.
        :param modelarts_session: session
        :return:
        """
        request_url = '/v1/' + modelarts_session.project_id + \
                      '/built-in-algorithms'
        return auth_by_apig(modelarts_session, HTTPS_GET, request_url)

    @classmethod
    @DeprecationWarning
    @auth_expired_handler
    def get_datasets(cls, modelarts_session, **kwargs):
        """
        :param modelarts_session: session
        :param kwargs:
        :return:
        """
        request_url = '/v1/' + modelarts_session.project_id + '/datasets'
        variable_name = locals()['kwargs']
        params = {'offset', 'limit', 'sortBy', 'order', 'search_content',
                  'data_url'}
        query = {}
        for param in params:
            if param in variable_name and variable_name[param]:
                query[param] = str(variable_name[param])
        return auth_by_apig(modelarts_session, HTTPS_GET, request_url, query=query)

    @auth_expired_handler
    def create_training_job(self, body):
        """
        Create Training Job.
        :param body: request body
        :return:
        """
        request_url = '/v1/' + self.modelarts_session.project_id + \
                      '/training-jobs'
        body_encode = JSONEncoder().encode(body)
        return auth_by_apig(
            self.modelarts_session, HTTPS_POST, request_url, body=body_encode)

    @auth_expired_handler
    def delete_job(self, job_id):
        """
        Delete Specified Training Job.
        :param job_id: job id
        :return:
        """
        request_url = '/v1/' + self.modelarts_session.project_id + \
                      '/training-jobs/' + str(job_id)
        auth_by_apig(self.modelarts_session, HTTPS_DELETE, request_url)

    @auth_expired_handler
    def create_job_configs(self, body):
        """
        Create Training Job Configs.
        :param body: request body
        :return:
        """
        request_url = '/v1/' + self.modelarts_session.project_id + \
                      '/training-job-configs'
        body_encode = JSONEncoder().encode(body)
        return auth_by_apig(
            self.modelarts_session, HTTPS_POST, request_url, body=body_encode)

    @classmethod
    @auth_expired_handler
    def get_job_configs_list(cls, modelarts_session, **kwargs):
        """
        Get Training Job Configs List.
        :param modelarts_session: session
        :param kwargs: support 'per_page', 'page', 'sortBy', 'order', 'search_content'
        :return:
        """
        request_url = '/v1/' + modelarts_session.project_id + \
                      '/training-job-configs'
        variable_name = locals()['kwargs']
        params = {'per_page', 'page', 'sortBy', 'order', 'search_content'}
        query = {}
        for param in params:
            if param in variable_name and variable_name[param]:
                query[param] = str(variable_name[param])
        return auth_by_apig(modelarts_session, HTTPS_GET, request_url, query=query)

    @auth_expired_handler
    def get_job_configs_info(self, config_name):
        """
        Get Specified Training Job Configs Info.
        :param config_name: config name
        :return:
        """
        request_url = '/v1/' + self.modelarts_session.project_id + \
                      '/training-job-configs/' + config_name
        return auth_by_apig(self.modelarts_session, HTTPS_GET, request_url)

    @auth_expired_handler
    def update_job_configs(self, config_name, body):
        """
        Update Specified Training Job Configs.
        :param config_name: config name
        :param body: request body
        :return:
        """
        request_url = '/v1/' + self.modelarts_session.project_id + \
                      '/training-job-configs/' + config_name
        body_encode = JSONEncoder().encode(body)
        return auth_by_apig(
            self.modelarts_session, HTTPS_PUT, request_url, body=body_encode)

    @auth_expired_handler
    def delete_job_configs(self, config_name):
        """
        Delete Specified Training Job Configs.
        :param config_name: config name
        :return:
        """
        request_url = '/v1/' + self.modelarts_session.project_id + \
                      '/training-job-configs/' + config_name
        return auth_by_apig(self.modelarts_session, HTTPS_DELETE, request_url)

    @auth_expired_handler
    def create_visualization_job(self, body):
        """
        Create Visualization Job.
        :param body: request body
        :return:
        """
        request_url = '/v1/' + self.modelarts_session.project_id + \
                      '/visualization-jobs'
        body_encode = JSONEncoder().encode(body)
        return auth_by_apig(
            self.modelarts_session, HTTPS_POST, request_url, body=body_encode)

    @classmethod
    @auth_expired_handler
    def get_visualization_job_list(cls, modelarts_session, **kwargs):
        """
        Get Visualization Job List.
        :param modelarts_session: session
        :param kwargs: support 'status', 'per_page', 'page', 'sortBy', 'order', 'search_content'
        :return:
        """
        request_url = '/v1/' + modelarts_session.project_id + \
                      '/visualization-jobs'

        variable_name = locals()['kwargs']
        params = {'status', 'per_page', 'page', 'sortBy', 'order',
                  'search_content'}
        query = {}
        for param in params:
            if param in variable_name and variable_name[param]:
                query[param] = str(variable_name[param])
        return auth_by_apig(modelarts_session, HTTPS_GET, request_url, query=query)

    @auth_expired_handler
    def get_visualization_job_info(self, job_id):
        """
        Get Specified Visualization Job Info.
        :param job_id: job id
        :return:
        """
        request_url = '/v1/' + self.modelarts_session.project_id + \
                      '/visualization-jobs/' + job_id
        return auth_by_apig(self.modelarts_session, HTTPS_GET, request_url)

    @auth_expired_handler
    def update_visualization_job(self, job_id, body):
        """
        Update Specified Visualization Job.
        :param job_id: job id
        :param body: request body
        :return:
        """
        request_url = '/v1/' + self.modelarts_session.project_id + \
                      '/visualization-jobs/' + job_id
        body_encode = JSONEncoder().encode(body)
        return auth_by_apig(
            self.modelarts_session, HTTPS_PUT, request_url, body=body_encode)

    @auth_expired_handler
    def delete_visualization_job(self, job_id):
        """
        Delete Specified Visualization Job.
        :param job_id: job id
        :return:
        """
        request_url = '/v1/' + self.modelarts_session.project_id + \
                      '/visualization-jobs/' + job_id
        return auth_by_apig(self.modelarts_session, HTTPS_DELETE, request_url)

    @auth_expired_handler
    def restart_visualization_job(self, job_id):
        """
        Restart Specified Visualization Job.
        :param job_id: job id
        :return:
        """
        request_url = '/v1/' + self.modelarts_session.project_id + \
                      '/visualization-jobs/' + job_id + '/restart'
        return auth_by_apig(self.modelarts_session, HTTPS_POST, request_url)

    @auth_expired_handler
    def stop_visualization_job(self, job_id):
        """
        Stop Specified Visualization Job.
        :param job_id: job id
        :return:
        """
        request_url = '/v1/' + self.modelarts_session.project_id + \
                      '/visualization-jobs/' + job_id + '/stop'
        return auth_by_apig(self.modelarts_session, HTTPS_POST, request_url)


class _TrainingJobApiRomaImpl(TrainingJob):

    def __init__(self, modelarts_session):
        """
        Initialize a ModelArts Training Job instance when using Roma auth.
        """
        self.modelarts_session = modelarts_session

    def check_roma_response(self, response):
        error_code = response.status_code
        if response.status_code > 500:
            raise RomaException(code=error_code, message=response.content)
        if response.status_code > 300:
            error_message = json.loads(response.content)[
                'error_msg'] if 'error_msg' in json.loads(
                response.content) else response.content
            raise RomaException(code=error_code, message=error_message)

    @classmethod
    def get_job_list(cls, modelarts_session, **kwargs):
        """
        Get Training Job List.
        :param modelarts_session: session
        :param kwargs: support 'status', 'per_page', 'page', 'sortBy', 'order', 'search_content'
        :return:
        """
        request_url = modelarts_session.host + '/v1/' + \
                      modelarts_session.project_id + '/training-jobs'
        variable_name = locals()['kwargs']
        params = {'status', 'per_page', 'page', 'sortBy', 'order',
                  'search_content'}
        query = ''
        for param in params:
            if param in variable_name and variable_name[param]:
                query = query + param + '=' + str(variable_name[param]) + '&'
        query = query[:-1]
        try:
            response = requests.get(request_url,
                                    headers=modelarts_session.headers,
                                    params=query, verify=False)
            cls(modelarts_session=modelarts_session).check_roma_response(
                response)
            return response
        except Exception as e:
            raise Exception("Failed to get job list {}".format(e))

    def get_job_info(self, job_id, version_id):
        """
        Get Training Job Info of Specified job_id and version_id.
        :param job_id: job id
        :param version_id: version id
        :return:
        """
        request_url = self.modelarts_session.host + '/v1/' + \
                      self.modelarts_session.project_id + '/training-jobs/' \
                      + str(job_id) + '/versions/' + str(version_id)
        try:
            response = requests.get(request_url,
                                    headers=self.modelarts_session.headers,
                                    verify=False)
            self.check_roma_response(response)
            return response
        except Exception as e:
            raise Exception("Failed to get job info {}".format(e))

    def get_waiting_job_info(self, version_uid):
        """
        Get training job info which is waiting in roma
        :param version_uid: version uid of job in roma
        """
        request_url = self.modelarts_session.host + '/v1/' + self.modelarts_session.project_id + \
                      '/training-jobs/waiting/job?version_uid=' + version_uid
        try:
            response = requests.get(request_url,
                                    headers=self.modelarts_session.headers,
                                    verify=False)
            self.check_roma_response(response)
            return response
        except Exception as e:
            raise Exception("Failed to get job info {}".format(e))

    def delete_job_version(self, job_id, version_id):
        """
        Delete Training Job Version of Specified job_id and version_id.
        :param job_id: job id
        :param version_id: version id
        :return:
        """
        request_url = self.modelarts_session.host + '/v1/' + \
                      self.modelarts_session.project_id + '/training-jobs/' + \
                      str(job_id) + '/versions/' + str(version_id)
        try:
            response = requests.delete(request_url,
                                       headers=self.modelarts_session.headers,
                                       verify=False)
            self.check_roma_response(response)
            return response
        except Exception as e:
            raise Exception("Failed to delete job version, {}".format(e))

    @staticmethod
    def response_to_dict(response):
        """
        Turn http response to dictionary.
        :param response: http response
        :return: http response in the format of dictionary
        """
        content_str = str(response.content, encoding="utf-8")
        return json.loads(content_str)

    def get_job_version_info(self, job_id):
        """
        Get Training Job Version Info of Specified job_id.
        :param job_id: job id
        :return:
        """
        request_url = self.modelarts_session.host + '/v1/' + \
                      self.modelarts_session.project_id + \
                      '/training-jobs/' + str(job_id) + '/versions'
        try:
            response = requests.get(request_url,
                                    headers=self.modelarts_session.headers,
                                    verify=False)
            self.check_roma_response(response)
            return self.response_to_dict(response)
        except Exception as e:
            raise Exception("Failed to get job version info, {}".format(e))

    def create_job_version(self, job_id, body):
        """
        Create Training Job Version for Specified job_id.
        :param job_id: job id
        :param body: request body
        :return:
        """
        request_url = self.modelarts_session.host + '/v1/' + \
                      self.modelarts_session.project_id + \
                      '/training-jobs/' + str(job_id) + '/versions'
        try:
            body = json.loads(json.dumps(str(body).replace("\'", "\"")))
            response = requests.post(request_url,
                                     headers=self.modelarts_session.headers,
                                     data=body, verify=False)
            self.check_roma_response(response)
            return response
        except Exception as e:
            raise Exception("Failed to create job version, {}".format(e))

    def stop_job_version(self, job_id, version_id):
        """
        Stop Training Job Version of Specified job_id and version_id.
        :param job_id: job id
        :param version_id:
        :return:
        """
        request_url = self.modelarts_session.host + '/v1/' + \
                      self.modelarts_session.project_id + \
                      '/training-jobs/' + str(job_id) + '/versions/' + \
                      str(version_id) + '/stop'
        try:
            response = requests.post(request_url,
                                     headers=self.modelarts_session.headers,
                                     verify=False)
            self.check_roma_response(response)
            return response
        except Exception as e:
            raise Exception("Failed to stop job version, {}".format(e))

    def update_job_description(self, job_id, body):
        """
        Update Training Job Description for Specified job_id.
        :param job_id: job id
        :param body: request body
        :return:
        """
        request_url = self.modelarts_session.host + '/v1/' + \
                      self.modelarts_session.project_id + \
                      '/training-jobs/' + str(job_id)
        try:
            body = json.loads(json.dumps(str(body).replace("\'", "\"")))
            response = requests.put(request_url,
                                    headers=self.modelarts_session.headers,
                                    data=body, verify=False)
            self.check_roma_response(response)
            return response
        except Exception as e:
            raise Exception("Failed to update job description, {}".format(e))

    def get_job_log_file_list(self, job_id, version_id):
        """
        Get Training Job Log File List of Specified job_id and version_id.
        :param job_id: job id
        :param version_id: version id
        :return:
        """
        request_url = self.modelarts_session.host + '/v1/' + \
                      self.modelarts_session.project_id + '/training-jobs/' + \
                      str(job_id) + '/versions/' + \
                      str(version_id) + '/log/file-names'
        try:
            response = requests.get(request_url,
                                    headers=self.modelarts_session.headers,
                                    verify=False)
            self.check_roma_response(response)
            return json.loads(response.content)
        except Exception as e:
            raise Exception("Failed to get job log file list, {}".format(e))

    def get_job_log(self, job_id, version_id, **kwargs):
        """
        Get Training Job Log of Specified job_id and version_id.
        :param job_id: job id
        :param version_id: version id
        :param kwargs: support 'start_byte', 'offset'
        :return:
        """
        request_url = self.modelarts_session.host + '/v1/' + \
                      self.modelarts_session.project_id + \
                      '/training-jobs/' + str(job_id) + '/versions/' + \
                      str(version_id) + '/log'

        variable_name = locals()['kwargs']
        params = {'start_byte', 'offset', 'log_file'}
        query = ''
        for param in params:
            if param in variable_name and variable_name[param]:
                query = query + param + '=' + str(variable_name[param]) + '&'
        query = query[:-1]

        try:
            response = requests.get(request_url,
                                    headers=self.modelarts_session.headers,
                                    params=query, verify=False)
            self.check_roma_response(response)
            return response.content.decode('utf-8')
        except Exception as e:
            raise Exception("Failed to get job log, {}".format(e))

    def get_job_pool_list(self):
        """
        Get training job list.
        """
        request_url = self.modelarts_session.host + '/v1/' + self.modelarts_session.project_id + '/pools'
        try:
            response = requests.get(request_url, headers=self.modelarts_session.headers, verify=False)
            self.check_roma_response(response)
            return json.loads(response.content)
        except Exception as e:
            raise Exception("Failed to get job pool list, error={}".format(e))

    @classmethod
    def get_spec_list(cls, modelarts_session):
        """
        Get Supported Spec List.
        :param modelarts_session: session
        :return:
        """
        request_url = modelarts_session.host + '/v1/' + \
                      modelarts_session.project_id + '/job/resource-specs'
        try:
            response = requests.get(request_url,
                                    headers=modelarts_session.headers,
                                    verify=False)
            cls(modelarts_session=modelarts_session).check_roma_response(
                response)
            return response
        except Exception as e:
            raise Exception("Failed to get spec list, {}".format(e))

    @classmethod
    def get_flavor_list(cls, modelarts_session):
        """
        Get Supported Flavors List.
        :param modelarts_session: session
        :return:
        """
        request_url = modelarts_session.host + '/v1/' + \
                      modelarts_session.project_id + '/flavors'
        try:
            response = requests.get(request_url,
                                    headers=modelarts_session.headers,
                                    verify=False)
            cls(modelarts_session=modelarts_session).check_roma_response(
                response)
            return response
        except Exception as e:
            raise Exception("Failed to get flavor list, {}".format(e))

    @classmethod
    def get_pools_list(cls, modelarts_session):
        """
        Get Supported pools List.
        :param modelarts_session: session
        :return:
        """
        request_url = modelarts_session.host + '/v1/' + \
                      modelarts_session.project_id + '/pools'
        try:
            response = requests.get(request_url,
                                    headers=modelarts_session.headers,
                                    verify=False)
            cls(modelarts_session=modelarts_session).check_roma_response(
                response)
            return response
        except Exception as e:
            raise Exception("Failed to get pools list, {}".format(e))

    @classmethod
    def get_predefined_flavors_dict(cls, modelarts_session, pools_info):
        """
        Get Supported Predefined Flavors list.
        :param modelarts_session: session
        :param pools_info:
        :return: For example:
                    {'poolxxxxx' : ['modelarts.bm.gpu.v100.4.predefined', 'modelarts.bm.gpu.v100.2.predefined'],
                     'poolxxxxx' : ['modelarts.bm.gpu.v100.predefined', 'modelarts.bm.gpu.8v100.predefined']}
        """
        predefined_flavors_dict = dict()
        for pool_info in json.loads(pools_info.content)['pools']:
            pool_id = pool_info['pool_id']
            supported_flavors = []
            for predefined_flavors in pool_info['predefined_flavors']:
                supported_flavors.append(predefined_flavors['flavor_code'])
            predefined_flavors_dict[pool_id] = supported_flavors
        return predefined_flavors_dict

    @classmethod
    def get_train_instance_types(cls, modelarts_session, flavor_info):
        """
        Get Supported Train Instance Types.
        :param modelarts_session: session
        :param flavor_info: flavor info
        :return: For example: ['modelarts.vm.cpu.2u', 'modelarts.vm.gpu.v100NV32']
        """
        flavor_list = []
        flavors = json.loads(flavor_info.content)['flavors']
        for flavor in flavors:
            flavor_list.append(flavor['flavor_code'])
        return flavor_list, json.loads(flavor_info.content)

    @classmethod
    def get_engine_list(cls, modelarts_session, **kwargs):
        """
        Get Supported Engine List.
        :param modelarts_session: session
        :return:
        """
        request_url = modelarts_session.host + '/v1/' + \
                      modelarts_session.project_id + '/job/ai-engines'
        variable_name = locals()['kwargs']
        params = {'job_type'}
        query = ''
        for param in params:
            if param in variable_name and variable_name[param]:
                query = query + param + '=' + str(variable_name[param]) + '&'
        query = query[:-1]
        try:
            response = requests.get(request_url,
                                    headers=modelarts_session.headers,
                                    params=query,
                                    verify=False)
            cls(modelarts_session=modelarts_session).check_roma_response(
                response)
            return response
        except Exception as e:
            raise Exception("Failed to get engine list, {}".format(e))

    @classmethod
    def get_framework_list(cls, modelarts_session, engine_list):
        """
        Get Supported Framework List.
        :param modelarts_session: session
        :param engine_list:
        :return: For example: [{'framework_type': 'TensorFlow', 'framework_version': 'TF-1.4.0-python2.7'},
                               {'framework_type': 'TensorFlow', 'framework_version': 'TF-1.4.0-python3.6'},
                               ...
                               {'framework_type': 'PyTorch', 'framework_version': 'PyTorch-1.0.0-python3.6'}]
        """
        framework_list = []
        engines = json.loads(engine_list.content)['engines']
        for engine in engines:
            framework = {'framework_type': engine['engine_name'],
                         'framework_version': engine['engine_version']}
            framework_list.append(framework)
        return framework_list

    @classmethod
    def get_built_in_algorithms(cls, modelarts_session):
        """
        Get Supported Built_in Algorithms.
        :param modelarts_session: session
        :return:
        """
        request_url = modelarts_session.host + '/v1/' + \
                      modelarts_session.project_id + '/built-in-algorithms'
        try:
            response = requests.get(request_url,
                                    headers=modelarts_session.headers,
                                    verify=False)
            cls(modelarts_session=modelarts_session).check_roma_response(
                response)
            return response.content.decode('utf-8')
        except Exception as e:
            raise Exception("Failed to get built_in algorithms, {}".format(e))

    @classmethod
    @DeprecationWarning
    def get_datasets(cls, modelarts_session, **kwargs):
        """
        :param modelarts_session: session
        :param kwargs:
        :return:
        """
        request_url = modelarts_session.host + '/v1/' + \
                      modelarts_session.project_id + '/datasets'
        variable_name = locals()['kwargs']
        params = {'offset', 'limit', 'sortBy', 'order', 'search_content',
                  'data_url'}
        query = ''
        for param in params:
            if param in variable_name and variable_name[param]:
                query = query + param + '=' + str(variable_name[param]) + '&'
        query = query[:-1]
        try:
            response = requests.get(request_url,
                                    headers=modelarts_session.headers,
                                    params=query, verify=False)
            cls(modelarts_session=modelarts_session).check_roma_response(
                response)
            return response.content
        except Exception as e:
            raise Exception("Failed to get datasets, {}".format(e))

    @DeprecationWarning
    def get_datasets_versions_info(self, dataset_id):
        """
        :param dataset_id: dataset id
        :return:
        """
        request_url = self.modelarts_session.host + '/v1/' + \
                      self.modelarts_session.project_id + \
                      '/datasets/' + dataset_id + '/versions'
        try:
            response = requests.get(request_url,
                                    headers=self.modelarts_session.headers,
                                    verify=False)
            self.check_roma_response(response)
            return response.content
        except Exception as e:
            raise Exception("Failed to get datasets versions info, "
                            "{}".format(e))

    def create_training_job(self, body):
        """
        Create Training Job.
        :param body: request body
        :return:
        """
        request_url = self.modelarts_session.host + '/v1/' + \
                      self.modelarts_session.project_id + '/training-jobs'
        try:
            body = json.loads(json.dumps(str(body).replace("\'", "\"")))
            response = requests.post(request_url,
                                     headers=self.modelarts_session.headers,
                                     data=body, verify=False)
            self.check_roma_response(response)
            return response
        except Exception as e:
            raise Exception("Failed to create training job, {}".format(e))

    def delete_job(self, job_id):
        """
        Delete Specified Training Job.
        :param job_id: job id
        :return:
        """
        request_url = self.modelarts_session.host + '/v1/' + \
                      self.modelarts_session.project_id + \
                      '/training-jobs/' + str(job_id)
        try:
            response = requests.delete(request_url,
                                       headers=self.modelarts_session.headers,
                                       verify=False)
            self.check_roma_response(response)
            return response
        except Exception as e:
            raise Exception("Failed to delete job, {}".format(e))

    def create_job_configs(self, body):
        """
        Create Training Job Configs.
        :param body: request body
        :return:
        """
        request_url = self.modelarts_session.host + '/v1/' + \
                      self.modelarts_session.project_id + \
                      '/training-job-configs'
        try:
            body = json.loads(json.dumps(str(body).replace("\'", "\"")))
            response = requests.post(request_url,
                                     headers=self.modelarts_session.headers,
                                     data=body, verify=False)
            self.check_roma_response(response)
            return response.content
        except Exception as e:
            raise Exception("Failed to create job configs, {}".format(e))

    @classmethod
    def get_job_configs_list(cls, modelarts_session, **kwargs):
        """
        Get Training Job Configs List, Roma does not support sortBy and order.
        :param modelarts_session: session
        :param kwargs: support 'per_page', 'page', 'order', 'search_content'
        :return:
        """
        request_url = modelarts_session.host + '/v1/' + \
                      modelarts_session.project_id + '/training-job-configs'
        variable_name = locals()['kwargs']
        params = {'per_page', 'page', 'search_content'}
        query = ''
        for param in params:
            if param in variable_name and variable_name[param]:
                query = query + param + '=' + str(variable_name[param]) + '&'
        query = query[:-1]
        try:
            response = requests.get(request_url,
                                    headers=modelarts_session.headers,
                                    params=query, verify=False)
            cls(modelarts_session=modelarts_session).check_roma_response(
                response)
            return json.loads(response.content)
        except Exception as e:
            raise Exception("Failed to get job configs list, {}".format(e))

    def get_job_configs_info(self, config_name):
        """
        Get Specified Training Job Configs Info.
        :param config_name: config name
        :return:
        """
        request_url = self.modelarts_session.host + '/v1/' + \
                      self.modelarts_session.project_id + \
                      '/training-job-configs/' + config_name
        try:
            response = requests.get(request_url,
                                    headers=self.modelarts_session.headers,
                                    verify=False)
            self.check_roma_response(response)
            return json.loads(response.content)
        except Exception as e:
            raise Exception("Failed to get job configs info, {}".format(e))

    def update_job_configs(self, config_name, body):
        """
        Update Specified Training Job Configs.
        :param config_name: config name
        :param body: request body
        :return:
        """
        request_url = self.modelarts_session.host + '/v1/' + \
                      self.modelarts_session.project_id + \
                      '/training-job-configs/' + config_name
        try:
            body = json.loads(json.dumps(str(body).replace("\'", "\"")))
            response = requests.put(request_url,
                                    headers=self.modelarts_session.headers,
                                    data=body, verify=False)
            self.check_roma_response(response)
            return response.content
        except Exception as e:
            raise Exception("Failed to update job configs, {}".format(e))

    def delete_job_configs(self, config_name):
        """
        Delete Specified Training Job Configs.
        :param config_name: config name
        :return:
        """
        request_url = self.modelarts_session.host + '/v1/' + \
                      self.modelarts_session.project_id + \
                      '/training-job-configs/' + config_name
        try:
            response = requests.delete(request_url,
                                       headers=self.modelarts_session.headers,
                                       verify=False)
            self.check_roma_response(response)
            return response.content
        except Exception as e:
            raise Exception("Failed to delete job configs, {}".format(e))

    def create_visualization_job(self, body):
        """
        Create Visualization Job.
        :param body: request body
        :return:
        """
        request_url = self.modelarts_session.host + '/v1/' + \
                      self.modelarts_session.project_id + '/visualization-jobs'
        try:
            body = json.loads(json.dumps(str(body).replace("\'", "\"")))
            response = requests.post(request_url,
                                     headers=self.modelarts_session.headers,
                                     data=body, verify=False)
            self.check_roma_response(response)
            return response.content
        except Exception as e:
            raise Exception("Failed to create visualization job, {}".format(e))

    @classmethod
    def get_visualization_job_list(cls, modelarts_session, **kwargs):
        """
        Get Visualization Job List, Roma does not support sortBy and order.
        :param modelarts_session: session
        :param kwargs: support 'status', 'per_page', 'page', 'sortBy', 'order', 'search_content'
        :return:
        """
        request_url = modelarts_session.host + '/v1/' + \
                      modelarts_session.project_id + '/visualization-jobs'
        variable_name = locals()['kwargs']
        params = {'status', 'per_page', 'page', 'search_content'}
        query = ''
        for param in params:
            if param in variable_name and variable_name[param]:
                query = query + param + '=' + str(variable_name[param]) + '&'
        query = query[:-1]
        print(query)
        try:
            response = requests.get(request_url,
                                    headers=modelarts_session.headers,
                                    params=query, verify=False)
            cls(modelarts_session=modelarts_session).check_roma_response(
                response)
            return json.loads(response.content)
        except Exception as e:
            raise Exception("Failed to get visualization job list, "
                            "{}".format(e))

    def get_visualization_job_info(self, job_id):
        """
        Get Specified Visualization Job Info.
        :param job_id: job id
        :return:
        """
        request_url = self.modelarts_session.host + '/v1/' + \
                      self.modelarts_session.project_id + \
                      '/visualization-jobs/' + job_id
        try:
            response = requests.get(request_url,
                                    headers=self.modelarts_session.headers,
                                    verify=False)
            self.check_roma_response(response)
            return json.loads(response.content)
        except Exception as e:
            raise Exception("Failed to get visualization job info, "
                            "{}".format(e))

    def update_visualization_job(self, job_id, body):
        """
        Update Specified Visualization Job.
        :param job_id: job id
        :param body: request body
        :return:
        """
        request_url = self.modelarts_session.host + '/v1/' + \
                      self.modelarts_session.project_id + \
                      '/visualization-jobs/' + job_id
        try:
            body = json.loads(json.dumps(str(body).replace("\'", "\"")))
            response = requests.put(request_url,
                                    headers=self.modelarts_session.headers,
                                    data=body, verify=False)
            self.check_roma_response(response)
            return response.content
        except Exception as e:
            raise Exception("Failed to update visualization job, {}".format(e))

    def delete_visualization_job(self, job_id):
        """
        Delete Specified Visualization Job.
        :param job_id: job id
        :return:
        """
        request_url = self.modelarts_session.host + '/v1/' + \
                      self.modelarts_session.project_id + \
                      '/visualization-jobs/' + job_id
        try:
            response = requests.delete(request_url,
                                       headers=self.modelarts_session.headers,
                                       verify=False)
            self.check_roma_response(response)
            return response.content
        except Exception as e:
            raise Exception("Failed to delete visualization job, {}".format(e))

    def restart_visualization_job(self, job_id):
        """
        Restart Specified Visualization Job.
        :param job_id: job id
        :return:
        """
        request_url = self.modelarts_session.host + '/v1/' + \
                      self.modelarts_session.project_id + \
                      '/visualization-jobs/' + job_id + '/restart'
        try:
            response = requests.post(request_url,
                                     headers=self.modelarts_session.headers,
                                     verify=False)
            self.check_roma_response(response)
            return response.content
        except Exception as e:
            raise Exception("Failed to restart visualization job {}".format(e))

    def stop_visualization_job(self, job_id):
        """
        Stop Specified Visualization Job.
        :param job_id: job id
        :return:
        """
        request_url = self.modelarts_session.host + '/v1/' + \
                      self.modelarts_session.project_id + \
                      '/visualization-jobs/' + job_id + '/stop'
        try:
            response = requests.post(request_url,
                                     headers=self.modelarts_session.headers,
                                     verify=False)
            self.check_roma_response(response)
            return response.content
        except Exception as e:
            raise Exception(f"Failed to stop visualization job, {str(e)}")


class VisualizationJob(object):

    def __init__(self, modelarts_session, visualization_id=None,
                 create_time=None, job_name=None, status=None):
        """
        Initialize a ModelArts Visualization Job instance.
        """
        self.modelarts_session = modelarts_session
        self.visualization_id = visualization_id
        self.create_time = create_time
        self.job_name = job_name
        self.status = status
        self._training_job = _TrainingJobApiAKSKImpl(modelarts_session) \
            if modelarts_session.auth == constant.AKSK_AUTH else _TrainingJobApiRomaImpl(modelarts_session)

    def _check_visualization_id(self, visualization_id):
        """
        :param visualization_id: visualization id
        :return:
        """
        if not visualization_id and not self.visualization_id:
            raise ValueError(
                'Parameter job_id is needed for Visualization job')
        return visualization_id if visualization_id else self.visualization_id

    def _transform_roma_response(self, response):
        return json.loads(
            response.content) if self.modelarts_session.auth == constant.ROMA_AUTH else response

    def create_visualization_job(self, train_url, job_name=None, job_desc=None, job_type="tensorboard",
                                 wait=False):
        """
        Create Visualization Job.
        :param job_name: job name
        :param train_url:
        :param job_desc: job description
        :param job_type: job type, default value is tensorboard
        :param wait: whether wait the job completed or not
        :return:
        """
        if not job_name:
            beijing_date = (datetime.now() + timedelta(hours=8)).strftime(
                constant.ISO_TIME_FORMAT)
            job_name = 'tensor-' + beijing_date
        body = {"job_name": job_name,
                "train_url": train_url,
                "job_type": job_type}
        if job_desc:
            body["job_desc"] = job_desc
        response = self._training_job.create_visualization_job(body)
        response = self._transform_roma_response(response)
        if not response['is_success']:
            raise Exception(
                'Failed to create the visualization job for %s' % response[
                    'error_msg'])
        if wait:
            self.print_visualization_job_middle_state(response)
        self.visualization_id = response['job_id']
        self.create_time = response['create_time']
        self.job_name = response['job_name']
        self.status = response['status']
        self.visualizationJob = VisualizationJob(self.modelarts_session,
                                                 self.visualization_id,
                                                 self.create_time,
                                                 self.job_name, self.status)
        return self.visualizationJob

    @classmethod
    def get_visualization_job_list(cls, modelarts_session, **kwargs):
        """
        Get Visualization Job List.
        :param modelarts_session: session
        :param kwargs: support 'status', 'per_page', 'page', 'sortBy', 'order', 'search_content'
        :return:
        """
        return cls(modelarts_session=modelarts_session). \
            _training_job.get_visualization_job_list(modelarts_session, **kwargs)

    @classmethod
    def get_visualization_job_object_list(cls, modelarts_session, is_show=True,
                                          **kwargs):
        """
        Get Visualization Job List.
        :param modelarts_session: session
        :param kwargs: support 'status', 'per_page', 'page', 'sortBy', 'order', 'search_content'
        :return:
        """
        response = cls(modelarts_session=modelarts_session)._training_job. \
            get_visualization_job_list(modelarts_session, **kwargs)
        if not response['is_success']:
            raise Exception(
                'Failed to get visualization list for %s' % response[
                    'error_msg'])
        if is_show:
            print(response)
        visualizationJob_list = []
        for job in response['jobs']:
            info_resp = cls(modelarts_session=modelarts_session). \
                get_visualization_job_info(job['job_id'])
            if not info_resp['is_success']:
                raise Exception(
                    'Failed to get visualization job info %s for %s' % (
                        job['job_id'], info_resp['error_msg']))
            job_id = info_resp['job_id'] if info_resp['job_id'] else None
            create_time = info_resp['create_time'] if info_resp[
                'create_time'] else None
            job_name = info_resp['job_name'] if info_resp['job_name'] else None
            status = info_resp['status'] if info_resp['status'] else None
            visualizationJob_list.append(
                VisualizationJob(modelarts_session=modelarts_session,
                                 visualization_id=job_id,
                                 create_time=create_time,
                                 job_name=job_name, status=status))
        return visualizationJob_list

    def get_visualization_job_info(self, job_id=None):
        """
        Get Specified Visualization Job Info.
        :param job_id: job id
        :return:
        """
        job_id = str(self._check_visualization_id(job_id))
        return self._training_job.get_visualization_job_info(job_id)

    def update_visualization_job(self, job_desc, job_id=None):
        """
        Update Specified Visualization Job.
        :param job_desc: job description
        :param job_id: job id
        :param wait: whether wait the job completed or not
        :return:
        """
        job_id = str(self._check_visualization_id(job_id))
        body = {'job_desc': job_desc}
        response = self._training_job.update_visualization_job(job_id, body)
        response = self._transform_roma_response(response)
        if response['is_success']:
            logging.info('Successfully update the visualization job %s', job_id)
        else:
            raise Exception(
                'Failed to update the visualization job %s for %s' % (
                    job_id, response['error_msg']))
        return response

    @staticmethod
    def visualization_job_and_wait(count_times, response, duration):
        """
        Print visualization job middle state response and wait some time.
        :param count_times: job middle state wait count
        :param response: job response
        :param duration: wait time
        :return: count times
        """
        if count_times == 0:
            print(response)
        count_times = count_times + 1
        time.sleep(duration)
        return count_times

    @staticmethod
    def visualization_job_running(response, duration, job_name):
        print(response)
        sec = duration / 1000
        minu, seconds = divmod(sec, 60)
        hours, minutes = divmod(minu, 60)
        duration_format = "%02d:%02d:%02d" % (hours, minutes, seconds)
        logging.info("Visualization Job [ %s ] status is running, "
                     "duration is %s", job_name, duration_format)

    def print_visualization_job_middle_state(self, job_train_resp):
        """
        Print Specified Visualization Job Middle State.
        :param job_train_resp: job train response
        :return:
        """
        job_name = job_train_resp['job_name']
        count_unknowm = 0
        count_init = 0
        count_waiting = 0
        count_deploying = 0
        while True:
            response, duration = self.get_visualization_job_state(
                job_name=job_name)
            if response == 'JOBSTAT_UNKNOWN':
                if count_unknowm > 0:
                    logging.info("Visualization Job [ %s ] status is %s, "
                                 "please check on the "
                                 "platform", job_name, response)
                    break
                count_unknowm = self.visualization_job_and_wait(count_unknowm, response, 3)
            elif response == 'JOBSTAT_INIT':
                count_init = self.visualization_job_and_wait(count_init, response, 3)
            elif response == 'JOBSTAT_WAITING':
                count_waiting = self.visualization_job_and_wait(count_waiting, response, 5)
            elif response == 'JOBSTAT_DEPLOYING':
                count_deploying = self.visualization_job_and_wait(count_deploying, response, 5)
            elif response == 'JOBSTAT_RUNNING':
                self.visualization_job_running(response, duration, job_name)
                break
            else:
                logging.info(
                    "Visualization Job [ %s ] status is %s, please check "
                    "on the platform", job_name, response)
                break

            count_total = count_init + count_unknowm + count_waiting + count_deploying
            if count_total > int(constant.MAXIMUM_RETRY_TIMES):
                logging.info("Reach the maximum start times, the current "
                             "status is %s", response)
                break

    def get_visualization_job_state(self, job_name):
        """
        Delete Specified Visualization Job State.
        :param job_name: job name
        :return:
        """
        status = 'UNKNOWN'
        duration = 'UNKNOWN'
        res = self._training_job.get_visualization_job_list(
            self.modelarts_session)
        for job in res['jobs']:
            if job_name == job['job_name']:
                status_id = job['status']
                status = JOB_STATE[int(status_id)]
                duration = job['duration']
        return status, duration

    def delete_visualization_job(self, job_id=None):
        """
        Delete Specified Visualization Job.
        :param job_id: job id
        :return:
        """
        job_id = str(self._check_visualization_id(job_id))
        response = self._training_job.delete_visualization_job(job_id)
        response = self._transform_roma_response(response)
        if response['is_success']:
            logging.info('Successfully delete the visualization job %s', job_id)
        else:
            raise Exception(
                'Failed to delete the visualization job %s for %s' % (
                    job_id, response['error_msg']))
        return response

    def restart_visualization_job(self, job_id=None):
        """
        Restart Specified Visualization Job.
        :param job_id: job id
        :return:
        """
        job_id = str(self._check_visualization_id(job_id))
        response = self._training_job.restart_visualization_job(job_id)
        response = self._transform_roma_response(response)
        if response['is_success']:
            logging.info('Successfully restart the visualization job %s', job_id)
        else:
            raise Exception(
                'Failed to restart the visualization job %s for %s' % (
                    job_id, response['error_msg']))
        return response

    def stop_visualization_job(self, job_id=None):
        """
        Stop Specified Visualization Job.
        :param job_id: job id
        :return:
        """
        job_id = str(self._check_visualization_id(job_id))
        response = self._training_job.stop_visualization_job(job_id)
        response = self._transform_roma_response(response)
        if response['is_success']:
            logging.info('Successfully stop the visualization job %s', job_id)
        else:
            raise Exception(
                'Failed to stop the visualization job %s for %s' % (
                    job_id, response['error_msg']))
        return response
