"""
Predictor for ModelArts online service.
"""
import os
import json
from urllib import parse
import stat
import requests
import copy
from abc import ABCMeta, abstractmethod
from json import JSONEncoder
from io import BytesIO

from PIL import Image
from six import with_metaclass

from .config.auth import auth_by_apig, auth_by_roma_api
from .util.secret_util import auth_expired_handler
from . import constant

TIMEOUT = int(constant.REQUEST_TIME_OUT)


class Predictor(object):
    """
    A ModelArts Predictor that can be predicted,
    got service information and list,
    changed service state and configuration.
    """

    def __init__(self, session, service_id, is_local=False, port=None, model_local_path=None):
        """
        Initialize a Predictor, determine the predictor authorize type.
        param session: Building interactions with Cloud service.
        param service_id: The deployed model service id
        param is local: local service flag
        """
        self.session = session
        self.service_id = service_id
        self.is_local = is_local
        if self.is_local:
            self.predictor_instance = LocalPredictor(port, model_local_path)
        else:
            self.predictor_instance = PredictorApiAKSKImpl(self.session, service_id) \
                if self.session.auth == constant.AKSK_AUTH else PredictorApiROMAImpl(self.session, service_id)
            service_info = self.get_service_info(service_id=self.service_id)
            self.__set_service_attribute(service_params=service_info)

    def get_service_info(self, service_id=None):
        """ Get the deployed model service information
        :param service_id: The deployed model service id
        :return: The deployed service information,
        including model service access address.
        """
        return self.predictor_instance.get_service_info(service_id)

    def __set_service_attribute(self, service_params):
        """ set model attribute, model parameters
        :param service_params: service params
        """

        def get_value(service_params, params):
            return service_params[params] if params in service_params else None

        self.status = get_value(service_params, 'status')
        self.is_shared = get_value(service_params, 'is_shared')
        self.failed_times = get_value(service_params, 'failed_times')
        self.description = get_value(service_params, 'description')
        self.service_name = get_value(service_params, 'service_name')
        self.project = get_value(service_params, 'project')
        self.invocation_times = get_value(service_params, 'invocation_times')
        self.progress = get_value(service_params, 'progress')
        self.publish_at = get_value(service_params, 'publish_at')
        self.owner = get_value(service_params, 'owner')
        self.service_id = get_value(service_params, 'service_id')
        self.tenant = get_value(service_params, 'tenant')
        self.infer_type = get_value(service_params, 'infer_type')

    def predict(self, data, data_type, path='/'):
        """ service predict
        :param data:  Input data for which you want the model to provide inference.
                      if not isinstance(data, str),
        :param data_type: support {files, images}
        :param path: inference path
        :return: predict result
        """
        if data_type not in constant.DATA_TYPE_SET:
            raise Exception("The data type %s is not in %s" % (
                data_type, constant.DATA_TYPE_SET))

        return self.predictor_instance.predict(data, data_type, path)

    @classmethod
    def get_service_list(cls, session, **kwargs):
        """ Get the current account services, and return service information(dict type)
        :param session: session with cloud service
        :param kwargs: index params
        :return:  service list
        """
        service_id = None
        predictor_instance = PredictorApiAKSKImpl(session, service_id) if session.auth == constant.AKSK_AUTH else \
            PredictorApiROMAImpl(session, service_id)
        return predictor_instance.get_service_list(**kwargs)

    @classmethod
    def get_service_object_list(cls, session, is_show=True, **kwargs):
        """ Get the current account services, and return service object(Predictor)
        :param session: session with cloud service
        :param is_show: show in console
        :param kwargs: index params
        :return: service list
        """
        index_surplus_set = set(kwargs.keys()) - constant.SERVICE_INDEX_PARAMS
        if len(index_surplus_set) != 0:
            raise ValueError('The input params: {} for service index is surplus'
                             .format(index_surplus_set))

        service_object_list = []
        service_list_info = Predictor.get_service_list(session, **kwargs)

        for one_predictor in service_list_info['services']:
            service_object_list.append(
                Predictor(session, one_predictor['service_id']))
        if is_show:
            print(json.dumps(service_list_info, indent=1))
        return service_object_list

    @classmethod
    def get_service_by_id(cls, session, service_id):
        """ return model object of model_id
        :param session: session with cloud service
        :param service_id: service id
        """
        return Predictor(session, service_id)

    @classmethod
    def delete_service_by_id(cls, session, service_id):
        """ delete service object by service_id
        :param session: session with cloud service
        :param service_id: service id
        """
        service_instance = Predictor(session, service_id)
        service_instance.delete_service(service_id=service_id)

    def change_edge_service_state(self, node_id, action_body, service_id=None):
        """
        :param node_id: node id
        :param action_body: Operate type, {stop, run}
        :param service_id: service id
        :return: Service stop or start tasks result.
        """
        return self.predictor_instance. \
            change_edge_service_state(node_id, action_body, service_id=service_id)

    def update_service_config(self, service_id=None, **config_body):
        """ update a service configuration
        :param service_id: service id
        :param config_body: service configuration parameters
        :return: Service update configuration tasks result.
        """
        return self.predictor_instance.update_service_config(
            service_id=service_id, **config_body)

    def get_service_monitor(self, service_id=None, node_id=None):
        """ service monitor information
            Args: service_id: service id
            Args: node_id: node id
            return: monitor information
        """
        return self.predictor_instance.get_service_monitor(service_id=service_id, node_id=node_id)

    def get_service_logs(self):
        """
        :return:  monitor information
        """
        return self.predictor_instance.get_service_logs(
            service_id=self.service_id)

    def delete_service(self, service_id=None):
        """
        :param service_id: service id
        """
        if service_id is None:
            service_id = self.service_id
        self.predictor_instance.delete_service(service_id=service_id)
        if service_id is not None:
            print("Successfully delete the service %s ." % service_id)


class PredictorApiBase(with_metaclass(ABCMeta, object)):
    """ Make prediction requests to a ModelArts model service endpoint
    """

    def __init__(self):
        """ Initialize Predictor
            service_id: The deployed model service id
        """

    @abstractmethod
    def get_service_info(self):
        """ Get the deployed model service information
        return: The deployed service information,including model service access address.
        """
        pass

    @abstractmethod
    def predict(self, data, data_type, path):
        """
        :param data:  Input data for which you want the model to provide inference.
        :param data_type: {files, images}
        :param path: inference path
        return: predict result
        """
        pass

    @abstractmethod
    def get_service_list(self):
        """
        return User service list
        """
        pass

    @abstractmethod
    def change_edge_service_state(self, node_id, action_body, service_id=None):
        """ change a service state.
        :param node_id: node id
        :param action_body: Operate type, {stop, run}
        :param service_id: service id
        :return: Service stop or start tasks result.
        """
        pass

    @abstractmethod
    def update_service_config(self, service_id=None, **config_body):
        """ update a service configuration
        :param service_id: service id
        :param config_body: service configuration parameters
        :return Service update configuration tasks result.
        """
        pass

    @abstractmethod
    def get_service_monitor(self, service_id=None):
        """ service monitor information
        :param service_id: service id
        :return: monitor information
        """
        pass

    @abstractmethod
    def get_service_logs(self, service_id=None):
        """ service logs
        :param service_id: service id
        :return: monitor information
        """
        pass

    @abstractmethod
    def delete_service(self, service_id):
        """
        :param service_id: service id
        :return: delete service endpoint
        """
        pass

    @staticmethod
    def convert_config_format(config_body):
        """  convert config parameter format to dict
        :param config_body: configuration body
        """
        config_value = []
        for service_config in config_body:
            one_config = dict()
            one_config['model_id'] = service_config.model_id
            one_config['specification'] = service_config.specification
            one_config['instance_count'] = service_config.instance_count
            if service_config.envs is not None:
                one_config['envs'] = service_config.envs
            config_value.append(one_config)

        return config_value


class LocalPredictor(PredictorApiBase):
    """
    Provide predict service locally.
    """

    def __init__(self, port, model_local_path=None):
        PredictorApiBase.__init__(self)
        if not str(port).isdigit():
            raise ValueError("Parameter port must be a number.")
        self.port = port
        self.model_local_path = model_local_path

    def predict(self, data, data_type, path='/'):
        """
        Predict locally.
        :param data: input data
        :param data_type: data type
        :param path: inference path
        """
        local_service_host = "http://{host}:{port}/".format(
            host=constant.MODEL_LOCAL_HOST,
            port=self.port)
        url = parse.urljoin(local_service_host, path.lstrip('/'))

        if data_type == constant.JSON_TYPE:
            headers = {'Content-Type': 'application/json'}
            if isinstance(data, str):  # json file path
                if not os.path.exists(os.path.realpath(data)):
                    raise FileNotFoundError(f"Path {data} not found.")
                with os.fdopen(os.open(data, os.O_RDONLY, stat.S_IWUSR | stat.S_IRUSR), 'r') as f:
                    content = f.read()
                body = json.loads(content, encoding='utf-8')
            else:  # dict
                body = data
            predict_result = requests.post(url=url,
                                           headers=headers,
                                           data=json.dumps(body),
                                           proxies={"http": None,
                                                    "https": None})
        # support input Image matrix
        elif isinstance(data, Image.Image):
            f = BytesIO()
            data.save(f, format='PNG')
            data = f.getvalue()
            data = {'images': ('temp.jpg', data)}
            predict_result = requests.post(url,
                                           files=data,
                                           proxies={"http": None,
                                                    "https": None})
        # support input path
        else:
            if not os.path.exists(os.path.realpath(data)):
                raise FileNotFoundError(f"Path {data} not found.")
            data_byte = os.fdopen(os.open(data, os.O_RDONLY, stat.S_IWUSR | stat.S_IRUSR), 'rb')
            data_post = {data_type: (os.path.realpath(data), data_byte)}
            predict_result = requests.post(url,
                                           files=data_post,
                                           proxies={"http": None,
                                                    "https": None})
        status_code = predict_result.status_code
        if status_code < constant.HTTP_STATUS_CODE_200 or status_code > constant.HTTP_STATUS_CODE_299:
            print("Warning: an unexpected error happens, please check log in {}".
                  format(os.path.join(self.model_local_path, constant.LOCAL_INFER_LOG_FILE_NAME)))

        return json.loads(predict_result.text)

    def get_service_info(self):
        pass

    def get_service_list(self):
        pass

    def change_edge_service_state(self, node_id, action_body, service_id=None):
        pass

    def update_service_config(self, service_id=None, **config_body):
        pass

    def get_service_monitor(self, service_id=None):
        pass

    def get_service_logs(self, service_id=None):
        pass

    def delete_service(self, service_id):
        """
        Delete local service.
        :param service_id: service id
        """
        current_path = os.path.split(os.path.realpath(__file__))[0]
        stop_port = r"bash {basepath}/local/stop_port.sh  {port}".format(
            basepath=current_path,
            port=self.port)
        os.system(stop_port)
        local_service_ip = constant.MODEL_LOCAL_HOST + ":" + str(self.port)
        print("Successfully stop the local service at {}.".format(local_service_ip))


class PredictorApiAKSKImpl(PredictorApiBase):
    """ Make prediction requests to a ModelArts model service endpoint
    """

    def __init__(self, session, service_id):
        """ Initialize Predictor
        :param session: Building interactions with Cloud Service, including project id.
        :param service_id: The deployed model service id
        """
        PredictorApiBase.__init__(self)
        self.session = session
        self.service_id = service_id
        self.access_address = None
        self.base_request_url = '/v1/' + self.session.project_id + '/services/'

    @auth_expired_handler
    def get_service_info(self, service_id=None):
        """
        :param service_id: service id
        :return: service information
        """
        if service_id is None:
            service_id = self.service_id
        request_url = self.base_request_url + service_id
        return auth_by_apig(self.session, constant.HTTPS_GET, request_url, '')

    @auth_expired_handler
    def predict(self, data, data_type, path='/'):
        """
        :param data: Input data for which you want the model to provide inference.
        :param data_type: support {files, images}
        :param path: inference path
        :return: predict result
        """
        if self.access_address is None:
            self.access_address = self.get_service_info()["access_address"]
        access_host = self.access_address.split("//")[1].split('/', 1)[0]
        access_request = \
            parse.urljoin('/' + self.access_address.split("//")[1].split('/', 1)[1] + '/', path.lstrip('/'))

        if 'JSON' == data_type.upper() and type(data) != str:
            headers = {'Content-Type': "application/json"}
            predict_body = json.dumps(data)

        else:
            predict_file = {data_type: open(data, 'rb')}
            predict_body, content_type = requests.models.RequestEncodingMixin._encode_files(
                predict_file, {})
            headers = {'content-type': content_type}
            predict_file[data_type].close()

        temp_session = copy.copy(self.session)
        temp_session.host = access_host
        predict_result = auth_by_apig(temp_session,
                                      constant.HTTPS_POST,
                                      access_request, '', body=predict_body,
                                      headers=headers)
        return predict_result

    @auth_expired_handler
    def get_service_list(self, **kwargs):
        """
        :param kwargs: index params
        :return: User service list
        """
        request_url = '/v1/' + self.session.project_id + '/services'
        return auth_by_apig(self.session, constant.HTTPS_GET, request_url, query=kwargs)

    @auth_expired_handler
    def change_edge_service_state(self, node_id, action_body, service_id=None):
        """
        :param node_id: node id
        :param action_body: Operate type, {stop, run}
        :param service_id: service id
        :return: Service stop or start tasks result.
        """
        if service_id is None:
            service_id = self.service_id

        request_url = self.base_request_url + service_id + '/nodes/' + node_id + '/status'
        action_body = JSONEncoder().encode(action_body)
        return auth_by_apig(self.session, constant.HTTPS_PUT, request_url, '', action_body)

    @auth_expired_handler
    def update_service_config(self, service_id=None, **config_body):
        """update a service configuration
        :param service_id: service id
        :param config_body: service configuration parameters
        :return: Service update configuration tasks result.
        """
        service_config_body = config_body
        if 'configs' in config_body:
            service_config_body[
                'config'] = PredictorApiBase.convert_config_format(
                config_body['configs'])

            service_config_body.pop('configs')

        if service_id is None:
            service_id = self.service_id

        request_url = self.base_request_url + service_id
        service_config_body = JSONEncoder().encode(service_config_body)
        return auth_by_apig(self.session, constant.HTTPS_PUT, request_url, '', service_config_body)

    @auth_expired_handler
    def get_service_monitor(self, service_id=None, node_id=None):
        """  service monitor information
        :param service_id: service id
        :param node_id: node id
        :return: monitor information
        """
        if service_id is None:
            service_id = self.service_id

        query = {}
        if node_id:
            query['node_id'] = node_id
        request_url = self.base_request_url + service_id + '/monitor'
        return auth_by_apig(self.session, constant.HTTPS_GET, request_url, query)

    @auth_expired_handler
    def get_service_logs(self, service_id=None):
        """
        :param service_id:  service id
        :return: monitor information
        """
        if service_id is None:
            service_id = self.service_id

        request_url = self.base_request_url + service_id + '/logs'
        return auth_by_apig(self.session, constant.HTTPS_GET, request_url, '')

    @auth_expired_handler
    def delete_service(self, service_id):
        """ Delete a service
        :param service_id: service id
        """
        request_url = '/v1/' + self.session.project_id + '/services/' + service_id
        auth_by_apig(self.session, constant.HTTPS_DELETE, request_url, '')


class PredictorApiROMAImpl(PredictorApiBase):
    """ Make prediction requests to a ROMA ModelArts model service endpoint
    """

    def __init__(self, session, service_id):
        """ Initialize Predictor
        :param session: Building interactions with Cloud Service, including project id.
        :param service_id: The deployed model service id
        """
        PredictorApiBase.__init__(self)
        self.session = session
        self.service_id = service_id
        self.base_request_url = self.session.host + '/v1/' + \
                                self.session.project_id + '/services/'

    def get_service_info(self, service_id=None):
        """
        :param service_id: service id
        :return: service information
        """
        if service_id is None:
            service_id = self.service_id
        request_url = self.base_request_url + service_id
        return auth_by_roma_api(session=self.session, request_url=request_url,
                                request_type=constant.HTTPS_GET,
                                intf_action="get_service_info")

    def predict(self, data, data_type, path='/'):
        """
        :param data: Input data for which you want the model to provide inference.
        :param data_type: support {files, images}
        :param path: inference path
        :return: predict result
        """
        predict_url = parse.urljoin(self.get_service_info()["access_address"] + '/', path.lstrip('/'))
        predict_file = {data_type: open(data, 'rb')}
        predict_body, Content_Type = \
            requests.models.RequestEncodingMixin._encode_files(predict_file, {})
        self.session.headers['content-type'] = Content_Type
        self.session.headers['csb-token'] = self.session.headers['App-Token']
        model_create_resp = auth_by_roma_api(session=self.session,
                                             request_url=predict_url,
                                             request_type=constant.HTTPS_POST,
                                             intf_action="service predict",
                                             data=predict_body)
        predict_file[data_type].close()
        if not model_create_resp['success']:
            raise Exception("service predict failed, %s." % model_create_resp)
        return model_create_resp

    def get_service_list(self, **kwargs):
        """
        :param kwargs: index params
        :return: User service list
        """
        return auth_by_roma_api(session=self.session,
                                request_url=self.base_request_url,
                                request_type=constant.HTTPS_GET,
                                intf_action="get_service_list", params=None)

    def change_edge_service_state(self, node_id, action_body, service_id=None):
        """
        :param node_id: node id
        :param action_body: Operate type, {stop, run}
        :param service_id: service id
        :return: Service stop or start tasks result.
        """
        raise Exception(" The ROMA ModelArts does not support edge service.")

    def update_service_config(self, service_id=None, **config_body):
        """update a service configuration
        :param service_id: service id
        :param config_body: service configuration parameters
        :return: Service update configuration tasks result.
        """
        service_config_body = config_body
        if 'configs' in config_body:
            service_config_body[
                'config'] = PredictorApiBase.convert_config_format(
                config_body['configs'])

            service_config_body.pop('configs')

        if service_id is None:
            service_id = self.service_id

        request_url = self.base_request_url + service_id
        body = json.loads(
            json.dumps(str(service_config_body).replace("\'", "\"")))

        return auth_by_roma_api(session=self.session, request_url=request_url,
                                request_type=constant.HTTPS_PUT,
                                intf_action="update_service_config", data=body)

    def get_service_monitor(self, service_id=None, node_id=None):
        """  service monitor information
        :param service_id: service id
        :param node_id: node id
        :return: monitor information
        """
        if service_id is None:
            service_id = self.service_id

        query = {}
        if node_id:
            query['node_id'] = node_id
        request_url = self.base_request_url + service_id + '/monitor'
        return auth_by_roma_api(session=self.session, request_url=request_url,
                                request_type=constant.HTTPS_GET,
                                intf_action="get_service_monitor")

    def get_service_logs(self, service_id=None):
        """
        :param service_id:  service id
        :return: monitor information
        """
        if service_id is None:
            service_id = self.service_id

        request_url = self.base_request_url + service_id + '/logs'
        return auth_by_roma_api(session=self.session, request_url=request_url,
                                request_type=constant.HTTPS_GET,
                                intf_action="get_service_logs")

    def delete_service(self, service_id):
        """ Delete a service
        :param service_id: service id
        """
        request_url = self.base_request_url + service_id
        auth_by_roma_api(session=self.session, request_url=request_url,
                         request_type=constant.HTTPS_DELETE,
                         intf_action="delete_service")
