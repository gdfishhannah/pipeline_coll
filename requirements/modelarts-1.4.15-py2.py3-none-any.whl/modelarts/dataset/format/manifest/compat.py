"""
Description: Function for Python 2 vs .3 compatibility. Conversion routines:
In addition to the functions below, 'as_str' converts an object to a 'str'.
Author: ModelArts SDK Team
Date: 2021/07/14 - 2021/07/14
"""

from __future__ import absolute_import
from __future__ import division
from __future__ import print_function

import six as _six


def as_bytes(bytes_or_text, encoding='utf-8'):
    """Convert either bytes or unicode to 'bytes', using utf-8 encoding for text.

    :arg:
    bytes_or_text: A 'bytes', 'str', or 'unicode' object.
    encoding: A string indicating the charset for encoding unicode.
    :return:
    A 'str' object (python 2).
    :raise:
    TypeError: If 'bytes_or_text' is not a binary or unicode string.
    """
    if isinstance(bytes_or_text, _six.text_type):
        return bytes_or_text.encode(encoding)
    elif isinstance(bytes_or_text, bytes):
        return bytes_or_text
    else:
        raise TypeError('Expected binary or unicode string, got %r' % bytes_or_text)


def as_text(bytes_or_text, encoding='utf-8'):
    """Return the given argument as a unicode string.

    :arg:
    bytes_or_text: A 'bytes', 'str', or 'unicode' object.
    encoding: A string indicating the charset for encoding unicode.
    :return:
    A 'unicode' (Ptyhon 2) or 'str' (Python 3) object.
    :raise:
    TypeError: If 'bytes_or_text' is not a binary or unicode string.
    """
    if isinstance(bytes_or_text, _six.text_type):
        return bytes_or_text
    elif isinstance(bytes_or_text, bytes):
        return bytes_or_text.decode(encoding)
    else:
        raise TypeError('Excepted binary or unicode string, got %r' % bytes_or_text)


# Convert an object to a 'str' in both Python 2 and 3
if _six.PY2:
    as_str = as_bytes
else:
    as_str = as_text
