"""
Description: Manage the devcontainers
Author: ModelArts SDK Team
"""
import os
from enum import Enum, auto

import yaml

from .util.docker_util import DockerComposeCli, DockerCli


class DevContainerStatus(Enum):
    PULLING = "pulling"
    PULLED = "pulled"
    BUILDING = "building"
    STARTING = "starting"
    RUNNING = "running"
    STOPPING = "stopping"
    STOPPED = "stopped"
    PAUSED = "paused"
    DELETING = "deleting"
    DELETED = "deleted"
    UNKNOWN = "unknown"


class DevContainerAction(Enum):
    CREATE = auto()
    DELETE = auto()
    START = auto()
    STOP = auto()


class DevContainer(object):
    """
    This class is used to manage the devcontainers which are notebooks in vm.
    """
    COMPOSE_FIELD_SERVICE = "services"
    MODELARTS_SERVICE_NAME = "modelarts"
    COMPOSE_FIELD_SERVICE_IMAGE = "image"
    COMPOSE_FIELD_SERVICE_BUILD = "build"
    CONTAINER_STATUS_TO_DEV_STATUS = {
        "running": DevContainerStatus.RUNNING.value,
        "exited": DevContainerStatus.STOPPED.value,
        "paused": DevContainerStatus.PAUSED.value,
        "created": DevContainerStatus.STARTING.value,
    }

    def __init__(self, compose_file: str, project_directory="", project_name=""):
        """
        Init a dev container status.
        :param compose_file: docker compose file
        :param project_directory: an alternate working directory(default: the path of the Compose file)
        :param project_name: specify an alternate project name(default: directory name)
        """
        self._check_params(compose_file, project_directory, project_name)
        self.__compose_file = os.path.abspath(compose_file)
        self.__project_directory = os.path.abspath(project_directory) if project_directory else ""
        self.__project_name = project_name
        self.__status = None
        self.__process = None
        self.__compose_options = self._get_compose_options()
        self.__actual_project_name = self._get_project_name()
        self.__content = self._read_compose_file()
        self.__modelarts_image = self._get_service_image()
        self.__action = None

    @staticmethod
    def _check_params(compose_file: str, project_directory="", project_name=""):
        """
        Get the options of docker-compose.
        :param compose_file: docker compose file
        :param project_directory: an alternate working directory(default: the path of the Compose file)
        :param project_name: specify an alternate project name(default: directory name)
        :return: project name
        """
        if project_directory:
            if not isinstance(project_directory, str):
                raise TypeError("The parameter project_directory should be type of string.")
            project_directory_path = os.path.abspath(project_directory)
            if not os.path.exists(project_directory_path):
                raise FileNotFoundError(f"Project directory {project_directory_path} does not exist.")
        if project_name:
            if not isinstance(project_name, str):
                raise TypeError("The parameter project_name should be type of string.")
        if not isinstance(compose_file, str):
            raise TypeError("The parameter compose_file should be type of string.")
        compose_file_path = os.path.abspath(compose_file)
        if not os.path.exists(compose_file_path):
            raise FileNotFoundError(f"Compose file {compose_file_path} does not exist.")

    def _read_compose_file(self):
        with open(self.__compose_file, 'r') as stream:
            content = yaml.safe_load(stream)
        if self.COMPOSE_FIELD_SERVICE not in content:
            raise ValueError(f"The top-level element {self.COMPOSE_FIELD_SERVICE} is not in compose file.")
        if self.MODELARTS_SERVICE_NAME not in content[self.COMPOSE_FIELD_SERVICE]:
            raise ValueError(f"The service {self.MODELARTS_SERVICE_NAME} is not in compose file.")
        return content

    def _get_compose_options(self) -> list:
        """
        Get the options of docker-compose.
        :return: compose options
        """
        compose_options = []
        if self.__project_directory:
            compose_options.extend(["--project-directory", self.__project_directory])
        if self.__project_name:
            compose_options.extend(["--project-name", self.__project_name])
        compose_options.extend(["--file", self.__compose_file])
        return compose_options

    def _get_project_name(self) -> str:
        """
        Get the project name of docker compose project according to these parameters.
        :return: project name
        """
        if self.__project_name:
            return self.__project_name
        if self.__project_directory:
            return os.path.basename(self.__project_directory)
        return os.path.basename(os.path.dirname(self.__compose_file))

    def prepare(self, service=MODELARTS_SERVICE_NAME) -> str:
        """
        Because docker-compose in arm DevServer cannot pull private images from swr, we pull images by docker pull.
        :return: project name
        """
        modelarts_service = self.__content[self.COMPOSE_FIELD_SERVICE][service]
        if self.COMPOSE_FIELD_SERVICE_IMAGE not in modelarts_service:
            return self.__actual_project_name
        self.__process = DockerCli.pull(self.__modelarts_image)
        self.__status = DevContainerStatus.PULLING.value
        self.__action = DevContainerAction.CREATE
        return self.__actual_project_name

    def create(self) -> str:
        """
        Create and start a docker compose project.
        :return: project name
        """
        # The devcontainer should not be started if it is being created or deleted
        if self.__process and self.__process.poll() is None:
            return self.__actual_project_name
        options = ["-d", "--quiet-pull"]
        self.__process = DockerComposeCli.up(compose_options=self.__compose_options, options=options)
        self.__status = DevContainerStatus.STARTING.value
        self.__action = DevContainerAction.CREATE
        return self.__actual_project_name

    def delete(self):
        """
        Delete the project.
        :return: project name
        """
        status = self.get_status()
        # If the docker-compose project has not been started, the command 'docker-compose down' will not take effect.
        if status == DevContainerStatus.STARTING.value:
            # If the devcontainer creation fails, the process is None.
            if self.__process:
                self.__process.kill()
            self.__status = DevContainerStatus.DELETING.value
            return self.__actual_project_name
        if self.__action == DevContainerAction.DELETE:
            return self.__actual_project_name
        self.__process = DockerComposeCli.down(compose_options=self.__compose_options)
        self.__status = DevContainerStatus.DELETING.value
        self.__action = DevContainerAction.DELETE
        return self.__actual_project_name

    def start(self):
        """
        Start a stopped project.
        :return: project name
        """
        if self.__action == DevContainerAction.START:
            return self.__actual_project_name
        self.__process = DockerComposeCli.start(compose_options=self.__compose_options)
        self.__status = DevContainerStatus.STARTING.value
        self.__action = DevContainerAction.START
        return self.__actual_project_name

    def stop(self):
        """
        Stop running containers without removing them.
        :return: project name
        """
        if self.__action == DevContainerAction.STOP:
            return self.__actual_project_name
        self.__process = DockerComposeCli.stop(compose_options=self.__compose_options)
        self.__status = DevContainerStatus.STOPPING.value
        self.__action = DevContainerAction.STOP
        return self.__actual_project_name

    def get_status(self, service=MODELARTS_SERVICE_NAME):
        """
        Get the service status.
        :param service: a service in the project
        :return: the status of service
        """
        if self.__process:
            return self._get_status_from_process()
        info = DockerComposeCli.ps(compose_options=self.__compose_options)
        return self._parse_devcontainer_status(info, service)

    def _parse_devcontainer_status(self, info, service=MODELARTS_SERVICE_NAME):
        """
        Parse devcontainer status from docker-compose ps command.
        :param info: the result of docker-compose ps
        :param service: a service in the project
        :return: devcontainer status
        """
        # When the pulling process is done, we should return DevContainerStatus.PULLED.value
        if self.__status == DevContainerStatus.PULLING.value:
            return DevContainerStatus.PULLED.value
        containers = info.splitlines()
        if len(containers) <= 1:
            # After the delete process finished, nothing can be got from docker-compose ps
            return DevContainerStatus.DELETED.value if self.__status == DevContainerStatus.DELETING.value else \
                self.__status
        container_idx = -1
        service_idx = -1
        for i, container in enumerate(containers):
            modelarts_container = container.split()
            # The 'COMMAND' in modelarts_container may contain many spaces so the position of 'STATUS' is uncertain,
            # but it's definitely next to the 'SERVICE'
            for idx, entry in enumerate(modelarts_container):
                if entry == service:
                    service_idx = idx
                    container_idx = i
                    break
            if container_idx != -1:
                break
        else:
            return DevContainerStatus.DELETED.value
        status = containers[container_idx].split()[service_idx + 1]
        self.__status = DevContainer.CONTAINER_STATUS_TO_DEV_STATUS[status] \
            if status in DevContainer.CONTAINER_STATUS_TO_DEV_STATUS else DevContainerStatus.UNKNOWN.value
        return self.__status

    def _get_status_from_process(self):
        """
        Get the devcontainer status from the create or delete process.
        """
        # If the process has not finished, self.__process.poll() will none
        if self.__process.poll() is None:
            return self._get_process_status()
        err_info = self.__process.stderr.read().decode("utf-8")
        return_code = self.__process.poll()
        # When the process finished, we should set it as None.
        self.__process = None
        # If the create process was killed, the return code is 9 and no error message
        if return_code != 0 and err_info:
            self.__process = None
            raise Exception("Failed to create or delete devcontainer, err=", err_info)
        return self.__status

    def _get_process_status(self):
        """
        After starting the project, docker-compose may pull or build the image of modelarts service if the image
        does not exists, which may take a long time. So we need to report the status of 'pulling' or 'building' to user.
        """
        if self.__action != DevContainerAction.CREATE:
            return self.__status
        image_list = DockerCli.images(["-q"], self.__modelarts_image)
        # The image exists.
        if len(image_list) >= 1:
            if self.__status == DevContainerStatus.PULLING.value:
                self.__process = None
                self.__status = DevContainerStatus.PULLED.value
            return self.__status
        if self.__modelarts_image == self._get_build_image_name():
            return DevContainerStatus.BUILDING.value
        return DevContainerStatus.PULLING.value

    def _get_service_image(self, service=MODELARTS_SERVICE_NAME):
        modelarts_service = self.__content[self.COMPOSE_FIELD_SERVICE][service]
        if self.COMPOSE_FIELD_SERVICE_IMAGE in modelarts_service:
            return modelarts_service[self.COMPOSE_FIELD_SERVICE_IMAGE]
        elif self.COMPOSE_FIELD_SERVICE_BUILD in modelarts_service:
            return self._get_build_image_name(service)
        return ""

    def _get_build_image_name(self, service=MODELARTS_SERVICE_NAME):
        return self.__actual_project_name + "_" + service + ":latest"

    @property
    def compose_file(self):
        return self.__compose_file

    @property
    def project_directory(self):
        return self.__project_directory

    @property
    def project_name(self):
        return self.__project_name

    @property
    def compose_options(self):
        return self.__compose_options

    @property
    def actual_project_name(self):
        return self.__actual_project_name

    @property
    def status(self):
        return self.__status
