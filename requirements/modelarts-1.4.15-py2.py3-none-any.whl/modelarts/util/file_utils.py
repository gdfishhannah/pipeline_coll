import os
import zipfile
import stat
import yaml

EXCLUDE_FILES = [".ipynb_checkpoints"]
COMPRESS_FILE_SUFFIX = [".zip", ".tzr.gz", ".tar.bz2", ".tar.xz", ".tar"]


def get_files_modify_time(local_model_path):
    """
    Record local model files.
    :param local_model_path: directory path
    :return a dictionary describing every file and directory modification time
    """
    file_map = dict()
    files = os.listdir(local_model_path)
    for single_file in files:
        single_file_path = os.path.join(local_model_path, single_file)
        file_map[single_file_path] = str(os.path.getmtime(single_file_path))
    return file_map


def write_with_permission(file_path, mode):
    chmod_mode = stat.S_IRUSR | stat.S_IWUSR | stat.S_IRGRP | stat.S_IROTH
    flags = os.O_WRONLY | os.O_CREAT
    return os.fdopen(os.open(file_path, flags, chmod_mode), mode)


def compress_dir_to_zip(zip_file_path, source_dir, arcname=''):
    """
    Compress a directory to a zip file.
    :param zip_file_path: zip file path
    :param source_dir: the directory to be compressed
    :param arcname: the top-level folder name of the zip file
    """
    try:
        with zipfile.ZipFile(zip_file_path, 'w', zipfile.ZIP_DEFLATED) as f:
            zip_list = []
            for path, subdirs, files in os.walk(source_dir):
                for fileItem in files:
                    zip_list.append(os.path.join(path, fileItem))
                for dirItem in subdirs:
                    zip_list.append(os.path.join(path, dirItem))
            for i in zip_list:
                add_file = True
                for exclude_file in EXCLUDE_FILES:
                    if exclude_file in i:
                        add_file = False
                        break
                if add_file:
                    f.write(i, i.replace(source_dir, arcname))
    except Exception as err:
        raise ("Error happens when compressing folder {} into a zip file, "
               "err={}".format(source_dir, err))


def is_supported_compress_file(path):
    """
    If path points to compressed file which is supported by training v2.
    """
    for suffix in COMPRESS_FILE_SUFFIX:
        if path.endswith(suffix):
            return True
    return False


def load_config_yaml(yaml_path):
    if not os.path.exists(yaml_path):
        raise FileNotFoundError(f"Config file path {yaml_path} does not exist.")
    with open(yaml_path, 'r') as f:
        configs = yaml.safe_load(f)
        return parse_endpoint_info(configs)


def parse_endpoint_info(config):
    if "regions" not in config.keys() or not isinstance(config.get("regions"), list):
        raise ValueError("Invalid config YAML format, which must contain regions field "
                         "and the value type must be a list.")
    if len(config["regions"]) == 0:
        raise ValueError("Config file must contain at least one region info.")
    default_index = 0
    for index, region in enumerate(config["regions"]):
        if region.get("default", False):
            default_index = index
            break
    region = config["regions"][default_index]
    return dict(iam_endpoint=region.get("iamEndpoint"),
                obs_endpoint=region.get("obsEndpoint"),
                modelarts_endpoint=region.get("modelartsEndpoint"),
                swr_endpoint=region.get("swrEndpoint"),
                console_endpoint=region.get("consoleEndpoint"),
                region_name=region.get("region"),
                display_name=region.get("displayName")
                )
