"""
Description: ROMA OBS management using roma s3 API and obs client
Author: ModelArts SDK Team
Date: 2021/07/01 - 2021/07/29
"""

import base64
import json
import logging
import multiprocessing as mp
import os
import queue
import threading
import time
from collections import defaultdict
from concurrent.futures import ThreadPoolExecutor, as_completed
from datetime import datetime
from decimal import Decimal
from xml import etree
from lxml import etree as letree

import requests
from tenacity import retry, stop_after_attempt, wait_fixed

from modelarts import constant
from .obs_base import OBSApiBase, TransferJob
from modelarts.util.obs_logger import OBSLogger
from . import constant as obs_constant
from modelarts.util.config import Config

retry_map = defaultdict(int)
file_lock = threading.Lock()
UPLOAD_FILE_BLOCK_RETRY_TIMES = 3
BLOCK_SIZE_SCALING = 10
ROMA_NEXT_MARKER = 'nextmarker'
ROMA_REGION_NAME = 'region'
ROMA_BUCKET_ID = 'bucketid'
ROMA_OBJECT_KEY = 'objectkey'
ROMA_APP_TOKEN = 'apptoken'
try:
    STANDARD_SIZE = obs_constant.MAX_BLOCK_SIZE / BLOCK_SIZE_SCALING
except ZeroDivisionError as e:
    raise e


class RomaOBSApiImpl(OBSApiBase):
    """  Operate ROMA OBS object.
    """

    def __init__(self, app_id, csb_token, region_name):
        OBSApiBase.__init__(self)

        self.app_id = app_id
        self.csb_token = csb_token
        self.region_name = region_name
        self.roma_obs_host = Config.getenv("ROMA_OBS_HOST", strict=True)
        self.roma_obs_bucket_host = Config.getenv("ROMA_OBS_BUCKET_HOST", strict=True)
        self.headers = {"Content-Type": "application/json",
                        "csb-token": self.csb_token}

    def is_obs_file(self, obs_file):
        """ whether the file is obs file
        :param obs_file:
        :return: bool, True or False
        """
        OBSApiBase.check_obs_file_head_tail(obs_file)
        return self._check_obs_path_exist_by_metadata_api(obs_file) == 'true'

    @retry(stop=stop_after_attempt(obs_constant.RETRY_TIMES), reraise=True,
           wait=wait_fixed(obs_constant.RETRY_INTERVAL))
    def upload_file(self, src_local_file, dst_obs_dir, file_size=None, check_file=True):
        """ upload local file to obs path
        :param src_local_file: source local file path, e.g. c://programs/obs.py"
        :param dst_obs_dir: destination obs directory, e.g. obs://bucket_name/obs_dir/"
        :param file_size: local file size
        :param check_file: whether to check file path and size,
                False when called by upload_dir(do not check local files), otherwise, True(check local files).
        """
        dst_file_dir, dst_file_name = OBSApiBase.get_dst_file_name(src_local_file, dst_obs_dir)
        if dst_file_dir:
            dst_obs_dir = dst_file_dir

        if check_file:
            self._check_paths(src_local_file, dst_obs_dir, constant.UPLOAD_MODE,
                              obs_constant.FILE_MODE, is_check_obs_path_exist=False)
        _, file_name = os.path.split(src_local_file)
        file_name = dst_file_name or file_name
        bucket_name, bucket_file_path_without_bucket_name_b64, _ = \
            self._get_bucket_info_for_file_transfer(dst_obs_dir, constant.UPLOAD_MODE, file_name)
        bucket_file_address = self._get_bucket_file_address(bucket_name)
        file_size = file_size or self._get_file_size(src_local_file)

        if file_size <= int(STANDARD_SIZE):
            self._roma_api_upload_file(bucket_name, bucket_file_path_without_bucket_name_b64,
                                       bucket_file_address, src_local_file)
        else:
            if check_file:
                try:
                    _size = file_size / 1024 ** 3
                except ZeroDivisionError as _e:
                    raise _e
                OBSLogger.common_info_log(
                    f'Uploading large file <{src_local_file}>, '
                    f'size: {Decimal(_size).quantize(Decimal("0.00"))} '
                    'GB, please wait ...')
            self._roma_api_upload_large_file(bucket_name, bucket_file_path_without_bucket_name_b64, bucket_file_address,
                                             src_local_file, file_size)

    def upload_dir(self, src_local_dir, dst_obs_dir, keep_last_dir):
        """ upload local directory to obs path
        :param src_local_dir: source local directory path
        :param dst_obs_dir: destination obs directory path
        :param keep_last_dir: If True,  copy files to ./dir2/dir1.  Otherwise, to ./dir2
        """
        dst_obs_dir = OBSApiBase.add_suffix_slash(dst_obs_dir)
        src_local_dir = OBSApiBase.add_suffix_slash(src_local_dir)
        self._check_paths(src_local_dir, dst_obs_dir, constant.UPLOAD_MODE,
                          constant.DIR_MODE, is_check_obs_path_exist=False)
        src_local_file_list = OBSApiBase.get_local_dir_file_path_list(src_local_dir)
        self._upload_dir(src_local_dir, dst_obs_dir, src_local_file_list,
                         mode=obs_constant.NORMAL_MODE, silence=False, keep_last_dir=keep_last_dir)

    def increment_upload_dir(self, src_local_dir, dst_obs_dir, increment_files, keep_last_dir):
        """ upload local directory to obs path incrementally
        :param src_local_dir: source local directory path
        :param dst_obs_dir: destination obs directory path
        :param increment_files: list of increment files to be upload, e.g. ['./dir1/file1', './dir2/file2', ...]
        :param keep_last_dir: If True,  copy files to ./dir2/dir1.  Otherwise, to ./dir2
        """
        src_local_dir = OBSApiBase.add_suffix_slash(src_local_dir)
        dst_obs_dir = OBSApiBase.add_suffix_slash(dst_obs_dir)
        self._check_paths(src_local_dir, dst_obs_dir, constant.UPLOAD_MODE,
                          constant.DIR_MODE, is_check_obs_path_exist=False)
        if increment_files:
            # check local files
            OBSApiBase.check_increment_files(src_local_dir, increment_files)
        else:
            increment_files = OBSApiBase.get_increment_files(src_local_dir)
        upload_files_list = OBSApiBase.get_increment_upload_files(increment_files)
        self._upload_dir(src_local_dir, dst_obs_dir, upload_files_list,
                         mode=obs_constant.INCREMENT_MODE, silence=True, keep_last_dir=keep_last_dir)

    @retry(stop=stop_after_attempt(obs_constant.RETRY_TIMES), reraise=True,
           wait=wait_fixed(obs_constant.RETRY_INTERVAL))
    def download_file(self, src_obs_file, dst_local_dir, object_size=None, check_file=True):
        """ download obs file to local
        :param src_obs_file: source obs file path
        :param dst_local_dir: destination local directory
        :param object_size: obs file size
        :param check_file: whether to check file and size,
                True when called by upload_dir(do not check local files), otherwise, False(check local files).
        """
        dst_file_dir, dst_file_name = OBSApiBase.get_dst_file_name(src_obs_file, dst_local_dir)
        if dst_file_dir:
            dst_local_dir = dst_file_dir

        is_check_obs_path_exist = False if object_size is not None else check_file
        self._check_paths(dst_local_dir, src_obs_file, obs_constant.DOWNLOAD_MODE,
                          obs_constant.FILE_MODE, is_check_obs_path_exist=is_check_obs_path_exist)
        if check_file and object_size is None:
            object_size = self._get_file_size(src_obs_file)

        bucket_name, bucket_file_path_without_bucket_name_b64, bucket_file_name = \
            self._get_bucket_info_for_file_transfer(src_obs_file, obs_constant.DOWNLOAD_MODE, None)
        bucket_file_address = self._get_bucket_file_address(bucket_name)
        if dst_file_name:
            bucket_file_name = dst_file_name
        dst_local_file_path = os.path.join(dst_local_dir, bucket_file_name)
        if object_size <= STANDARD_SIZE:
            self._roma_api_download_file(
                bucket_file_service_address=bucket_file_address,
                bucket_name=bucket_name,
                bucket_file_path_b64=bucket_file_path_without_bucket_name_b64,
                dst_local_file_path=dst_local_file_path
            )
        else:
            if check_file:
                try:
                    _obj_size = object_size / 1024 ** 3
                except ZeroDivisionError as _e:
                    raise _e
                OBSLogger.common_info_log(
                    f'Downloading large file <{src_obs_file}>, '
                    f'size: {Decimal(_obj_size).quantize(Decimal("0.00"))} '
                    'GB, please wait ...')
            self._roma_api_download_multi_blocks(bucket_name, bucket_file_path_without_bucket_name_b64, object_size,
                                                 bucket_file_address, dst_local_file_path)

    def download_dir(self, src_obs_dir, dst_local_dir, keep_last_dir, specified_objects=None):
        """ download obs directory to local path
        :param src_obs_dir: source obs directory path
        :param dst_local_dir: destination local directory
        :param keep_last_dir: If True,  copy files to ./dir2/dir1.  Otherwise, to ./dir2
        :param specified_objects: type: list, specified objects to be downloaded, e.g. [object1, object2, ...]
        """
        if specified_objects and not isinstance(specified_objects, list):
            raise Exception(f"the type specified_objects should be [list], but got {type(specified_objects)}")

        src_obs_dir = OBSApiBase.add_suffix_slash(src_obs_dir)
        dst_local_dir = OBSApiBase.add_suffix_slash(dst_local_dir)
        self._check_paths(dst_local_dir,
                          src_obs_dir,
                          obs_constant.DOWNLOAD_MODE,
                          constant.DIR_MODE,
                          is_check_obs_path_exist=True)
        bucket_name, bucket_dir_path = OBSApiBase.get_bucket_info_for_download_dir(src_obs_dir)
        objects_key_and_size = self._get_source_files(bucket_name, bucket_dir_path)
        sub_objects_size = OBSApiBase._get_sub_objects(specified_objects, objects_key_and_size)

        self._download_dir(src_obs_dir, dst_local_dir, sub_objects_size or objects_key_and_size,
                           mode=obs_constant.NORMAL_MODE, silence=False, keep_last_dir=keep_last_dir)

    def increment_download_dir(self, src_obs_dir, dst_local_dir, increment_files, keep_last_dir):
        """ download obs directory to local path incrementally
        :param src_obs_dir: source obs directory path
        :param dst_local_dir: destination local directory
        :param increment_files: list of increment files to be download, e.g. ['./dir1/file1', './dir2/file2', ...]
        :param keep_last_dir: If True,  copy files to ./dir2/dir1.  Otherwise, to ./dir2
        """
        src_obs_dir = OBSApiBase.add_suffix_slash(src_obs_dir)
        dst_local_dir = OBSApiBase.add_suffix_slash(dst_local_dir)
        self._check_paths(dst_local_dir, src_obs_dir,
                          obs_constant.DOWNLOAD_MODE, constant.DIR_MODE, is_check_obs_path_exist=True)
        bucket_name, bucket_dir_path = OBSApiBase.get_bucket_info_for_download_dir(src_obs_dir)
        if increment_files:
            # check obs files
            self._check_increment_files(src_obs_dir, increment_files)
            increment_files = {
                file_path: {'size': self._get_file_size(file_path), 'md5': self._get_obs_file_md5(file_path)}
                for file_path in increment_files}
        else:
            increment_files = self._get_all_objects_attr(bucket_name, bucket_dir_path)
        download_files_list = self._get_increment_download_files(src_obs_dir,
                                                                 dst_local_dir,
                                                                 bucket_name,
                                                                 increment_files)
        if not download_files_list:
            return

        for path in download_files_list.keys():
            OBSApiBase.check_obs_file_head_tail(path)
        self._download_dir(src_obs_dir, dst_local_dir, download_files_list,
                           mode=obs_constant.INCREMENT_MODE, silence=True, keep_last_dir=keep_last_dir)

    def copy(self, src_path, dst_path, keep_last_dir):
        """ Transfer data between OBS and Local. Support download from OBS or upload to OBS;
            Support transter files or directory
        :param src_path: obs path or local path
        :param dst_path: obs path or local path
        :param keep_last_dir: If True,  copy files to ./dir2/dir1.  Otherwise, to ./dir2
        """
        if not src_path.startswith(constant.OBS_HEAD_FORMAT) and not dst_path.startswith(constant.OBS_HEAD_FORMAT):
            raise Exception(f'OBS path should start with {constant.OBS_HEAD_FORMAT}')
        if os.path.isdir(src_path) or self.is_obs_directory(src_path):
            self._copy_directory(src_path, dst_path, keep_last_dir)
        else:
            self._copy_file(src_path, dst_path)

    def is_obs_directory(self, obs_path):
        """ check whether the obs path is directory
        :param obs_path:
        :return: bool, True or False
        """
        if not obs_path.endswith(constant.SEP):
            obs_path += constant.SEP
        return self.is_obs_path_exists(obs_path)

    def is_obs_path_exists(self, obs_path):
        """ check whether the obs path exists
        :param obs_path: obs directory or obs file
        :return: bool, True or False
        """
        if obs_path.startswith(constant.OBS_HEAD_FORMAT) and '\\' in obs_path:
            raise Exception(f'{obs_constant.WINDOWS_PATH_SEP_WARN}, got {obs_path}')
        if not obs_path.startswith(constant.OBS_HEAD_FORMAT):
            return False
        # check the obs path by check object's metadata
        if self._check_obs_path_exist_by_metadata_api(obs_path) == 'true':
            return True
        # check the obs path by listing objects under specified obs directory
        obs_path = OBSApiBase.add_suffix_slash(obs_path)
        len_object_list = self._check_obs_path_exist_by_objectkey_api(obs_path)
        return not len_object_list == 0

    def del_obs_file(self, obs_file):
        """ delete obs object(file)
        :param obs_file: obs object(file)
        """
        self._check_obs_path(obs_file, obs_constant.DOWNLOAD_MODE, obs_constant.FILE_MODE, True)
        bucket_name, object_key = OBSApiBase.split_obs_path(obs_file)
        bucket_id = self._get_bucket_id_by_name(bucket_name)
        self._del_obs_file(bucket_id, object_key)

    def del_obs_dir(self, obs_dir):
        """ delete obs objects(directory)
        :param obs_dir: obs objects(directory)
        """
        obs_dir = OBSApiBase.add_suffix_slash(obs_dir)
        self._check_obs_path(obs_dir, obs_constant.DOWNLOAD_MODE, constant.DIR_MODE, True)
        bucket_name, object_key = OBSApiBase.split_obs_path(obs_dir)
        bucket_id = self._get_bucket_id_by_name(bucket_name)
        self._del_obs_file(bucket_id, object_key)

    def list_all_objects(self, obs_path, is_list_all_objects=True, show_progress=False):
        """ get all objects in obs directory
        :param obs_path: obs directory which should starts with obs:/ and ends with /
        :param is_list_all_objects: set to False while checking obs path for reducing time of listing objects,
                                      True for transfer data, default is True
        :param show_progress: show the progress of listing obs objects, default is False
        :return: list of obs files
        """
        bucket_name, object_key = OBSApiBase.split_obs_path(obs_path)
        bucket_dir_path, _ = os.path.split(object_key)
        object_keys = self._get_bucket_dir_objects(bucket_name, bucket_dir_path, is_list_all_objects, show_progress)
        return [f"{constant.OBS_HEAD_FORMAT}{bucket_name}/{object_key}" for object_key in object_keys]

    def list_buckets(self):
        request_url = f"{self.roma_obs_bucket_host}s3/listbuckets?appid={self.app_id}"
        headers = {"Content-Type": "application/json", "csb-token": self.csb_token}
        bucket_list = []
        try:
            resp = requests.get(request_url, headers=headers)
            if resp.status_code < 300:
                for bucket in json.loads(resp.content)["buckets"]:
                    bucket_list.append(bucket.get("name"))
            return bucket_list
        except Exception as e_:
            error_reason = "Failed to get bucket list {}".format(e_)
            OBSApiBase.handle_exception_logs(error_reason)
        return []

    def is_bucket_exists(self, bucket_name):
        return bucket_name in self.list_buckets()

    def create_obs_bucket(self, bucket_name, region_name=None):
        if region_name is None:
            region_name = self.region_name
        request_url = f"{self.roma_obs_bucket_host}s3/createbucket?" \
                      f"appid={self.app_id}&vendor=HEC&region={region_name}"
        headers = {"Content-Type": "application/json", "csb-token": self.csb_token}
        body = {"name": bucket_name, "type": "STANDARD",
                "networkType": "common", "ifAllowGreenVisit": "true"}
        try:
            resp = requests.post(request_url, headers=headers, json=body)
            if resp.status_code != 200:
                raise Exception(f'Failed to create obs bucket {bucket_name}, '
                                f'status code is {resp.status_code},'
                                f'reason is {resp.content}')
        except Exception as _e:
            raise _e

    def make_obs_dir(self, obs_dir):
        """ make obs directory
        :param obs_dir: obs directory which should starts with obs://
        """
        bucket_name, object_key = OBSApiBase.split_obs_path(obs_dir)
        bucket_id = self._get_bucket_id_by_name(bucket_name)

        headers = {"Content-Type": "application/json", "csb-token": self.csb_token}
        body = {"id": bucket_id, "name": os.path.basename(object_key),
                "path": os.path.dirname(object_key), "userPrivate": False}

        request_url = f"{self.roma_obs_bucket_host}s3/newfolder?appid={self.app_id}"
        try:
            resp = requests.post(request_url, headers=headers, json=body)
            if resp.status_code != 200:
                raise Exception(f'Failed to create obs directory {obs_dir}, '
                                f'status code is {resp.status_code},'
                                f'reason is {resp.content}')
        except Exception as e:
            raise e

    def get_objects_size(self, obs_path):
        """ get size of obs objects
        :param obs_path: obs directory or obs file
        :return: dict of obs path and obs file size, e.g. {'obs_object': file_size}
        """
        objects_size = {}
        if self.is_obs_directory(obs_path):
            obs_path = OBSApiBase.add_suffix_slash(obs_path)
            bucket_name, object_key = OBSApiBase.split_obs_path(obs_path)
            bucket_dir_path, bucket_file_name = os.path.split(object_key)
            bucket_dir_path = OBSApiBase.add_suffix_slash(bucket_dir_path)
            objects_attr = self._get_all_objects_attr(bucket_name, bucket_dir_path,
                                                      is_list_all_objects=True)
            for object_key, object_attr in objects_attr.items():
                objects_size[f"{constant.OBS_HEAD_FORMAT}{bucket_name}/{object_key}"] = int(object_attr.get('size'))
            return objects_size
        elif self.is_obs_file(obs_path):
            objects_size[obs_path] = int(self._get_obs_metadata(obs_path).get('objectKey').get('size'))
            return objects_size
        else:
            raise Exception(f"Expected valid obs directory or obs file, but got {obs_path}")

    def _check_increment_files(self, src_obs_dir, increment_files):
        """ check whether increment files legal
        :param src_obs_dir:
        :param increment_files:
        :return:
        """
        OBSApiBase.check_list_type(increment_files)
        for increment_file in increment_files:
            self._check_obs_path(increment_file, obs_constant.DOWNLOAD_MODE, obs_constant.FILE_MODE, True)
        OBSApiBase.check_parent_path(src_obs_dir, increment_files)

    def _get_source_files(self, bucket_name, bucket_path_without_bucket_name):
        """ get source file paths
        :param bucket_name:
        :param bucket_path_without_bucket_name:
        :return: objects_key_and_size: type: dict, e.g. {objects1: size1, objects2: size2, ... }
        """
        objects_attr_dict = self._get_all_objects_attr(bucket_name, bucket_path_without_bucket_name)

        objects_key_and_size = {}
        for object_key, object_attr in objects_attr_dict.items():
            if not object_key.endswith(constant.SEP):
                object_path = f"{constant.OBS_HEAD_FORMAT}{bucket_name}/{object_key}"
                objects_key_and_size[object_path] = int(object_attr.get('size'))
        return objects_key_and_size

    def _get_increment_download_files(self, src_obs_dir, dst_local_dir, bucket_name, increment_files):
        """ get files with the modified md5
        :param src_obs_dir: source obs path
        :param dst_local_dir:  destination local path
        :param bucket_name:
        :param increment_files: dict type, e.g. {object1_key : {'object1_md5':'O', 'object1_size':xxx}, ...}
        :return: dict of obs file and size, e.g. {object1_key : object1_size, ...}
        """
        increment_files_attr = self._reset_obs_MD5(bucket_name, increment_files)
        return OBSApiBase.get_increment_download_files(bucket_name, increment_files_attr)

    def _reset_obs_MD5(self, bucket_name, increment_files):
        """ get files with the latest update time
        :param bucket_name:
        :param increment_files: dict type, e.g. {object1_key : {'object1_md5':'O', 'object1_size':xxx}, ...}
        :return: dict type, e.g. {object1_key : {'object1_md5':'new_md5', 'object1_size':xxx}, ...}
        """
        for increment_file, file_size_and_md5 in increment_files.items():
            if int(file_size_and_md5.get('size')) >= obs_constant.FILE_SIZE_REQUIRED_MD5:
                file_md5 = self._get_obs_file_md5(f'{constant.OBS_HEAD_FORMAT}{bucket_name}/{increment_file}')
                increment_files[increment_file]['md5'] = file_md5

        return increment_files

    def _upload_dir(self, src_local_dir, dst_obs_dir, src_local_files_list, mode, silence, keep_last_dir):
        """ upload local directory to obs
        :param src_local_dir: source local directory path
        :param dst_obs_dir: destination obs directory path
        :param src_local_files_list: list of local files to be upload
        :param mode: normal or increment, normal represents upload, Otherwise, increment upload
        :param silence: show transfer progress, False for upload or download, True for increment transfer
        :param keep_last_dir: If True,  copy files to ./dir2/dir1.  Otherwise, to ./dir2
        """
        src_local_files_list, dst_obs_files_list = OBSApiBase.get_upload_files_list(src_local_dir,
                                                                                    dst_obs_dir,
                                                                                    src_local_files_list,
                                                                                    keep_last_dir)

        upload_job = TransferJob(self.upload_file,
                                 src_file_list=src_local_files_list,
                                 dst_file_list=dst_obs_files_list,
                                 file_size_list=None,
                                 mode=mode,
                                 silence=silence)

        OBSApiBase.do_transfer(upload_job)

    def _copy_directory(self, src_path, dst_path, keep_last_dir):
        """ upload/download directory
        :param src_path: source path
        :param dst_path: destination path
        :param keep_last_dir: If True,  copy files to ./dir2/dir1.  Otherwise, to ./dir2
        """
        if os.path.isdir(src_path):
            self.upload_dir(src_path, dst_path, keep_last_dir)
        else:
            self.download_dir(src_path, dst_path, keep_last_dir)

    def _copy_file(self, src_path, dst_path):
        """ upload/download file
        :param src_path: source path
        :param dst_path: destination path
        """
        if os.path.isfile(src_path):
            self.upload_file(src_path, dst_path)
        elif self.is_obs_path_exists(src_path.rstrip(constant.SEP)):
            self.download_file(src_path, dst_path)
        else:
            raise Exception(f'file {src_path} does not exist')

    def _get_bucket_info_for_file_transfer(self, obs_path, transfer_mode, file_name):
        """
        :param obs_path: obs directory or file
        :param transfer_mode: download or upload
        :param file_name: the name of file to be transfered
        :return: bucket name, bucket file path, bucket file name
        """
        bucket_name, object_key = OBSApiBase.split_obs_path(obs_path)
        bucket_dir_path, bucket_file_name = os.path.split(object_key)
        if transfer_mode == obs_constant.DOWNLOAD_MODE:
            bucket_file_path_without_bucket_name = \
                OBSApiBase.update_path_sep(os.path.join(bucket_dir_path, bucket_file_name))
        elif transfer_mode == constant.UPLOAD_MODE:
            bucket_file_path_without_bucket_name = \
                OBSApiBase.update_path_sep(os.path.join(bucket_dir_path, file_name))
        else:
            raise Exception(f'transfer_mode only support {constant.UPLOAD_MODE} and {obs_constant.DOWNLOAD_MODE},'
                            f' but got {transfer_mode}')
        bucket_file_path_without_bucket_name_b64 = base64.urlsafe_b64encode(
            bucket_file_path_without_bucket_name.encode()).decode('utf-8')
        return bucket_name, bucket_file_path_without_bucket_name_b64, bucket_file_name

    def _get_object_token(self, bucket_id, objectkey):
        """ get the token of object to be deleted
        :param bucket_id: bucket id
        :param objectkey: directory path of object
        :return: object token, file server ip and port
        """
        request_url = "{}s3/deleteobjects?appid={}".format(self.roma_obs_bucket_host, self.app_id)
        headers = {"Content-Type": "application/json", "csb-token": self.csb_token}
        body = {"bucketid": bucket_id, "objectKeyList": [objectkey], "objectSizeList": [""]}
        try:
            response = requests.delete(request_url, json=body, headers=headers)
            if response.status_code >= 300:
                raise Exception(f"status code of response is {response.status_code}, content is {response.content}")
            else:
                content = json.loads(response.content)
                if not content['success']:
                    raise Exception(content['msg'])
        except Exception as e:
            raise Exception(e)
        object_token = content['token']
        file_server_ip_and_port = content['fileServerIpAndPort']
        return object_token, file_server_ip_and_port

    def _del_obs_file(self, bucket_id, objectkey):
        """ delete obs object(file)
        :param bucket_id:
        :param objectkey: directory path of object
        """
        token, file_server_ip_and_port = self._get_object_token(bucket_id, objectkey)
        request_url = "{file_server_ip_and_port}/rest/csbfileserver/api/invoke/by/token?token={token}".format(
            file_server_ip_and_port=file_server_ip_and_port,
            token=token
        )
        headers = {"Content-Type": "application/json", "csb-token": self.csb_token}
        try:
            response = requests.post(request_url, headers=headers, verify=False)
            if response.status_code >= 300:
                raise Exception(f"status code of response is {response.status_code}, content is {response.content}")
            content = json.loads(response.content)
            if not content['success']:
                raise Exception(content['msg'])
        except Exception as e:
            raise Exception(e)

    def _check_obs_path_exist_by_metadata_api(self, obs_path):
        """ check whether the obs path exists by metadata api
        :param obs_path: obs path
        :return:
        """
        content = self._get_obs_metadata(obs_path)
        return content.get('success')

    def _get_obs_metadata(self, obs_path):
        """ get metadata of obs file
        :param obs_path: obs path
        :return: metadata of obs file, which contained file size, md5, updated time and so on.
        """
        bucket_name, object_key = OBSApiBase.split_obs_path(obs_path)
        bucket_file_service_address = self._get_bucket_file_address(bucket_name)
        object_key_b64 = base64.urlsafe_b64encode(
            object_key.encode()).decode('utf-8')
        request_url = "{endpoint}/rest/boto3/s3/object/metadata?" \
                      "vendor=HEC&{roma_region}" \
                      "={region}&{roma_bucketid}={bucketid}&{roma_apptoken}=" \
                      "{apptoken}&{roma_objectkey}=" \
                      "{objectkey}".format(endpoint=bucket_file_service_address,
                                           region=self.region_name,
                                           bucketid=bucket_name,
                                           apptoken=self.csb_token,
                                           objectkey=object_key_b64,
                                           roma_region=ROMA_REGION_NAME,
                                           roma_apptoken=ROMA_APP_TOKEN,
                                           roma_objectkey=ROMA_OBJECT_KEY,
                                           roma_bucketid=ROMA_BUCKET_ID
                                           )

        headers = {"Content-Type": "application/json"}
        try:
            response = requests.get(request_url, headers=headers)
        except Exception:
            # return request failed instead of raise exception, to enable check obs path exists
            return {"success": False}

        if response.status_code >= 300:
            return {"success": False}

        content = json.loads(response.content)
        return content

    def _get_obs_file_md5(self, obs_path):
        """ get md5 of obs file
        :param obs_path: obs path
        :return: md5 of obs file
        """
        bucket_name, object_key = OBSApiBase.split_obs_path(obs_path)
        bucket_id = self._get_bucket_id_by_name(bucket_name)
        request_url = "{endpoint}s3/object/metadata?id={id}".format(endpoint=self.roma_obs_bucket_host,
                                                                    id=bucket_id
                                                                    )
        headers = {"Content-Type": "application/json", "csb-token": self.csb_token}
        body = {"objectKey": object_key}
        try:
            response = requests.post(request_url, headers=headers, json=body)
            if response.status_code >= 300:
                raise Exception(f"status code of response is {response.status_code}, content is {response.content}")
        except Exception as e:
            raise Exception(e)
        content = json.loads(response.content)

        return content.get('result').get('eTage').strip('\"')

    def _get_obs_object_size(self, obs_path):
        """ get size of obs file
        :param obs_path: obs path
        :return: size of obs file
        """
        content = self._get_obs_metadata(obs_path)
        return int(content.get('objectKey').get('size'))

    def _check_obs_path_exist_by_objectkey_api(self, obs_path):
        """ get list of objects
        :param obs_path: obs path
        :return: length of existed objects list
        """
        bucket_name, object_key = OBSApiBase.split_obs_path(obs_path)
        bucket_dir_path, _ = os.path.split(object_key)
        bucket_dir_path += constant.SEP
        object_list = self._get_bucket_dir_objects(bucket_name, bucket_dir_path, is_list_all_objects=False)
        return len(object_list)

    def _check_paths(self, local_path, obs_path, transfer_mode, file_mode, is_check_obs_path_exist=True):
        """ check whether both local path and obs path legal and exist
        :param local_path: local directory or local file
        :param obs_path:  obs directory or obs file
        :param transfer_mode:  download or upload
        :param file_mode: file or dir
        :param is_check_obs_path_exist: True for download, False for upload
        :return:
        """
        OBSApiBase.check_local_path_legal(local_path, transfer_mode, file_mode)
        self._check_obs_path(obs_path, transfer_mode, file_mode, is_check_obs_path_exist)

    def _check_obs_path(self, obs_path, transfer_mode, file_mode, is_check_obs_path_exist):
        """ check whether the obs path legal and exist
        :param obs_path: obs directory or file
        :param transfer_mode: download or upload
        :param file_mode: file or dir
        :param is_check_obs_path_exist: True for download, False for upload
        :return:
        """
        OBSApiBase.check_obs_path_legal(obs_path, transfer_mode, file_mode)
        if is_check_obs_path_exist and not self.is_obs_path_exists(obs_path):
            raise Exception(f'your obs path {obs_path} does not exist')

    def _download_dir(self, src_obs_dir, dst_local_dir, objects_key_and_size, mode, silence, keep_last_dir):
        """ download obs directory to local path
        :param src_obs_dir: source obs directory path
        :param dst_local_dir: destination local directory path
        :param objects_key_and_size: type: dict, e.g. {objects1: size1, objects2: size2, ... }
        :param mode: normal or increment, normal represents upload or download, Otherwise, increment transfer
        :param silence: show transfer progress, False for normal mode(upload or download), True for increment
        :param keep_last_dir: If True,  copy files to ./dir2/dir1.  Otherwise, to ./dir2
        :return:
        """
        _, bucket_dir_path = OBSApiBase.get_bucket_info_for_download_dir(src_obs_dir)
        src_obs_file_list, dst_local_file_list, obs_object_size_list = \
            OBSApiBase.get_download_files_list(src_obs_dir,
                                               dst_local_dir,
                                               bucket_dir_path,
                                               objects_key_and_size,
                                               keep_last_dir)

        download_job = TransferJob(self.download_file,
                                   src_file_list=src_obs_file_list,
                                   dst_file_list=dst_local_file_list,
                                   file_size_list=obs_object_size_list,
                                   mode=mode,
                                   silence=silence)

        OBSApiBase.do_transfer(download_job)

    def _get_bucket_file_address(self, bucket_name):
        """ get bucket file operation endpoint
        :param bucket_name:
        :return: roma bucket file endpoint
        """
        bucket_id = self._get_bucket_id_by_name(bucket_name=bucket_name)
        if not bucket_id:
            raise Exception(f'bucket {bucket_name} does not exist in current account')
        bucket_file_service_address = self._roma_api_get_file_upload_endpoint(
            bucket_id)
        return bucket_file_service_address

    def _get_all_objects_attr(self, bucket_name, bucket_dir_path, is_list_all_objects=True, show_list_progress=False):
        """ get all objects path and update time in obs directory
        :param bucket_dir_path: obs directory, as obs://
        :param bucket_name:
        :param is_list_all_objects: set to False while checking obs path for reducing time of listing objects,
                                      True for transfer data, default is True
        :param show_list_progress: default is False
        :return: objects attribute, type: dict. e.g. {'obs://bucket_name/file_path:{'size':123, 'md5':'aaa'}, ...}
        """
        bucket_file_service_address = self._get_bucket_file_address(
            bucket_name)
        bucket_dir_path_b64 = base64.urlsafe_b64encode(
            bucket_dir_path.encode()).decode('utf-8')
        object_attr_dict = self._get_objects_attribute(
            bucket_file_service_address,
            bucket_name,
            bucket_dir_path_b64,
            is_list_all_objects=is_list_all_objects,
            show_list_progress=show_list_progress)

        return object_attr_dict

    def _get_bucket_dir_objects(self, bucket_name, bucket_dir_path, is_list_all_objects=True, show_list_progress=False):
        """ get all objects in obs directory
        :param bucket_dir_path: obs directory, as s3://
        :param bucket_name:
        :param is_list_all_objects: set to False while checking obs path for reducing time of listing objects,
                                      True for transfer data, default is True
        :param show_list_progress: default is False
        :return: list of object key in bucket_dir_path
        """
        return list(self._get_all_objects_attr(bucket_name, bucket_dir_path,
                                               is_list_all_objects, show_list_progress).keys())

    def _get_bucket_id_by_name(self, bucket_name):
        """
        :param bucket_name: bucket name
        :return: bucket id
        """
        bucket_list = self._roma_api_get_bucket_list()
        bucket_name_list = [i['name'] for i in bucket_list]
        if bucket_name in bucket_name_list:
            bucket_id = bucket_list[bucket_name_list.index(bucket_name)]['id']
        else:
            bucket_id = None
        return bucket_id

    def _get_objects_attribute(self, bucket_file_service_address, bucket_name, bucket_dir_path_b64, nextmarker="",
                               is_list_all_objects=True, show_list_progress=False):
        """ get latest update time of whole objects
        :param bucket_file_service_address: bucket file service address
        :param bucket_name:  bucket id is bucket name
        :param bucket_dir_path_b64:  bucket directory base64 coded
        :param nextmarker: next page flags
        :param is_list_all_objects: set to False while checking obs path for reducing time of listing objects,
                                      True for transfer data, default is True
        :param show_list_progress: default is False
        :return:  objects attribute, type: dict. e.g. {'obs://bucket_name/file_path:{'size':123, 'md5':'aaa'}, ...}
        """
        is_truncated = True
        object_keys = []
        file_cnt = 0
        while is_truncated:
            # at most 1000 files one time
            resp = self._roma_api_get_bucket_object_keys(
                bucket_file_service_address, bucket_name, bucket_dir_path_b64,
                nextmarker)
            nextmarker = resp[ROMA_NEXT_MARKER]
            is_truncated = resp['truncated'] == str(True).lower() if is_list_all_objects else False
            object_keys.extend(resp['objectKeys'])
            file_cnt += len(resp['objectKeys'])
            if show_list_progress:
                OBSLogger.common_info_log(f'listing obs object: {file_cnt}')
        object_attr_dict = {}
        for dic in object_keys:
            object_attr_dict[dic['objectKey']] = {"MD5": 'None', "size": dic['size']}
        return object_attr_dict

    def _roma_api_upload_file(self, bucket_name,
                              bucket_file_path_without_bucket_name_b64,
                              bucket_file_address,
                              src_local_file):
        """
        :param bucket_name:
        :param bucket_file_path_without_bucket_name_b64:
        :param bucket_file_address:
        :param src_local_file:
        :return:
        """
        request_url = "{}/rest/boto3/s3/HEC/{}/{}/{}/{}".format(
            bucket_file_address,
            self.region_name,
            self.csb_token,
            bucket_name,
            bucket_file_path_without_bucket_name_b64)
        headers = {"Content-Type": "text/plain", "csb-token": self.csb_token}
        body = open(src_local_file, 'rb')
        try:
            response = requests.put(request_url, data=body, headers=headers,
                                    verify=False)
            if response.status_code > 200:
                OBSLogger.roma_error_log(api_response=response)
                raise Exception(response.content)
        except Exception as e:
            error_reason = "Failed to upload file,  {}".format(e)
            OBSApiBase.handle_exception_logs(error_reason)

    def _roma_api_download_file(self, bucket_file_service_address, bucket_name,
                                bucket_file_path_b64, dst_local_file_path):
        """ roam api for download file
        :param bucket_file_service_address:
        :param bucket_name:
        :param bucket_file_path_b64:
        :param dst_local_file_path:
        :return:
        """
        request_url = '{}/rest/boto3/s3/HEC/{}/{}/{}/{}'.format(
            bucket_file_service_address,
            self.region_name,
            self.csb_token,
            bucket_name,
            bucket_file_path_b64,
        )
        headers = {"Content-Type": "text/plain", "csb-token": self.csb_token}
        try:
            response = requests.get(request_url, headers=headers, verify=False)
            if response.status_code > 200:
                OBSLogger.roma_error_log(api_response=response)
                raise Exception(response.content)
            with os.fdopen(os.open(dst_local_file_path, os.O_WRONLY | os.O_CREAT | os.O_TRUNC,
                                   constant.FILE_PERMISSION), "wb") as f:
                f.write(response.content)
                f.close()
        except Exception as e:
            error_reason = "Failed to download file,  {}".format(e)
            OBSApiBase.handle_exception_logs(error_reason)

    def _roma_api_get_bucket_object_keys(self, bucket_file_service_address,
                                         bucket_name, bucket_dir_path_b64, nextmarker):
        """
        :param bucket_file_service_address: bucket file service address
        :param bucket_name:  bucket id is bucket name
        :param bucket_dir_path_b64:  bucket directory base64 coded
        :return:  objectKeys
        """
        request_url = "{endpoint}/rest/boto3/s3/list/bucket/objectkeys?vendor=HEC&{roma_region}" \
                      "={region}&{roma_bucketid}={bucketid}&{roma_apptoken}={apptoken}&{roma_objectkey}=" \
                      "{objectkey}&{roma_nextmarker}={nextmarker}" \
            .format(endpoint=bucket_file_service_address,
                    region=self.region_name,
                    bucketid=bucket_name,
                    apptoken=self.csb_token,
                    objectkey=bucket_dir_path_b64,
                    roma_region=ROMA_REGION_NAME,
                    roma_apptoken=ROMA_APP_TOKEN,
                    roma_objectkey=ROMA_OBJECT_KEY,
                    roma_bucketid=ROMA_BUCKET_ID,
                    roma_nextmarker=ROMA_NEXT_MARKER,
                    nextmarker=nextmarker)

        headers = {"Content-Type": "application/json",
                   "csb-token": self.csb_token}
        try:
            response = requests.get(request_url, headers=headers, verify=False)
            if response.status_code > 200:
                OBSLogger.roma_error_log(api_response=response)
                raise Exception(response.content)
            return json.loads(response.content)
        except Exception as e:
            error_reason = "Fail to get bucket object keys,  {}".format(e)
            OBSApiBase.handle_exception_logs(error_reason)

    def _roma_api_get_bucket_list(self):
        """ get roma user bucket list
        :return: bucket list
        """
        request_url = "{host}s3/listbuckets?appid={app_id}".format(
            host=self.roma_obs_host, app_id=self.app_id)
        try:
            response = requests.get(request_url, headers=self.headers,
                                    verify=False)
            if json.loads(response.content)['success']:
                return json.loads(response.content)['buckets']
            OBSLogger.roma_error_log(api_response=response)
            raise Exception(json.loads(response.content)['msg'])
        except Exception as e:
            error_reason = "Failed to get bucket list {}".format(e)
            OBSApiBase.handle_exception_logs(error_reason)

    def _roma_api_get_file_upload_endpoint(self, bucket_id):
        """
        :param bucket_id: roma bucket id
        :return: file server ip and port for upload file
        """
        try:
            request_url = "{}userconsole/get/hec/fileserver/ip/and/port?id={}".format(self.roma_obs_host, bucket_id)
            response = requests.get(request_url, headers=self.headers,
                                    verify=False)
            if json.loads(response.content)['success']:
                file_service_address = json.loads(response.content)[
                    'fileServerIpAndPort']
                return file_service_address
            OBSLogger.roma_error_log(api_response=response)
            raise Exception(json.loads(response.content)['msg'])
        except Exception as e:
            error_reason = "Failed to get file server ip and port, for {}".format(e)
            OBSApiBase.handle_exception_logs(error_reason)

    def _get_file_size(self, file_path):
        if os.path.isfile(file_path):
            return int(os.path.getsize(file_path))
        if file_path.startswith(constant.OBS_HEAD_FORMAT):
            return self._get_obs_object_size(file_path)
        raise Exception(f'file {file_path} does not exist')

    def _init_multi_upload_id(self, bucket_name, object_key, bucket_file_address):
        """ initialize upload id for large file(larger than 500M)
        :param bucket_name: bucket name
        :param object_key: object key
        :param bucket_file_address:
        :return: unique upload id
        """
        request_url = f"{bucket_file_address}/rest/boto3/s3/HEC/{self.region_name}/{self.csb_token}/" \
                      f"{bucket_name}/{object_key}?uploads=uploads"
        headers = {"Content-Type": "text/plain"}

        resp = requests.post(request_url, headers=headers)
        parserSafe = letree.XMLParser(resolve_entities=False)
        tree = letree.fromstring(resp.content, parser=parserSafe)
        if not tree.findall('UploadId'):
            raise (f"Failed to get the upload id of {object_key}, please retry upload it")
        return tree.findall('UploadId')[0].text

    def _upload_block(self, bucket_name, object_key, upload_id, src_local_file, completed_blocks, bucket_file_address,
                      file_block_queue):
        """ upload a block of file
        :param bucket_name: bucket name
        :param object_key: object key
        :param upload_id: unique upload id
        :param src_local_file: source local file
        :param completed_blocks: record index and md5 of uploaded file block
        :param bucket_file_address:
        :param file_block_queue: record index range of size of all file blocks
        """
        headers = {"Content-Type": "text/plain", "Connection": "keep-alive"}
        while file_block_queue.qsize() > 0:
            file_block_info = file_block_queue.get()
            start_idx, end_idx, block_idx = file_block_info

            request_url = f"{bucket_file_address}/rest/boto3/s3/HEC/{self.region_name}/{self.csb_token}/" \
                          f"{bucket_name}/{object_key}?partNumber={block_idx}&uploadId={upload_id}"
            with open(src_local_file, "rb") as file_io:
                try:
                    file_io.seek(start_idx)
                    resp = requests.put(request_url, data=file_io.read(end_idx - start_idx + 1), headers=headers)

                    if resp.status_code != 200:
                        raise Exception(
                            f"Failed to upload part {block_idx} of {object_key}, error code is {resp.text}")
                    completed_blocks[str(block_idx)] = {"block_idx": str(block_idx), "etag": resp.headers["ETag"]}

                except Exception:
                    import traceback
                    traceback.print_exc()
                    key = object_key + "@" + str(file_block_info)
                    retry_map[key] += 1

                    if retry_map[key] > UPLOAD_FILE_BLOCK_RETRY_TIMES:
                        logging.error(f"{key} try {UPLOAD_FILE_BLOCK_RETRY_TIMES} times failed")
                        continue
                    file_block_queue.put(file_block_info)
                    self._upload_block(bucket_name, object_key, upload_id, src_local_file, completed_blocks,
                                       bucket_file_address, file_block_queue)

    def _merge_multi_blocks(self, bucket_name, object_key, src_local_file, upload_id, completed_blocks,
                            bucket_file_address):
        """ merge uploaded file blocks
        :param bucket_name: bucket name
        :param object_key: object key
        :param src_local_file: source local file
        :param upload_id: unique upload id
        :param completed_blocks: record index and md5 of uploaded file block
        :param bucket_file_address:
        """
        request_url = f"{bucket_file_address}/rest/boto3/s3/HEC/{self.region_name}/{self.csb_token}/" \
                      f"{bucket_name}/{object_key}?uploadId={upload_id}"
        headers = {"Content-Type": "text/plain"}
        data = self.parse2xml(completed_blocks)
        resp = requests.post(request_url, headers=headers, data=data)

        if resp.status_code != 200:
            raise Exception(f'Failed to merge blocks of file {src_local_file}, error code is {resp.status_code}, '
                            'please retry upload it')

    def parse2xml(self, completed_blocks):
        root = etree.ElementTree.Element("CompleteMultipartUpload")

        for tag in completed_blocks.values():
            part = etree.ElementTree.SubElement(root, "Part")
            part_number = etree.ElementTree.SubElement(part, "PartNumber")
            part_number.text = tag["block_idx"]
            etag = etree.ElementTree.SubElement(part, "ETag")
            etag.text = tag["etag"]

        return etree.ElementTree.tostring(root)

    def _set_size_range_list(self, file_size):
        """ set size range of different blocks
        :param file_size: total size of a file
        :return: list of size range of different blocks, e.g. [[0, 100, 1], [100, 200, 2], ...]
        """
        size_range_list = [[i if i == 0 else i + 1, i + int(STANDARD_SIZE)]
                           for i in range(0, file_size + 1, int(STANDARD_SIZE))]

        index = 1
        if size_range_list[-1][0] > file_size:
            del size_range_list[-1]
        if size_range_list[-1][1] > file_size:
            size_range_list[-1][1] = file_size
        for r in size_range_list:
            r.append(index)
            index += 1
        return size_range_list

    def _roma_api_upload_large_file(self, bucket_name, bucket_file_path_without_bucket_name_b64, bucket_file_address,
                                    src_local_file, file_size):
        """ upload large local file(larger than 500M)
        :param bucket_name: bucket name
        :param bucket_file_path_without_bucket_name_b64: object key base64
        :param src_local_file: source local file
        :param file_size: local file size
        :param bucket_file_address:
        """
        file_block_queue = mp.Manager().Queue()
        completed_blocks = mp.Manager().dict()

        size_range_list = self._set_size_range_list(file_size)
        for block_size_range in size_range_list:
            file_block_queue.put(block_size_range)

        upload_id = self._init_multi_upload_id(bucket_name, bucket_file_path_without_bucket_name_b64,
                                               bucket_file_address)

        processes_list = []
        threads = min(len(size_range_list), obs_constant.DEFAULT_THREADS)
        for i in range(threads):
            p = mp.Process(target=self._upload_block,
                           args=(bucket_name, bucket_file_path_without_bucket_name_b64, upload_id, src_local_file,
                                 completed_blocks, bucket_file_address, file_block_queue,))
            processes_list.append(p)

        for p in processes_list:
            p.start()
        for p in processes_list:
            p.join()

        self._merge_multi_blocks(bucket_name, bucket_file_path_without_bucket_name_b64, src_local_file, upload_id,
                                 completed_blocks, bucket_file_address)

    def _roma_api_download_multi_blocks(self, bucket_name, object_key_b64, object_size, bucket_file_address,
                                        dst_local_file):
        """ download large obs file(larger than 500M)
        :param bucket_name: bucket name
        :param object_key_b64: object key base64
        :param dst_local_file: destination local file
        :param object_size: obs file size
        :param bucket_file_address:
        """

        size_range_list = [[i if i == 0 else i + 1, int(i + STANDARD_SIZE)] for i in
                           range(0, object_size + 1, int(STANDARD_SIZE))]
        file_block_queue = queue.Queue()
        for block_size_range in size_range_list:
            file_block_queue.put(block_size_range)

        threads = min(len(size_range_list), obs_constant.DEFAULT_THREADS)
        pool = ThreadPoolExecutor(max_workers=threads)
        file_io = os.fdopen(os.open(dst_local_file, os.O_RDWR | os.O_CREAT, constant.FILE_PERMISSION), "wb+")
        threads_list = []
        for i in range(threads):
            thread_job = pool.submit(self._download_block, bucket_name, object_key_b64, bucket_file_address, file_io,
                                     file_block_queue)
            threads_list.append(thread_job)

        for thread_job in as_completed(threads_list):
            try:
                thread_job.result()
            except Exception as e:
                raise e
        file_io.close()

    def _download_block(self, bucket_name, object_key_b64, bucket_file_address, file_io, file_block_queue):

        """ download a block of large obs file(larger than 500M)
        :param bucket_name: bucket name
        :param object_key_b64: object key base64
        :param dst_local_file: destination local file
        :param object_size: obs file size
        :param bucket_file_address:
        :param file_block_queue: record size range of all blocks
        """
        while file_block_queue.qsize() > 0:
            block_size_range = file_block_queue.get()
            request_url = f"{bucket_file_address}/rest/boto3/s3/HEC/{self.region_name}/{self.csb_token}/" \
                          f"{bucket_name}/{object_key_b64}"
            headers = {"Content-Type": "application/json", "csb-token": self.csb_token,
                       "Range": f"Range={block_size_range[0]}-{block_size_range[1]}",
                       "Date": datetime.utcnow().strftime('%a, %d %b %Y %H:%M:%S GMT'),
                       "Connection": "Keep-Alive"}

            try:
                with requests.get(request_url, headers=headers) as resp:
                    with file_lock:
                        file_io.seek(block_size_range[0])
                        for object_content in resp.iter_content(chunk_size=obs_constant.CHUNK_SIZE):
                            file_io.write(object_content)
            except Exception:
                import traceback
                traceback.print_exc()
                file_block_queue.put(block_size_range)
                time.sleep(5)
                self._download_block(bucket_name, object_key_b64, bucket_file_address, file_io, file_block_queue)
