import json
from json import JSONEncoder

from modelarts import constant
from modelarts.config.auth import auth_by_apig
from modelarts.util.secret_util import read_ak_sk_from_secret
from modelarts.util.notebook_util import roma_notebook_operation_handler
from modelarts.util.string_util import query_var


class SWRManagement(object):
    """
        SWR Management, operate SWR object, create, get and delete  namespace
    """
    def __init__(self, session):

        """
        SWR Management initial include hwc obs.

        """
        self.session = session
        swr_host = query_var(cfg_var=f"SWR_{session.region_name}", env_var="SWR_ENDPOINT", remove_prefix=True)
        if swr_host is None:
            raise ValueError("SWR endpoint info is required for swr management.")
        self.host = swr_host.replace("swr", "swr-api") if "swr-api" not in swr_host else swr_host
        self.base_namespace_request_url = '/v2/manage/namespaces'

    def get_default_namespace(self):
        """ get default namespace

        """
        try:
            user_id = read_ak_sk_from_secret()[-1]
            namespace = f"modelarts-{self.session.region_name}-{user_id}"
        except Exception:
            raise ValueError('Please use `.create_namespace(namespace="your_namespace")` instead.')
        if not self.is_namespace_exists(namespace):
            self.create_namespace(namespace)
        return namespace

    def is_namespace_exists(self, namespace):
        if not isinstance(namespace, str):
            raise TypeError(f"namespace expects for type str but got {type(namespace)}.")
        namespace_list = self.get_namespace(namespace=namespace)
        return namespace in [item.get("name") for item in namespace_list]

    @roma_notebook_operation_handler
    def create_namespace(self, namespace):

        """ Send a request to swr service to create namespace
            :return response:
        """

        body = JSONEncoder().encode({"namespace": namespace})
        return auth_by_apig(self.session, constant.HTTPS_POST, self.base_namespace_request_url,
                            body=body, host=self.host)

    def get_namespace(self, namespace=None):

        """ Send a request to swr service to get namespace
            :return namespace:
        """
        query = None
        if namespace:
            query = {"filter": "namespace::" + namespace}
        request_url = '/v2/manage/namespaces'
        res = auth_by_apig(self.session, constant.HTTPS_GET, request_url, query=query, host=self.host)
        return res.get("namespaces")

    @roma_notebook_operation_handler
    def delete_namespace(self, namespace):

        """ Send a request to swr service to delete namespace
            :return response:
        """
        if not isinstance(namespace, str):
            raise TypeError(f"namespace expects for type str but got {type(namespace)}.")
        request_url = f"{self.base_namespace_request_url}/{namespace}"
        return auth_by_apig(self.session, constant.HTTPS_DELETE, request_url, host=self.host)

    def get_repository_list(self, query=None):
        request_url = "/v2/manage/repos"
        return auth_by_apig(self.session, constant.HTTPS_GET, request_url, host=self.host, query=query)

    def get_image_info(self, image_url: str):
        image_info, tag = image_url.split(":")
        image_info_split = image_info.split("/")
        if len(image_info_split) < 2 or len(image_info_split) > 3:
            raise Exception("Invalid image url, please follow 'organization/image_name:tag'.")
        namespace, image_name = image_info.split("/")[-2:]
        request_url = f'/v2/manage/namespaces/{namespace}/repos/{image_name}/tags'
        images = auth_by_apig(self.session, constant.HTTPS_GET, request_url, host=self.host)
        for img in images:
            if img.get('Tag') == tag:
                return img
        raise ValueError(f"Could not find tag {tag} in repository {image_name}.")

    def query_image_size(self, image_url):
        # The unit of the size is byte
        return self.get_image_info(image_url=image_url).get("size")

    def query_image_layers(self, image_url):
        manifest = self.get_image_info(image_url=image_url).get("manifest")
        return json.loads(manifest).get('layers')
