"""
Description: parse file of manifest format
Author: ModelArts SDK Team
Date: 2021/07/14 - 2021/07/14
"""

import codecs
import collections
import json
from copy import deepcopy

from modelarts.dataset.format.manifest import compat
from modelarts.dataset.format.manifest import constants
from modelarts.dataset.format.manifest.annotation import Annotation
from modelarts.dataset.format.manifest.constants import PREFIX_TEXT, LABEL_SEPARATOR, PROPERTY_START_INDEX, \
    PROPERTY_END_INDEX, \
    PROPERTY_CONTENT, SOUND_CLASSIFICATION, AUDIO_CLASSIFICATION, PROPERTY_FROM, PROPERTY_TO, AUDIO_SEGMENTATION
from modelarts.dataset.format.manifest.file_util import is_local, read, save
from modelarts.dataset.format.manifest.sample import Sample


class Manifest(object):
    def __init__(self, samples, size=None):
        """
        init method
        :param samples:  list of sample
        :param size:  number of samples
        """
        self.__samples = samples
        self.__size = size

    @property
    def size(self):
        """
        :return size of the data set
        Optional field
        """
        return self.__size

    @property
    def samples(self):
        """
        :return a list of sample
        Mandatory field
        """
        return self.__samples

    def __put(self, sample_dict, key, value):
        """
        Assign a value to sample_dict if value is not None
        :param sample_dict: sample dict
        :param key: candidate key
        :param value: assign value
        :return: sample dict
        """
        if key is not None and value is not None:
            sample_dict[key] = value
        return sample_dict

    def __annotations_to_json(self, annotations):
        """
        convert annotations dict to json format.
        :param annotations: list of annotation dict
        :return json formatted annotation
        """
        annotation_json_list = []
        annotation_json = collections.OrderedDict()
        if annotations is None:
            return None
        for annotation in annotations:
            self.__put(annotation_json, constants.ANNOTATION_NAME, annotation.name)
            self.__put(annotation_json, constants.ANNOTATION_LOC, annotation.annotation_loc)
            self.__put(annotation_json, constants.ANNOTATION_LOC_MAP, annotation.annotation_loc_map)
            self.__put(annotation_json, constants.ANNOTATION_TYPE, annotation.type)
            self.__put(annotation_json, constants.ANNOTATION_ID, annotation.id)
            self.__put(annotation_json, constants.ANNOTATION_FORMAT, annotation.annotation_format)
            self.__put(annotation_json, constants.ANNOTATION_CONFIDENCE, annotation.confidence)
            self.__put(annotation_json, constants.ANNOTATION_HARD, annotation.hard)
            self.__put(annotation_json, constants.ANNOTATION_HARD_COEFFICIENT, annotation.hard_coefficient)
            self.__put(annotation_json, constants.ANNOTATION_PROPERTY, annotation.annotation_property)
            self.__put(annotation_json, constants.ANNOTATION_ANNOTATED_BY, annotation.annotated_by)
            self.__put(annotation_json, constants.ANNOTATION_CREATION_TIME, annotation.creation_time)
            annotation_json_list.append(deepcopy(annotation_json))
        return annotation_json_list

    def __toJSON(self, sample):
        """
        convert sample to json
        :param sample: sample object of dataset
        :return: sample json
        """
        sample_json = {}
        self.__put(sample_json, constants.ID, sample.id)
        self.__put(sample_json, constants.SOURCE, sample.source)
        self.__put(sample_json, constants.SOURCE_MAP, sample.source_map)
        self.__put(sample_json, constants.USAGE, sample.usage)
        self.__put(sample_json, constants.INFERENCE_LOC, sample.inference_loc)
        self.__put(sample_json, constants.SOURCE_PROPERTY, sample.source_property)
        self.__put(sample_json, constants.SAMPLE_HARD, sample.hard)
        self.__put(sample_json, constants.HARD_REASONS, sample.hard_reasons)
        self.__put(sample_json, constants.ANNOTATION_HARD_COEFFICIENT, sample.hard_coefficient)
        self.__put(sample_json, constants.ANNOTATION, self.__annotations_to_json(sample.annotations))
        return sample_json

    def save(self, path, session=None, save_mode="w"):
        """
        save dataset to local or OBS
        It will overwrite if the file path already exists.
        Please check the file path before invoking this method

        :param path: manifest output path
        :param session  Session object
        :param save_mode: default is "w", it will overwrite if file already exists.
            User can set "a" if user want to append content to one file.
            Can not append to a normal object.
        :return: None
        """
        if is_local(path):
            with codecs.open(path, save_mode, encoding='utf-8') as f_obj:
                for sample in self.samples:
                    value = self.__toJSON(sample)
                    json.dump(value, f_obj, separators=(",", ":"), ensure_ascii=False)
                    f_obj.write('\n')
        else:
            if session is None:
                raise Exception("session can not be None when read obs file.")
            manifest_json = []
            for sample in self.samples:
                value = self.__toJSON(sample)
                manifest_json.append(json.dumps(value, separators=(",", ":"), ensure_ascii=False))
            save(manifest_json, path, session, saveMode=save_mode)

    @classmethod
    def get_sample_list(
            cls,
            manifest_path,
            task_type,
            exactly_match_type=False,
            usage=constants.DEFAULT_USAGE,
            session=None,
            encoding='utf-8'
    ):
        """
        get the sample list from manifest, support local and OBS path;
        If the exactly_match_type is True, then it will match the task annotation_type exactly;
        If the exactly_match_type is False, then it will not match the task annotation_type exactly
        and match the suffix of the annotation_type
        default_usage is all. Users can use usage="train" if users want to get train sample.
        default task annotation_type is all.

        :param manifest_path:  manifest file path
        :param task_type:  task annotation_type, like:
              image_classification,object_detection, image_segmentation
              audio_classification/sound_classification, audio_content, audio_segmentation
              text_classification, text_entity, text_triplet
        :param exactly_match_type: whether exactly match task annotation_type.
              Users can set True if users want to match exactly,
              like "modelarts/image_classification; Users can set False if users don't want to match exactly,
              like "image_classification;
        :param usage: usage of the sample, like "TRAIN", "EVAL", "TEST", "inference", "all", default value is all
        :param session: Building interactions with Cloud service
        :param encoding: file encoding format
        :return: data_list, label_type
        """
        data_set = cls.parse_manifest(manifest_path, session=session, encoding=encoding)
        task_type, task_type_str = cls.__update_task_type(task_type)
        sample_list = data_set.samples
        data_list = []
        label_type = constants.SINGLE_LABLE
        for sample in sample_list:
            flag = False
            annotations = sample.annotations
            sample_usage = sample.usage
            sample_source = sample.source
            if str(sample_usage).lower().__eq__(str(usage).lower()) or str(usage).lower().__eq__(
                    constants.DEFAULT_USAGE):
                label_list = []
                if str(usage).lower().__eq__(constants.USAGE_INFERENCE):
                    flag = True
                number = 0
                for annotation in annotations:
                    if number > 0:
                        label_type = constants.MULTI_LABLE
                    number = number + 1
                    flag, label_type = cls.__get_label_list(
                        annotation,
                        exactly_match_type,
                        flag,
                        label_list,
                        label_type,
                        task_type)
            else:
                continue
            if task_type_str.endswith(constants.TEXT_CLASSIFICATION) or task_type_str.endswith(
                    constants.TEXT_ENTITY):
                if not str(sample_source).startswith(PREFIX_TEXT):
                    raise ValueError
                sample_source = str(sample_source)[len(PREFIX_TEXT):]
            if flag:
                data_list.append([sample_source, label_list])
        return data_list, label_type

    @classmethod
    def __update_task_type(cls, task_type):
        if SOUND_CLASSIFICATION is task_type:
            task_type = AUDIO_CLASSIFICATION
        task_type_str = str(task_type)
        if task_type_str.endswith("/" + SOUND_CLASSIFICATION):
            task_type = task_type_str.replace(SOUND_CLASSIFICATION, AUDIO_CLASSIFICATION)
        return task_type, task_type_str

    @classmethod
    def __get_label_list(cls, annotation, exactly_match_type, flag, label_list, label_type, task_type):
        annotation_type = annotation.type
        if exactly_match_type:
            flag = cls.get_exact_label_list(annotation, flag, label_list, task_type, annotation_type)
        else:
            flag = cls.get_not_exact_label_list(annotation, flag, label_list, task_type, annotation_type)
        return flag, label_type

    @classmethod
    def get_exact_label_list(cls, annotation, flag, label_list, task_type, annotation_type):
        """
        exact match task type and get label list .
        :param annotation:  annotation info
        :param flag:  flag
        :param label_list: label list
        :param task_type: annotation task type
        :param annotation_type:  annotation type
        :return:
        """
        if annotation_type == task_type:
            flag = True
            task_type_str = str(task_type)
            if task_type_str.endswith("/" + constants.IMAGE_CLASSIFICATION) \
                    or task_type_str.endswith("/" + constants.AUDIO_CLASSIFICATION) \
                    or task_type_str.endswith("/" + constants.TEXT_CLASSIFICATION):
                label_list.append(annotation.name)
            elif task_type_str.endswith("/" + constants.TEXT_ENTITY):
                annotation_property = annotation.annotation_property
                label_list.append(annotation.name
                                  + LABEL_SEPARATOR + str(annotation_property.get(PROPERTY_START_INDEX))
                                  + LABEL_SEPARATOR + str(annotation_property.get(PROPERTY_END_INDEX)))
            elif task_type_str.endswith("/" + constants.TEXT_TRIPLET):
                annotation_property = annotation.annotation_property
                label_list.append(annotation.name
                                  + LABEL_SEPARATOR + str(annotation.id)
                                  + LABEL_SEPARATOR + str(annotation_property.get(PROPERTY_FROM))
                                  + LABEL_SEPARATOR + str(annotation_property.get(PROPERTY_TO)))
            elif task_type_str.endswith("/" + constants.AUDIO_CONTENT) or task_type_str.endswith(
                    "/" + constants.AUDIO_SEGMENTATION):
                annotation_property = annotation.annotation_property
                label = annotation_property.get(PROPERTY_CONTENT)
                label_list.append(cls.__get_label(annotation_property, label))
            elif task_type_str.endswith("/" + constants.OBJECT_DETECTION) or task_type_str.endswith(
                    "/" + constants.AUDIO_SEGMENTATION):
                label_list.append(annotation.annotation_loc)
            else:
                raise Exception("Don't support the task type:" + task_type)
        return flag

    @classmethod
    def __get_label(cls, annotation_property, label):
        if label is not None:
            return label
        else:
            return str(annotation_property)

    @classmethod
    def get_not_exact_label_list(cls, annotation, flag, label_list, task_type, annotation_type):
        if str(annotation_type).endswith("/" + task_type):
            flag = True
            if (task_type == constants.IMAGE_CLASSIFICATION or task_type == constants.AUDIO_CLASSIFICATION
                    or task_type == constants.TEXT_CLASSIFICATION):
                label_list.append(annotation.name)
            elif task_type == constants.TEXT_ENTITY:
                annotation_property = annotation.annotation_property
                label_list.append(annotation.name
                                  + LABEL_SEPARATOR + str(annotation_property.get(PROPERTY_START_INDEX))
                                  + LABEL_SEPARATOR + str(annotation_property.get(PROPERTY_END_INDEX)))
            elif task_type == constants.TEXT_TRIPLET:
                annotation_property = annotation.annotation_property
                label_list.append(annotation.name
                                  + LABEL_SEPARATOR + str(annotation.id)
                                  + LABEL_SEPARATOR + str(annotation_property[PROPERTY_FROM])
                                  + LABEL_SEPARATOR + str(annotation_property[PROPERTY_TO]))
            elif task_type == constants.AUDIO_CONTENT or task_type == AUDIO_SEGMENTATION:
                annotation_property = annotation.annotation_property
                label = annotation_property.get(PROPERTY_CONTENT)
                label_list.append(cls.__get_label(annotation_property, label))
            elif task_type == constants.OBJECT_DETECTION or task_type == constants.IMAGE_SEGMENTATION:
                label_list.append(annotation.annotation_loc)
            else:
                raise Exception("Don't support the task type:" + task_type)
        return flag

    @classmethod
    def get_sources(self, manifest_path, source_type):
        sources = []
        data_set = self.parse_manifest(manifest_path)
        sample_list = data_set.samples
        for sample in sample_list:
            if str(source_type).lower() == str(sample.source_type).lower():
                sources.append(sample.source)
        return sources

    @classmethod
    def get_annotations(self, value):
        text = json.loads(value)
        return self.__get_annotations_internal(text)

    @classmethod
    def __get_annotations_internal(self, text):
        annotations = text.get(constants.ANNOTATION)
        annotations_list = []
        if annotations is not None:
            for annotation in annotations:
                annotation_type = annotation.get(constants.ANNOTATION_TYPE)
                annotation_name = annotation.get(constants.ANNOTATION_NAME)
                annotation_id = annotation.get(constants.ANNOTATION_ID)
                annotation_loc = annotation.get(constants.ANNOTATION_LOC) or annotation.get(constants.ANNOTATION_LOC2)
                annotation_loc_map = annotation.get(constants.ANNOTATION_LOC_MAP)
                annotation_creation_time = annotation.get(constants.ANNOTATION_CREATION_TIME) or annotation.get(
                    constants.ANNOTATION_CREATION_TIME2)
                annotation_property = annotation.get(constants.ANNOTATION_PROPERTY)
                annotation_format = annotation.get(constants.ANNOTATION_FORMAT) or annotation.get(
                    constants.ANNOTATION_FORMAT2)
                annotation_confidence = annotation.get(constants.ANNOTATION_CONFIDENCE)
                annotated_by = annotation.get(constants.ANNOTATION_ANNOTATED_BY) or annotation.get(
                    constants.ANNOTATION_ANNOTATED_BY2)
                annotation_hard = annotation.get(constants.ANNOTATION_HARD)
                annotation_hard_coefficient = annotation.get(constants.ANNOTATION_HARD_COEFFICIENT)
                annotations_list.append(
                    Annotation(name=annotation_name, type=annotation_type, id=annotation_id,
                               annotation_loc=annotation_loc,
                               annotation_property=annotation_property,
                               confidence=annotation_confidence,
                               creation_time=annotation_creation_time,
                               annotated_by=annotated_by, annotation_format=annotation_format,
                               hard=annotation_hard,
                               hard_coefficient=annotation_hard_coefficient,
                               annotation_loc_map=annotation_loc_map))
        return annotations_list

    @classmethod
    def __get_dataset(cls, lines):
        sample_list = []
        size = 0
        for line in lines:
            line = compat.as_str(line)
            if line != '':
                size = size + 1
                try:
                    text = json.loads(line)
                except Exception as e:
                    raise Exception("Failed to parse the json line {}, error is {}".format(line, e))
                source = text.get(constants.SOURCE)
                source_map = text.get(constants.SOURCE_MAP)
                if source is None:
                    raise ValueError
                usage = text.get(constants.USAGE)
                source_type = text.get(constants.SOURCE_TYPE)
                if source_type is None:
                    source_type = text.get(constants.SAMPLE_TYPE)
                source_property = text.get(constants.SOURCE_PROPERTY)
                id = text.get(constants.ID)
                inference_loc = text.get(constants.INFERENCE_LOC) or text.get(constants.INFERENCE_LOC2)
                sample_hard = text.get(constants.SAMPLE_HARD)
                sample_hard_reasons = text.get(constants.HARD_REASONS)
                sample_hard_coefficient = text.get(constants.SAMPLE_HARD_COEFFICIENT)
                annotations_list = cls.__get_annotations_internal(text)
                sample_list.append(
                    Sample(source=source, usage=usage, annotations=annotations_list, inference_loc=inference_loc, id=id,
                           source_type=source_type, source_property=source_property, source_map=source_map,
                           hard=sample_hard,
                           hard_reasons=sample_hard_reasons, hard_coefficient=sample_hard_coefficient))
        return Manifest(samples=sample_list, size=size)

    @classmethod
    def parse_manifest(cls, manifest_path, encoding='utf-8', session=None):
        """
        user give the path of manifest file, it will return the dataset,
        including data object list, annotation list and so on after the manifest was parsed.

        :param encoding: file encoding
        :param manifest_path:  path of manifest file
        :param session: Building interactions with Cloud service
        :return: data set of manifest
        """
        if is_local(manifest_path):
            with codecs.open(manifest_path, encoding=encoding) as f_obj:
                lines = f_obj.readlines()
                return cls.__get_dataset(lines)
        else:
            if session is None or session.obs_client is None:
                raise Exception("Session can not be empty when read file from OBS")
            data = read(manifest_path, session.obs_client)
            result = cls.__get_dataset(compat.as_text(data, encoding=encoding).split("\n"))
            return result
