from abc import ABCMeta, abstractmethod
from json import JSONEncoder

from six import with_metaclass

from modelarts import constant
from modelarts.dataset import dataset_constant
from modelarts.config.auth import auth_by_apig, auth_by_roma_api
from modelarts.util.secret_util import auth_expired_handler


class DatasetApiBase(with_metaclass(ABCMeta, object)):
    """
    A ModelArts Dataset that can create dataset, get dataset information and list,
    update dataset, delete dataset, publish dataset version, get dataset verion information and list,
    get structured dataset schema, batch read the specified version of structured dataset,
    import dataset and export dataset.
    """

    def __init__(self):
        """
        Initialize a ModelArts Dataset instance.
        """

    @abstractmethod
    def get_dataset_list(self, offset, limit, dataset_type):
        """get dataset list
        """
        pass

    @abstractmethod
    def create_dataset(self, create_dataset_body):
        """create structured dataset
        """
        pass

    @abstractmethod
    def update_dataset(self, dataset_id, update_dataset_body):
        """update structured dataset
        """
        pass

    @abstractmethod
    def delete_dataset(self, dataset_id):
        """delete dataset
        """
        pass

    @abstractmethod
    def get_dataset_info(self, dataset_id):
        """get dataset information
        """
        pass

    @abstractmethod
    def get_version_list(self, dataset_id):
        """get dataset version list
        """
        pass

    @abstractmethod
    def release_dataset_version(self, dataset_id, create_version_body):
        """create dataset version
        """
        pass

    @abstractmethod
    def get_version_info(self, dataset_id, version_id):
        """get dataset version information
        """
        pass

    @abstractmethod
    def create_reader(self, dataset_id, version_id):
        """create reader to get dataset version data
        """
        pass

    @abstractmethod
    def list_samples(self, dataset_id, version_id, preview):
        """list samples of datasets
        """
        pass

    @abstractmethod
    def get_schema(self, dataset_id):
        """get dataset schema
        """
        pass

    @abstractmethod
    def import_data(self, dataset_id, import_data_body):
        """import data to dataset
        """
        pass

    @abstractmethod
    def get_import_task_info(self, dataset_id, task_id):
        """query import task
        """
        pass

    @abstractmethod
    def export_data(self, dataset_id, export_data_body):
        """export data to target path
        """
        pass

    @abstractmethod
    def get_export_task_info(self, dataset_id, task_id):
        """query export task
        """
        pass


class DatasetApiAccountImpl(DatasetApiBase):
    """
    A ModelArts Dataset that can create dataset, get dataset information and list,
    update dataset, delete dataset, publish dataset version, get dataset verion information and list,
    get structured dataset schema, batch read the specified version of structured dataset,
    import dataset and export dataset.
    """

    def __init__(self, session):
        """
        TODO: Initialize a ModelArts Dataset instance when using Account auth.
        """
        DatasetApiBase.__init__(self)
        self.session = session
        self.dataset_api = None

    def get_dataset_list(self, offset, limit, dataset_type):
        """get dataset list
        """
        return self.dataset_api.get_dataset_list(self.session.project_id, offset, limit,
                                                 dataset_type)

    def create_dataset(self, create_dataset_body):
        """create structured dataset
        """
        return self.dataset_api.create_dataset(self.session.project_id, create_dataset_body)

    def update_dataset(self, dataset_id, update_dataset_body):
        """update structured dataset
        """
        return self.dataset_api.update_dataset(self.session.project_id, dataset_id,
                                               update_dataset_body)

    def delete_dataset(self, dataset_id):
        """delete dataset
        """
        return self.dataset_api.delete_dataset(self.session.project_id, dataset_id)

    def get_dataset_info(self, dataset_id):
        """get dataset information
        """
        return self.dataset_api.get_dataset(self.session.project_id, dataset_id)

    def get_version_list(self, dataset_id):
        """get dataset version list
        """
        return self.dataset_api.get_version_list(self.session.project_id, dataset_id)

    def release_dataset_version(self, dataset_id, create_version_body):
        """create dataset version
        """
        return self.dataset_api.create_dataset_version(self.session.project_id, dataset_id,
                                                       create_version_body)

    def get_version_info(self, dataset_id, version_id):
        """get dataset version information
        """
        return self.dataset_api.get_dataset_version(self.session.project_id, dataset_id, version_id)

    def create_reader(self, dataset_id, version_id):
        """create reader to get dataset data
        """
        return

    def list_samples(self, dataset_id, version_id, preview):
        """list samples of dataset
        """
        return self.dataset_api.list_samples(self.session.project_id, dataset_id, version_id,
                                             preview)

    def get_schema(self, dataset_id):
        """get dataset schema
        """
        dataset_info_resp = self.get_dataset_info(dataset_id)
        try:
            schema = dataset_info_resp['schema']
            return schema
        except Exception:
            raise Exception("The dataset with type {} does not have 'schema'".format(
                dataset_info_resp['dataset_type']))

    def import_data(self, dataset_id, import_data_body):
        """import data to dataset
        """
        return self.dataset_api.import_data(self.session.project_id, dataset_id, import_data_body)

    def get_import_task_info(self, dataset_id, task_id):
        """query import task
        """
        return self.dataset_api.get_import_task_info(self.session.project_id, dataset_id, task_id)

    def export_data(self, dataset_id, export_data_body):
        """export data to target path
        """
        return self.dataset_api.export_data(self.session.project_id, dataset_id, export_data_body)

    def get_export_task_info(self, dataset_id, task_id):
        """query export task
        """
        return self.dataset_api.get_export_task_info(self.session.project_id, dataset_id, task_id)


class DatasetApiAKSKImpl(DatasetApiBase):
    """
    A ModelArts Dataset that can create dataset, get dataset information and list,
    update dataset, delete dataset, publish dataset version, get dataset verion information and list,
    get structured dataset schema, batch read the specified version of structured dataset,
    import dataset and export dataset.
    """

    def __init__(self, session, headers=None):
        """
        Initialize a ModelArts Dataset instance when using AKSK auth.
        """
        DatasetApiBase.__init__(self)
        self.session = session
        self.headers = headers
        self.base_request_url = '/v2/' + self.session.project_id + '/datasets'

    @auth_expired_handler
    def get_dataset_list(self, offset, limit, dataset_type):
        """get dataset list.
        """
        request_url = self.base_request_url
        kwargs = {}
        if offset is not None:
            kwargs['offset'] = str(offset)
        if limit is not None:
            kwargs['limit'] = str(limit)
        if dataset_type is not None:
            kwargs['dataset_type'] = str(dataset_type)
        return auth_by_apig(self.session,
                            constant.HTTPS_GET,
                            request_url, query=kwargs,
                            headers=self.headers)

    @auth_expired_handler
    def list_datasets(self, dataset_name=None, **kwargs):
        request_url = self.base_request_url
        query_args = {}
        for key, value in kwargs.items():
            if value is not None:
                query_args[key] = str(value)
        if dataset_name is not None:
            query_args['search_content'] = str(dataset_name)
        dataset_version = kwargs.get('dataset_version')
        query_args['dataset_version'] = "all" if dataset_version is None else str(kwargs.get('dataset_version'))
        return auth_by_apig(self.session,
                            constant.HTTPS_GET,
                            request_url, query=query_args,
                            headers=self.headers)

    @auth_expired_handler
    def create_dataset(self, create_dataset_body):
        """ create dataset.
        :param create_dataset_body: request body of creating dataset
        :return: response of creating dataset, including dataset id
        """
        request_url = self.base_request_url
        create_dataset_body = JSONEncoder().encode(create_dataset_body)
        return auth_by_apig(self.session,
                            constant.HTTPS_POST,
                            request_url, body=create_dataset_body,
                            headers=self.headers)

    @auth_expired_handler
    def update_dataset(self, dataset_id, update_dataset_body):
        """ update dataset
        :param dataset_id: dataset id
        :param update_dataset_body: request body of updating dataset
        :return: response of updating dataset, including dataset id
        """
        request_url = self.base_request_url + '/' + dataset_id
        update_dataset_body = JSONEncoder().encode(update_dataset_body)
        return auth_by_apig(self.session,
                            constant.HTTPS_PUT, request_url, '',
                            body=update_dataset_body,
                            headers=self.headers)

    @auth_expired_handler
    def delete_dataset(self, dataset_id):
        """delete dataset
        :param dataset_id: dataset id
        :return: response of deleting dataset, which is empty
        """
        request_url = self.base_request_url + '/' + dataset_id
        return auth_by_apig(self.session,
                            constant.HTTPS_DELETE, request_url,
                            headers=self.headers)

    @auth_expired_handler
    def get_dataset_info(self, dataset_id):
        """get dataset information
        :param dataset_id: dataset id
        :return: dataset information
        """
        request_url = self.base_request_url + '/' + dataset_id
        return auth_by_apig(self.session,
                            constant.HTTPS_GET, request_url,
                            headers=self.headers)

    @auth_expired_handler
    def get_version_list(self, dataset_id):
        """get dataset version list
        :param dataset_id: dataset id
        :return: dataset version list
        """
        request_url = self.base_request_url + '/' + dataset_id + '/versions'
        return auth_by_apig(self.session,
                            constant.HTTPS_GET, request_url,
                            headers=self.headers)

    @auth_expired_handler
    def release_dataset_version(self, dataset_id, create_version_body):
        """ create dataset version
        :param dataset_id: dataset id
        :param create_version_body: request body of creating dataset version
        :return: response of creating dataset version, including version id
        """
        request_url = self.base_request_url + '/' + dataset_id + '/versions'
        create_version_body = JSONEncoder().encode(create_version_body)
        return auth_by_apig(self.session,
                            constant.HTTPS_POST, request_url,
                            body=create_version_body,
                            headers=self.headers)

    @auth_expired_handler
    def get_version_info(self, dataset_id, version_id):
        """get dataset version information
        :param dataset_id: dataset id
        :param version_id: version id
        :return: dataset version information
        """
        request_url = self.base_request_url + '/' + dataset_id + '/versions/' + version_id
        return auth_by_apig(self.session,
                            constant.HTTPS_GET, request_url,
                            headers=self.headers)

    @auth_expired_handler
    def delete_version(self, dataset_id, version_id):
        """delete dataset version
        :param dataset_id:dataset id
        :param version_id:version id
        :return: None
        """
        request_url = self.base_request_url + '/' + dataset_id + '/versions/' + version_id
        return auth_by_apig(self.session, constant.HTTPS_DELETE, request_url,
                            headers=self.headers)

    @auth_expired_handler
    def create_reader(self, dataset_id, version_id):
        """create reader to get dataset data
        """
        return

    @auth_expired_handler
    def list_samples(self, dataset_id, version_id, **kwargs):
        """list samples of structured dataset
        :param dataset_id: dataset id
        :param version_id: version id
        :param kwargs: Optional arguments,like
        - preview: valid for structured dataset, default to true
        :return: rows of structured dataset
        """
        request_url = self.base_request_url + '/' + dataset_id + '/data-annotations/samples'
        query_args = {}
        if version_id is not None:
            query_args['version_id'] = str(version_id)
        preview = kwargs.get("preview")
        if preview is not None:
            preview_value = 'true' if preview else 'false'
            query_args['preview'] = str(preview_value)
        if kwargs.get("offset") is not None:
            query_args['offset'] = str(kwargs.get("offset"))
        if kwargs.get("limit") is not None:
            query_args['limit'] = str(kwargs.get("limit"))
        return auth_by_apig(self.session,
                            constant.HTTPS_GET, request_url, query=query_args,
                            headers=self.headers)

    @auth_expired_handler
    def get_sample_info(self, dataset_id, sample_id):
        """get dataset information
        :param dataset_id: dataset id
        :return: dataset information
        """
        request_url = self.base_request_url + '/' + dataset_id + '/data-annotations/samples/' + sample_id
        return auth_by_apig(self.session,
                            constant.HTTPS_GET, request_url,
                            headers=self.headers)

    @auth_expired_handler
    def upload_samples(self, dataset_id, upload_samples_body):
        """ upload samples from local
        :param dataset_id: dataset id
        :param upload_samples_body: list for upload data
        """
        request_url = self.base_request_url + '/' + dataset_id + '/data-annotations/samples'
        request_body = JSONEncoder().encode(upload_samples_body)
        return auth_by_apig(self.session,
                            constant.HTTPS_POST, request_url, body=request_body,
                            headers=self.headers)

    @auth_expired_handler
    def delete_samples(self, dataset_id, delete_samples_body):
        """delete dataset samples by sample_id
        :param dataset_id: dataset id
        :param samples: list of sample_id
        :return: list of sample_is that failed to delete
        """
        request_url = self.base_request_url + '/' + dataset_id + '/data-annotations/samples/delete'
        request_body = JSONEncoder().encode(delete_samples_body)
        return auth_by_apig(self.session, constant.HTTPS_POST, request_url,
                            body=request_body, headers=self.headers)

    @auth_expired_handler
    def get_schema(self, dataset_id):
        """get dataset schema
        :param dataset_id: dataset id
        :return: structured dataset schema
        """
        dataset_info_resp = self.get_dataset_info(dataset_id)
        try:
            schema = dataset_info_resp['schema']
            return schema
        except Exception:
            raise Exception("The dataset with type {} does not have 'schema'".format(
                dataset_info_resp['dataset_type']))

    @auth_expired_handler
    def list_import_tasks(self, dataset_id, **kwargs):
        """list dataset import tasks
        """
        request_url = self.base_request_url + '/' + dataset_id + '/import-tasks'
        query_args = {}
        if kwargs.get("offset") is not None:
            query_args['offset'] = str(kwargs.get("offset"))
        if kwargs.get("limit") is not None:
            query_args['limit'] = str(kwargs.get("limit"))
        return auth_by_apig(self.session,
                            constant.HTTPS_GET, request_url, query=query_args,
                            headers=self.headers)

    @auth_expired_handler
    def import_data(self, dataset_id, import_data_body):
        """import data to dataset
        :param dataset_id: dataset id
        :param import_data_body: request body of importing dataset
        :return: response of importing dataset, including import task id
        """
        request_url = self.base_request_url + '/' + dataset_id + '/import-tasks'
        import_data_body = JSONEncoder().encode(import_data_body)
        return auth_by_apig(self.session,
                            constant.HTTPS_POST, request_url,
                            body=import_data_body,
                            headers=self.headers)

    @auth_expired_handler
    def get_import_task_info(self, dataset_id, task_id):
        """query import task
        :param dataset_id: dataset id
        :param task_id: import task id
        :return: import task information
        """
        request_url = self.base_request_url + '/' + dataset_id + '/import-tasks/' + task_id
        return auth_by_apig(self.session,
                            constant.HTTPS_GET, request_url,
                            headers=self.headers)

    @auth_expired_handler
    def list_export_tasks(self, dataset_id, **kwargs):
        """list dataset import tasks
        """
        request_url = self.base_request_url + '/' + dataset_id + '/export-tasks'
        query_args = {}
        if kwargs.get("offset") is not None:
            query_args['offset'] = str(kwargs.get("offset"))
        if kwargs.get("limit") is not None:
            query_args['limit'] = str(kwargs.get("limit"))
        return auth_by_apig(self.session,
                            constant.HTTPS_GET, request_url, query=query_args,
                            headers=self.headers)

    @auth_expired_handler
    def export_data(self, dataset_id, export_data_body):
        """export data to target path
        """
        request_url = self.base_request_url + '/' + dataset_id + '/export-tasks'
        export_data_body = JSONEncoder().encode(export_data_body)
        return auth_by_apig(self.session,
                            constant.HTTPS_POST, request_url,
                            body=export_data_body,
                            headers=self.headers)

    @auth_expired_handler
    def get_export_task_info(self, dataset_id, task_id):
        """query export task
        """
        request_url = self.base_request_url + '/' + dataset_id + '/export-tasks/' + task_id
        return auth_by_apig(self.session,
                            constant.HTTPS_GET, request_url,
                            headers=self.headers)

    @auth_expired_handler
    def list_label_tasks(self, dataset_id=None, **kwargs):
        if dataset_id is None:
            task_type = kwargs.get(dataset_constant.TASK_TYPE)
            check_running_task = kwargs.get(dataset_constant.CHECK_RUNNING_TASK)
            offset = kwargs.get(dataset_constant.OFFSET)
            limit = kwargs.get(dataset_constant.LIMIT)
            request_url, query_args = self.__build_all_label_task_request(task_type=task_type,
                                                                          check_running_task=check_running_task,
                                                                          offset=offset, limit=limit)
        else:
            request_url, query_args = self.__build_dataset_label_task_request(dataset_id=dataset_id, **kwargs)
        return auth_by_apig(self.session,
                            constant.HTTPS_GET, request_url, query=query_args,
                            headers=self.headers)

    def __build_all_label_task_request(self, task_type=None, check_running_task=None, offset=None, limit=None):
        request_url = '/v2/' + self.session.project_id + dataset_constant.URI_LABEL_TASK
        query_args = {}
        if task_type is not None:
            query_args[dataset_constant.TASK_TYPE] = str(task_type)
        if check_running_task is not None:
            query_args[dataset_constant.CHECK_RUNNING_TASK] = str(check_running_task)
        if offset is not None:
            query_args[dataset_constant.OFFSET] = str(offset)
        if limit is not None:
            query_args[dataset_constant.LIMIT] = str(limit)

        return request_url, query_args

    def __build_dataset_label_task_request(self, dataset_id=None, **kwargs):
        request_url = self.base_request_url + "/" + dataset_id + dataset_constant.URI_LABEL_TASK
        query_args = {}
        if kwargs.get(dataset_constant.IS_WORKFORCE_TASK) is not None:
            query_args[dataset_constant.IS_WORKFORCE_TASK] = str(kwargs.get(dataset_constant.IS_WORKFORCE_TASK))

        if kwargs.get(dataset_constant.SORT_KEY) and kwargs.get(dataset_constant.SORT_DIR):
            query_args[dataset_constant.SORT_KEY] = kwargs.get(dataset_constant.SORT_KEY)
            query_args[dataset_constant.SORT_DIR] = kwargs.get(dataset_constant.SORT_DIR)

        return request_url, query_args

    @auth_expired_handler
    def create_label_task(self, dataset_id, create_label_task_body):
        request_url = self.base_request_url + "/" + dataset_id + dataset_constant.URI_LABEL_TASK
        create_label_task_body = JSONEncoder().encode(create_label_task_body)
        return auth_by_apig(self.session,
                            constant.HTTPS_POST,
                            request_url, body=create_label_task_body,
                            headers=self.headers)

    @auth_expired_handler
    def get_label_task_info(self, dataset_id, task_id):
        """get label-task info
        """
        request_url = self.base_request_url + "/" + dataset_id + "/label-tasks/" + task_id
        return auth_by_apig(self.session,
                            constant.HTTPS_GET, request_url,
                            headers=self.headers)

    @auth_expired_handler
    def delete_label_task(self, dataset_id, task_id):
        request_url = self.base_request_url + "/" + dataset_id + "/label-tasks/" + task_id
        return auth_by_apig(self.session,
                            constant.HTTPS_DELETE, request_url,
                            headers=self.headers)


class DatasetApiROMAImpl(DatasetApiBase):
    """
    A ModelArts Dataset that can create dataset, get dataset information and list,
    update dataset, delete dataset, publish dataset version, get dataset verion information and list,
    get structured dataset schema, batch read the specified version of structured dataset,
    import dataset and export dataset.
    """

    def __init__(self, session):
        """
        initialize a modelarts dataset instance when using roma auth.
        """
        DatasetApiBase.__init__(self)
        self.session = session
        self.base_request_url = self.session.host + '/v2/' + self.session.project_id + '/datasets'

    def get_dataset_list(self, offset, limit, dataset_type):
        """get dataset list
        """
        request_url = self.base_request_url
        return auth_by_roma_api(session=self.session, request_url=request_url,
                                request_type=constant.HTTPS_GET,
                                intf_action="get_dataset_list")

    def create_dataset(self, create_dataset_body):
        """create structured dataset
        """
        request_url = self.base_request_url
        create_dataset_body = JSONEncoder().encode(create_dataset_body)
        return auth_by_roma_api(session=self.session, request_url=request_url,
                                request_type=constant.HTTPS_POST,
                                intf_action="create_dataset",
                                data=create_dataset_body)

    def update_dataset(self, dataset_id, update_dataset_body):
        """update structured dataset
        """
        request_url = self.base_request_url + '/' + dataset_id
        update_dataset_body = JSONEncoder().encode(update_dataset_body)
        return auth_by_roma_api(session=self.session, request_url=request_url,
                                request_type=constant.HTTPS_PUT,
                                intf_action="update_dataset",
                                data=update_dataset_body)

    def delete_dataset(self, dataset_id):
        """delete dataset
        """
        request_url = self.base_request_url + '/' + dataset_id
        return auth_by_roma_api(session=self.session, request_url=request_url,
                                request_type=constant.HTTPS_DELETE,
                                intf_action="delete_dataset")

    def get_dataset_info(self, dataset_id):
        """get dataset information
        """
        request_url = self.base_request_url + '/' + dataset_id
        return auth_by_roma_api(session=self.session, request_url=request_url,
                                request_type=constant.HTTPS_GET,
                                intf_action="get_dataset_info")

    def get_version_list(self, dataset_id):
        """get dataset version list
        """
        request_url = self.base_request_url + '/' + dataset_id + '/versions'
        return auth_by_roma_api(session=self.session, request_url=request_url,
                                request_type=constant.HTTPS_GET,
                                intf_action="get_version_list")

    def release_dataset_version(self, dataset_id, create_version_body):
        """create dataset version
        """
        request_url = self.base_request_url + '/' + dataset_id + '/versions'
        create_version_body = JSONEncoder().encode(create_version_body)
        return auth_by_roma_api(session=self.session, request_url=request_url,
                                request_type=constant.HTTPS_POST,
                                intf_action="release_dataset_version",
                                data=create_version_body)

    def get_version_info(self, dataset_id, version_id):
        """get dataset version information
        """
        request_url = self.base_request_url + '/' + dataset_id + '/versions/' + version_id
        return auth_by_roma_api(session=self.session, request_url=request_url,
                                request_type=constant.HTTPS_GET,
                                intf_action="get_version_info")

    def create_reader(self, dataset_id, version_id):
        """create reader to get dataset data
        """
        return

    def list_samples(self, dataset_id, version_id, preview):
        """list samples of dataset
        """
        request_url = self.base_request_url + '/' + dataset_id + '/data-annotations/samples'
        return auth_by_roma_api(session=self.session, request_url=request_url,
                                request_type=constant.HTTPS_GET,
                                intf_action="list_samples")

    def get_schema(self, dataset_id):
        """get dataset schema
        """
        dataset_info_resp = self.get_dataset_info(dataset_id)
        try:
            schema = dataset_info_resp['schema']
            return schema
        except Exception:
            raise Exception("The dataset with type {} does not have 'schema'".format(
                dataset_info_resp['dataset_type']))

    def import_data(self, dataset_id, import_data_body):
        """import data to dataset
        """
        request_url = self.base_request_url + '/' + dataset_id + '/import-tasks'
        import_data_body = JSONEncoder().encode(import_data_body)
        return auth_by_roma_api(session=self.session, request_url=request_url,
                                request_type=constant.HTTPS_POST,
                                intf_action="import_data",
                                data=import_data_body)

    def get_import_task_info(self, dataset_id, task_id):
        """query import task
        """
        request_url = self.base_request_url + '/' + dataset_id + '/import-tasks/' + task_id
        return auth_by_roma_api(session=self.session, request_url=request_url,
                                request_type=constant.HTTPS_GET,
                                intf_action="get_import_task_info")

    def export_data(self, dataset_id, export_data_body):
        """export data to target path
        """
        request_url = self.base_request_url + '/' + dataset_id + '/export-tasks'
        export_data_body = JSONEncoder().encode(export_data_body)
        return auth_by_roma_api(session=self.session, request_url=request_url,
                                request_type=constant.HTTPS_POST,
                                intf_action="export_data",
                                data=export_data_body)

    def get_export_task_info(self, dataset_id, task_id):
        """query export task
        """
        request_url = self.base_request_url + '/' + dataset_id + '/export-tasks/' + task_id
        return auth_by_roma_api(session=self.session, request_url=request_url,
                                request_type=constant.HTTPS_GET,
                                intf_action="get_export_task_info")


class ManagedStorage(object):

    def __init__(self, managed=True, work_path=None, work_path_type=None):
        """
        Storage information of creating dataset
        """
        self.managed = managed if managed is False else True
        self.work_path_type = "0" if not work_path_type else work_path_type
        if not work_path:
            raise ValueError('The work_path is required in ManagedStorage.')
        self.work_path = work_path
