""""
Authorize AKSK API and ROMA API
"""
import hashlib
import hmac
import json
import logging
import sys
import platform

if sys.version_info.major < 3:
    from urllib import quote
else:
    from urllib.parse import quote

import requests
from huaweicloudsdkcore.signer import signer
from huaweicloudsdkcore.sdk_request import SdkRequest
from huaweicloudsdkcore.auth.credentials import BasicCredentials

from modelarts import constant
from modelarts.util.notebook_util import collect_env
from ..exception.apig_exception import APIGException
from ..exception.iam_exception import IAMException
from ..exception.roma_exception import RomaException

logging.basicConfig()
LOGGER = logging.getLogger('modelarts-sdk')
TIMEOUT = int(constant.REQUEST_TIME_OUT)
SYSTEM = f"{platform.system()}_{platform.machine()}"  # "Linux_x86_64"


def gen_user_agent():
    if sys.version_info >= (3, 8):
        from importlib import metadata
        from importlib.metadata import PackageNotFoundError
    else:
        from importlib_metadata import PackageNotFoundError
        import importlib_metadata as metadata
    try:
        version = metadata.version("modelarts")
    except PackageNotFoundError:
        version = "unknown"
    return f"ModelArts-SDK-{version}/{SYSTEM}/{collect_env()}"


def get_temporary_aksk_without_agency(token, iam_url):
    """get IAM's temporary AK/SK without agency which lasts for 24h
       :return: {
                "credential": {
                    "access": "0HCKAXX*********QUP9GE",
                    "expires_at": "2019-08-03T01:22:55.858000Z",
                    "securitytoken": "xxxxxxxxxxxxxx"
                    "secret": "yyyyyyyyyyyyy"
                    }
                }
    """
    body = {
        "auth": {
            "identity": {
                "methods": [
                    "token"
                ],
                "token": {
                    "duration-seconds": "86400"
                }
            }
        }
    }
    headers = {
        "X-Auth-Token": token,
        "Content-Type": "application/json"
    }
    headers.update({"User-Agent": gen_user_agent()})
    url = "https://" + iam_url + "/v3.0/OS-CREDENTIAL/securitytokens"
    try:
        response = requests.post(url, headers=headers, data=json.dumps(body),
                                 verify=False)
        if response.status_code > 300:
            resp = response.json()['error']
            message = "[ {} ] {}".format(resp['code'], resp['message'])
            raise IAMException(code=response.status_code, message=message)
        else:
            return response
    except IAMException:
        raise IAMException(code=response.status_code, message=message)
    except Exception as e:
        raise Exception(e)


def sign(key, msg):
    return hmac.new(key, msg.encode("utf-8"), hashlib.sha256).digest()


def get_signature_key(key, date_stamp, region_name, service_name):
    kDate = sign(('HWS' + key).encode('utf-8'), date_stamp)
    kRegion = sign(kDate, region_name)
    kService = sign(kRegion, service_name)
    kSigning = sign(kService, 'hws_request')
    return kSigning


def authorize_by_token(username, password, account, project_name, endpoint):
    """
    Set auth information to client configure
    """
    if not check_auth_validity(username):
        raise Exception("please input valid username")
    if not check_auth_validity(password):
        raise Exception("please input valid password")
    if account is None and username is not None:
        account = username

    body = {
        "auth": {
            "identity": {
                "methods": ["password"],
                "password": {
                    "user": {
                        "name": username,
                        "password": password,
                        "domain": {"name": account}
                    }
                }
            },
            "scope": {
                "project": {
                    "name": project_name
                }
            }
        }
    }
    headers = {
        "Content-Type": "application/json"
    }
    headers.update({"User-Agent": gen_user_agent()})
    url = "https://" + endpoint + "/v3/auth/tokens"
    try:
        response = requests.post(url, headers=headers, data=json.dumps(body),
                                 verify=False)
        if response.status_code > 300:
            resp = response.json()['error']
            message = "[ {} ] {}".format(resp['code'], resp['message'])
            raise IAMException(code=response.status_code, message=message)
        else:
            token = response.headers['X-Subject-Token']
            project_id = response.json()['token']['project']['id']
            return token, project_id
    except IAMException:
        raise IAMException(code=response.status_code, message=message)
    except Exception as e:
        raise Exception(e)


def get_token_by_ak_sk(access_key, secret_access_key, region_name, iam_endpoint):
    url = iam_endpoint + "/v3/auth/tokens"
    body = {
        "auth": {
            "identity": {
                "methods": [
                    "hw_ak_sk"
                ],
                "hw_ak_sk": {
                    "access": {
                        "key": access_key
                    },
                    "secret": {
                        "key": secret_access_key
                    }
                }
            },
            "scope": {
                "project": {
                    "name": region_name
                }
            }
        }
    }
    response = requests.post(url, data=json.dumps(body), timeout=10,
                             verify=False)
    if response.status_code > 300:
        raise IAMException(code=response.status_code, message=response.content)
    return response.headers["X-Subject-Token"]


def auth_by_roma_api(session, request_url, request_type, intf_action,
                     data=None, params=None):
    """ Call roma modelarts interface, get response
    :param session: session
    :param request_url: request url
    :param request_type: POST/GET
    :param data: body parameter
    :param params: index parameter
    :param intf_action: interface action, such as get_service_info, get_service_list
    :return: roma response
    """
    headers = session.headers.copy()
    headers.update({"User-Agent": gen_user_agent()})
    try:
        if request_type == constant.HTTPS_POST:
            response = requests.post(request_url, headers=headers,
                                     data=data, verify=False, timeout=TIMEOUT)
        elif request_type == constant.HTTPS_GET and params is None:
            response = requests.get(request_url, headers=headers,
                                    verify=False, timeout=TIMEOUT)
        elif request_type == constant.HTTPS_GET and params is not None:
            response = requests.get(request_url, headers=headers,
                                    params=params, verify=False, timeout=TIMEOUT)
        elif request_type == constant.HTTPS_DELETE:
            response = requests.delete(request_url, headers=headers,
                                       verify=False, timeout=TIMEOUT)
        elif request_type == constant.HTTPS_PUT:
            response = requests.put(request_url, headers=headers,
                                    data=data, verify=False, timeout=TIMEOUT)
        else:
            raise Exception("no such https request %s." % request_type)

        if response.status_code >= 400:
            raise RomaException(code=response.status_code,
                                message=response.content)
        return json.loads(response.content)

    except Exception as e:
        raise Exception(intf_action + " failed, %s." % e)


def parse_req_query(req_query):
    """
    Parses request query dict to the URL format.
    :param query: request index parameter
    :return: query string
    """
    req_query_sortd = sorted(req_query)
    query_string_arr = []
    for query_key in req_query_sortd:
        query_value = req_query[query_key]
        query_kv = f"{quote(query_key)}={quote(query_value)}"
        query_string_arr.append(query_kv)
    return '&'.join(query_string_arr)


def auth_by_roma_estimatorv2_api(session, req_method, request_url,
                                 query=None, body=None):
    """
    Call modelarts estimator v2 api with roma auth, get response content
    :param session: session
    :param req_method: POST/GET/PUT/DELETE
    :param request_url: request url
    :param query: index parameter
    :param body: body parameter
    :param headers: request headers
    :return: estimator v2 api response content dict
    """
    request_url = session.host + request_url
    if query:
        query_string = parse_req_query(query)
        if query_string:
            request_url = request_url + '?' + query_string

    headers = session.headers.copy()
    if "X-Project-Id" not in headers.keys() and session.project_id:
        headers["X-Project-Id"] = session.project_id
    headers.update({"User-Agent": gen_user_agent()})
    if body:
        resp = requests.request(req_method, request_url, headers=headers,
                                data=body, timeout=TIMEOUT, verify=False)
    else:
        resp = requests.request(req_method, request_url,
                                headers=headers, timeout=TIMEOUT, verify=False)

    if resp.status_code > 300:
        raise RomaException(
            code=resp.status_code, message=resp.reason, content=resp.content)
    return json.loads(resp.content) if len(resp.content) > 0 else None


def auth_by_apig(session, method, request_url, query=None, body=None, headers=None, host=None):
    # Use Permanent AK&SK
    crediental = BasicCredentials(session.access_key, session.secret_key, session.project_id)
    # Use Permanent AK&SK
    if session.security_token:
        crediental = crediental.with_security_token(session.security_token)
    sig = signer.Signer(crediental)
    r = check_request(session, query, method, request_url, headers, body, host)

    sig.sign(r)
    if body:
        resp = requests.request(r.method, r.schema + "://" + r.host + r.uri,
                                headers=r.header_params, data=r.body, timeout=TIMEOUT,
                                verify=False)
    else:
        resp = requests.request(r.method, r.schema + "://" + r.host + r.uri,
                                headers=r.header_params, timeout=TIMEOUT, verify=False)
    if resp.status_code > 300:
        raise APIGException(code=resp.status_code, message=resp.reason, content=resp.content)
    return json.loads(resp.content) if len(resp.content) > 0 else None


def check_request(session, query, method, request_url, headers=None, body=None, host=None):
    request = SdkRequest(schema="https",
                         host=session.host,
                         method=method,
                         resource_path=request_url,
                         query_params=[],
                         body="")
    if query:
        # Query params should be a list whose element is a tuple
        for kv in query.items():
            request.query_params.append(kv)

    request.header_params = {"Content-Type": "application/json"}
    if headers:
        request.header_params = headers

    if session.user_id and "x-modelarts-user-id" not in request.header_params.keys():
        request.header_params["x-modelarts-user-id"] = session.user_id
    if session.security_token and "x-security-token" not in request.header_params.keys():
        request.header_params["x-security-token"] = session.security_token
    if "X-Project-Id" not in request.header_params.keys() and session.project_id is not None:
        request.header_params["X-Project-Id"] = session.project_id
    request.header_params.update({"User-Agent": gen_user_agent()})
    if body:
        request.body = body

    if host:
        request.host = host

    return request


def check_auth_validity(authinfo):
    """ check auth information validity
    :param authinfo: check auth information validity
    :return: False or True
    """
    if authinfo is None or authinfo == "":
        return False
    return True
