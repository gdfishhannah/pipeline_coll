import logging


def ignore_warning(exception):
    return exception


try:
    from ma_cau.apis import DetDataBlock, COCOConverter, EnvManager, Learner, Model, VisDetPlatform

    ignore_warning([DetDataBlock,
                    COCOConverter,
                    EnvManager,
                    Learner,
                    Model,
                    VisDetPlatform]
                   )
except ImportError as e:
    info = "The requirements of algo_kit have not been supported yet, this feature is currently unavailable."
    logging.error(info)
    raise ValueError(info) from e
