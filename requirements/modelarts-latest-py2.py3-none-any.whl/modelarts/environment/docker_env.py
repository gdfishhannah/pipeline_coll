"""Classes for docker environment and image management."""
import os


class ImageRegistry(object):
    """
    An object used to register a docker image.
    """

    def __init__(self):
        """
        Initialize a docker image.
        """
        super(ImageRegistry, self).__init__()

        self.address = None
        self.username = None
        self.password = None

    @staticmethod
    def deserialize_from_dict(serialized_dict):
        """
        Generate an image registry object from a serialized dictionary.
        :param serialized_dict: a dictionary.
        :return an image instance.
        """
        ir = ImageRegistry()
        ir.address = serialized_dict.get("address")
        ir.username = serialized_dict.get("username")
        ir.password = serialized_dict.get("password")
        return ir

    @staticmethod
    def serialize_to_dict(image_registry):
        """
        Serialize a docker image into a dictionary.
        :param image_registry: a docker image
        :return a image registry object
        """
        ret = {}
        if image_registry.address:
            ret["address"] = image_registry.address
        if image_registry.username:
            ret["username"] = image_registry.username
        if image_registry.password:
            ret["password"] = image_registry.password
        return ret


class DockerEnv(object):
    """
    A docker environment object
    """

    def __init__(self, **kwargs):
        """
        Initialize a docker environment.
        :param kwargs: Create environment body params
        """
        super(DockerEnv, self).__init__()

        self._base_image = None
        self.base_image_registry = ImageRegistry()
        self._dockerfile = None
        # When the Docker image is pushed into SWR, the image URL should be
        # record as image_name
        self._image_name = None
        # packages records the specific conda/pip packages installed in the
        # docke image, backfilled after the image built.
        self._packages = {}

    @staticmethod
    def deserialize_from_dict(serialized_dict):
        """
        Generate a docker environment object from a serialized dictionary.
        :param serialized_dict: a serialized dictionary.
        :param a docker environment object.
        """
        docker = DockerEnv()
        if serialized_dict.get("base_image"):
            docker.base_image = serialized_dict.get("base_image")
        if serialized_dict.get("image_name"):
            docker.image_name = serialized_dict.get("image_name")
        if serialized_dict.get("dockerfile"):
            docker.dockerfile = serialized_dict.get("dockerfile")
        if serialized_dict.get("base_image_registry"):
            ir = ImageRegistry.deserialize_from_dict(
                serialized_dict.get("base_image_registry"))
            docker.base_image_registry = ir
        if serialized_dict.get("packages"):
            docker.packages = serialized_dict.get("packages")
        return docker

    @staticmethod
    def serialize_to_dict(docker_env):
        """
        Serialize a docker environment to a dictionary.
        :param docker_env: a docker environment.
        :return a dictionary.
        """
        ret = {}
        if docker_env.base_image:
            ret["base_image"] = docker_env.base_image
        if docker_env.image_name:
            ret["image_name"] = docker_env.image_name
        if docker_env.dockerfile:
            ret["dockerfile"] = docker_env.dockerfile
        if docker_env.base_image_registry:
            ir_dict = ImageRegistry.serialize_to_dict(
                docker_env.base_image_registry)
            if ir_dict:
                ret["base_image_registry"] = ir_dict
        if docker_env.packages:
            ret["packages"] = docker_env.packages
        return ret

    @property
    def packages(self):
        return self._packages

    @packages.setter
    def packages(self, packages={}):
        self._packages = {}
        if packages:
            self._packages = packages

    @property
    def image_name(self):
        return self._image_name

    @image_name.setter
    def image_name(self, image_name=None):
        self._image_name = None
        if image_name:
            self._image_name = image_name

    @property
    def base_image(self):
        return self._base_image

    @base_image.setter
    def base_image(self, image_name=None):
        self._base_image = None
        if image_name:
            self._base_image = image_name

    @property
    def dockerfile(self):
        return self._dockerfile

    @dockerfile.setter
    def dockerfile(self, filepath_or_str=None):
        """
        Read a docker file
        :param filepath_or_path: a filepath or a string pointing to a docker
        """
        if not filepath_or_str:
            self._dockerfile = None
            return

        self._dockerfile = filepath_or_str
        if os.path.isfile(filepath_or_str):
            with open(filepath_or_str) as f:
                self._dockerfile = f.read()
