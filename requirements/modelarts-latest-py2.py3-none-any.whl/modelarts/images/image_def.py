"""
Description: Cloud image definition
Author: ModelArts SDK Team
Date: 2021/11/01 - 2021/11/30
"""
import logging
import os
import shutil
from enum import Enum

from ..util.docker_util import DockerCli
from ..util import notebook_util

root_logger = logging.getLogger()
for h in root_logger.handlers:
    root_logger.removeHandler(h)
logging.basicConfig(level=logging.INFO, format='')


class ImageType(Enum):
    BUILDIN = "BUILD_IN"
    USERDEFINED = "DEDICATED"
    ALL = "ALL"

    @staticmethod
    def list():
        return [x.value for x in ImageType]


class ImageVisibility(Enum):
    PUBLIC = "PUBLIC"
    PRIVATE = "PRIVATE"

    @staticmethod
    def list():
        return [x.value for x in ImageVisibility]


class ImageArch(Enum):
    X86_64 = "X86_64"
    AARCH64 = "AARCH64"

    @staticmethod
    def list():
        return [x.value for x in ImageArch]


class ModelArtsService(Enum):
    NOTEBOOK = "NOTEBOOK"
    MODELBOX = "MODELBOX"

    @staticmethod
    def list():
        return [x.value for x in ModelArtsService]


class ResourceCategory(Enum):
    CPU = "CPU"
    GPU = "GPU"
    ASCEND = "ASCEND"

    @staticmethod
    def list():
        return [x.value for x in ResourceCategory]


class ImageQueryParams(Enum):
    NAME = "name"
    TYPE = "type"
    WORKSPACE_ID = "workspace_id"
    SORT_DIR = "sort_dir"
    SORT_KEY = "sort_key"
    OFFSET = "offset"
    LIMIT = "limit"

    @staticmethod
    def list():
        return [x.value for x in ImageQueryParams]


class Image(object):
    """
    This class includes the attributes of querying image api.
    """

    SWR_PATH_MIN_LENGTH = 16
    SWR_PATH_MAX_LENGTH = 2048
    MAX_DESCRIPTION_LENGTH = 512
    NOTEBOOK_IMAGE_ARCH_TO_DOCKER_ARCH = {"x86_64": "amd64", "aarch64": "arm64"}
    DOCKER_ARCH_TO_NOTEBOOK_IMAGE_ARCH = {"amd64": "x86_64", "arm64": "aarch64"}

    def __init__(self,
                 swr_path,
                 arch="",
                 description="",
                 service=[],
                 resource_category=[],
                 workspace_id="",
                 visibility=""):
        """Initialize an instance of class Image.
        :param swr_path:
        :param arch: the architecture of an image, including "X86_64" and "AARCH64"
        :param description: some specific information of this image
        :param service: "MODELBOX" or "NOTEBOOK"
        :param resource_category: {"CPU", "GPU", "ASCEND"}
        :param workspace_id: default to "0"
        :param visibility: private, public
        """
        swr_path = Image._check_parameters(swr_path, arch, description, service,
                                           resource_category, workspace_id, visibility)
        self.__arch = arch  # arm or x86
        self.__description = description
        self.__dev_services = service  # "MODELBOX" or "NOTEBOOK"
        self.__feature = None  # notebook or codelab
        self.__id = None
        self.__name = None  # should be same with swr_path
        self.__resource_category = resource_category  # {"CPU", "GPU", "ASCEND"}
        self.__status = None  # ACTIVE means this image can be used to create notebook
        self.__swr_path = swr_path
        self.__tag = None
        self.__type = None  # dedicated:the image provided by users, build_in: by notebook team
        self.__update_at = None
        self.__workspace_id = workspace_id
        self.__visibility = visibility  # private or public
        if notebook_util.is_notebook_environ():
            logging.warning("You are now in a notebook or devcontainer and cannot use 'ImageManagement.debug' to "
                            "check your image. If you need to debug it, please use a workstation.")
            return
        if not shutil.which("docker"):
            logging.warning("Your machine has no docker and cannot use 'ImageManagement.debug' to "
                            "check your image. If you need to debug it, please use a workstation installed docker.")
            return
        images_list = DockerCli.images(options=["-q"], swr_path=swr_path)
        if len(images_list) < 1:
            return
        arch_from_swr_path = self._get_arch_from_swr_path()
        if self.__arch:
            if self.__arch.upper() != arch_from_swr_path.upper():
                raise ValueError(f"The architecture of your image {self.__swr_path} is {arch_from_swr_path}, which is "
                                 f"not same with your parameter 'arch'({self.__arch}).")
        self.__arch = arch_from_swr_path

    @staticmethod
    def _check_parameters(swr_path, arch, description, service, resource_category, workspace_id, visibility):
        if not swr_path:
            raise ValueError("The parameter 'swr_path' is needed.")
        if not isinstance(swr_path, str):
            raise TypeError("The parameter 'swr_path' should be a string.")
        if len(swr_path) < Image.SWR_PATH_MIN_LENGTH or len(swr_path) > Image.SWR_PATH_MAX_LENGTH:
            raise ValueError("The length of parameter 'swr_path' should be "
                             f"between 16 and 2048, but it is {len(swr_path)}.")
        if len(swr_path.split("/")) not in [2, 3] or len(swr_path.split(":")) != 2:
            raise ValueError("The swr path should be like <region>/<organization>/<name>:<tag>")
        if len(swr_path.split("/")) == 2:
            swr_path = f"{os.environ.get('IMAGE_REPO_URL')}/{swr_path}"
        if arch:
            if not isinstance(arch, str):
                raise TypeError("The parameter 'arch' should be a string.")
            if arch.upper() not in ImageArch.list():
                raise ValueError(f"The parameter 'arch' should be one of {ImageArch.list()}, but it is {arch}.")
        if description:
            if not isinstance(description, str):
                raise TypeError("The parameter 'description' should be a string.")
            if len(description) > Image.MAX_DESCRIPTION_LENGTH:
                raise ValueError(f"The length of parameter 'description' should be less than "
                                 f"or equal to {Image.MAX_DESCRIPTION_LENGTH}, but it is {len(description)}.")
        Image._check_service(service)
        Image._check_resource_category(resource_category)
        if workspace_id and not isinstance(workspace_id, str):
            raise TypeError("The parameter 'workspace_id' should be a string.")
        if visibility:
            if not isinstance(visibility, str):
                raise TypeError("The parameter 'visibility' should be a string.")
            if visibility.upper() not in ImageVisibility.list():
                raise ValueError(f"The parameter 'visibility' should be one of "
                                 f"{ImageVisibility.list()}, but it is {visibility}.")
        return swr_path

    @staticmethod
    def _check_service(service):
        if not service:
            return
        if not isinstance(service, list):
            raise TypeError("The parameter 'service' should be a list.")
        for svc in service:
            if not isinstance(svc, str):
                raise TypeError("Each element of parameter 'service' should be a string.")
            if svc.upper() not in ModelArtsService.list():
                raise ValueError(f"Each element of parameter 'service' should be one of {ModelArtsService.list()}.")

    @staticmethod
    def _check_resource_category(resource_category):
        if not resource_category:
            return
        if not isinstance(resource_category, list):
            raise TypeError("The parameter 'resource_category' should be a list.")
        for res in resource_category:
            if not isinstance(res, str):
                raise TypeError("Each element of parameter 'resource_category' should be a string.")
            if res.upper() not in ResourceCategory.list():
                raise ValueError(f"Each element of parameter 'resource_category' should be "
                                 f"one of {ResourceCategory.list()}.")

    def _get_arch_from_swr_path(self):
        arch = DockerCli.inspect(name_or_id=self.swr_path, options=["--format", "{{.Architecture}}"])
        if isinstance(arch, bytes):
            arch = arch.decode()
        return Image.DOCKER_ARCH_TO_NOTEBOOK_IMAGE_ARCH[arch.strip().lower()]

    @property
    def swr_path(self):
        return self.__swr_path

    @property
    def arch(self):
        return self.__arch

    @property
    def description(self):
        return self.__description

    @property
    def visibility(self):
        return self.__visibility

    @property
    def dev_services(self):
        return self.__dev_services

    @property
    def resource_category(self):
        return self.__resource_category

    @property
    def workspace_id(self):
        return self.__workspace_id

    @staticmethod
    def get_supported_archs():
        return ImageArch.list()

    @staticmethod
    def get_supported_services():
        return ModelArtsService.list()

    @staticmethod
    def get_supported_resource_categories():
        return ResourceCategory.list()

    @staticmethod
    def get_supported_visibilities():
        return ImageVisibility.list()
