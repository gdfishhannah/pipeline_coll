#!/bin/bash
umask 0027

file_path=$1
service_port=$2

current_path=$(cd `dirname $0`;pwd)
service_ip=127.0.0.1

for filename in `ls ${file_path}`
do
  if [[ $filename == *.m ]]; then
    model_path=${file_path}/${filename}
  fi
done
 
if [ -n "${MODELARTS_SERVICE_PORT}" ]
then
  service_port=${MODELARTS_SERVICE_PORT}
fi

listen_address="${service_ip}:${service_port}"

log_file=${file_path}log.txt
if [ -f "${log_file}" ]; then
  rm -rf "${log_file}"
fi

# start service
export PY_MODEL_ARGS="--model_path=${model_path} --file_path=${file_path}"
 
cd ${current_path} && gunicorn -w 2 -b ${listen_address} flaskTask:app | tee ${log_file}
