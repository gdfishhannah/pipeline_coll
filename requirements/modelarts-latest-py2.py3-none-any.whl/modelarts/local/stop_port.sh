#!/bin/bash
port=$1
tf_server_port=8500
for i in `netstat -nlp | grep ${port} | awk '{print $7}' | awk -F"/" '{ print $1 }'`;do kill -9 $i;done

for i in `netstat -nlp | grep ${tf_server_port} | awk '{print $7}' | awk -F"/" '{ print $1 }'`;do kill -9 $i;done