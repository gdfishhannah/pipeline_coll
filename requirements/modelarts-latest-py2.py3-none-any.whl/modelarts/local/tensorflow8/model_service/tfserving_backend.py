# coding=utf-8
import fcntl
import os
import subprocess as sp
import sys
import time
from contextlib import contextmanager
from multiprocessing import Lock

import psutil
import utils
from configuration.config import Config
from modelarts.local.commons import log
from modelarts import constant

logger = log.getLogger(__name__)

DEFAULT_LOCK_FILE = "/tmp/tf_backend.lock"

MODEL_CONFIG_PATH = '/tmp/model.config'


@contextmanager
def lock(path=DEFAULT_LOCK_FILE):
    f = os.fdopen(os.open(path, os.O_RDWR | os.O_CREAT | os.O_TRUNC, constant.FILE_PERMISSION), "w")
    fd = f.fileno()
    fcntl.lockf(fd, fcntl.LOCK_EX)

    try:
        yield
    finally:
        time.sleep(1)
        fcntl.lockf(fd, fcntl.LOCK_UN)


def get_process_pid_by_name(name="tensorflow_model_server"):
    for proc in psutil.process_iter():
        if proc.name() == name:
            return proc.pid
    raise Exception("can not find tf serving backend , process name: {}".format(name))


class TFServingBackend(object):

    def __init__(self, model_config_path=MODEL_CONFIG_PATH):

        self.model_config_path = model_config_path
        self.pid = None
        self.port = None
        self.running = False
        self.mutex = Lock()
        self.is_running()

    def is_running(self):
        try:
            self.pid = get_process_pid_by_name()
            utils.check_port_is_open(Config.MODELARTS_TFSERVING_GRPC_PORT)
            self.port = Config.MODELARTS_TFSERVING_GRPC_PORT
            self.running = True

        except Exception:
            logger.info("tf serving is not running")
            logger.info("start tf serving backend")
        return

    def stop(self):
        try:
            parent = psutil.Process(self.pid)

            for child in parent.children(recursive=True):
                child.kill()
            parent.kill()
            logger.info("process %s has been killed", self.pid)
        except Exception:
            logger.info("process %s may be finished or killed", self.pid)

    def load(self, model):
        command = "tensorflow_model_server --port=%s --model_base_path=%s --model_name=serve" % (
            Config.MODELARTS_TFSERVING_GRPC_PORT, os.path.abspath(os.path.join(model.path, os.pardir)))
        try:
            p = sp.Popen(command, shell=False, stdout=sys.stdout, stderr=sys.stderr)
            self.pid = p.pid
            # wait for port open
            while True:
                try:
                    utils.check_port_is_open(Config.MODELARTS_TFSERVING_GRPC_PORT)
                    break
                except Exception:
                    logger.info("failed to check tensorflow_model_server listen port, wait next poll")
                    time.sleep(0.5)

            self.port = Config.MODELARTS_TFSERVING_GRPC_PORT
            self.running = True

        except Exception as e:
            logger.error(e, exc_info=True)


class TFServingBackendFactory(object):
    tf_serving_backend = TFServingBackend()

    @classmethod
    def get_instance(cls):
        return cls.tf_serving_backend
