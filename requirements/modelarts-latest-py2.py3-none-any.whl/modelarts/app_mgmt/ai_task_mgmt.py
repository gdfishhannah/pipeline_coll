# coding=utf-8
"""
A ModelArts Task can create Task, get Task info and list,and delete Task.
"""
import os
import sys
from json import JSONEncoder

sys.path.append(os.getcwd())

from modelarts import constant
from modelarts.config.auth import auth_by_apig


class Task(object):
    """
    ModelArts task manager class, used to create, query and delete service
    """

    @staticmethod
    def create(session, service_id, name, input, output, description=None,
               service_config=None):
        """
        Create service task
        :param session: modelarts session
        :param service_id: service ID
        :param name: job name
        :param input: data input list
        :param output: data output list
        :param description: job description
        :param service_config: service config, the field structure is related to the algorithm
        :return: create result
        """
        project_id = session.project_id
        request_url = "/v2/" + project_id + "/vision-services/" + service_id + "/tasks"
        request_body = TaskParam.create_tasks_body(name, input, output, description, service_config)
        request_body = JSONEncoder().encode(request_body).encode("utf8")
        return auth_by_apig(session, constant.HTTPS_POST, request_url, body=request_body)

    @staticmethod
    def list(session, service_id, query_dict):
        """
        Query service job list
        :param session: modelarts session
        :param service_id: service ID
        :param query_dict: query dictionary
        :return: job list
        """
        # get project_id from session
        project_id = session.project_id
        request_url = "/v2/" + project_id + "/vision-services/" + service_id + "/tasks"
        return auth_by_apig(session, constant.HTTPS_GET, request_url, query=query_dict)

    @staticmethod
    def get(session, service_id, task_id):
        """
        query a single task from target service
        :param session: modelarts session
        :param service_id: service ID
        :param task_id: task ID
        :return: job details
        """
        # get project_id from session
        project_id = session.project_id
        request_url = "/v2/" + project_id + "/vision-services/" + service_id + "/tasks/" + task_id
        return auth_by_apig(session, constant.HTTPS_GET, request_url)

    @staticmethod
    def delete(session, service_id, task_id):
        """
        delete service task
        :param session: modelarts session
        :param service_id: service ID
        :param task_id: task ID
        :return: delete result
        """
        # get project_id from session
        project_id = session.project_id
        request_url = "/v2/" + project_id + "/vision-services/" + service_id + "/tasks/" + task_id
        return auth_by_apig(session, constant.HTTPS_DELETE, request_url)


class TaskParam(object):
    """
    Task parameter construction class, which is used to construct parameters in the job management interface
    """

    @staticmethod
    def create_tasks_body(name, input, output, description=None,
                          service_config=None):
        """
        create task request body
        :param name: task name
        :param input: data input list
        :param output: data output list
        :param description: job description
        :param service_config: service config, the field structure is related to the algorithm
        :return: task request body
        """
        request_body = {}
        if name is not None:
            request_body["name"] = name
        if input is not None:
            request_body["input"] = input
        if output is not None:
            request_body["output"] = output
        if description is not None:
            request_body["description"] = description
        if service_config is not None:
            request_body["service_config"] = TaskParam.generate_service_config(service_config)
        return request_body

    @staticmethod
    def generate_input(input):
        """
        Generate input parameters
        :param input: reference input structure
        :return: input parameters
        """
        input_body = {}
        input_type = input["type"]
        if input_type in ['vis', 'obs', 'url', 'vcn']:
            input_body["type"] = input_type
            input_body["data"] = input["data"]
        else:
            raise Exception("incorrect input type, vis, obs, url or vcn")
        return input_body

    @staticmethod
    def generate_output(obs=None, dis=None, webhook=None):
        """
        Generate output parameters
        :param obs: OBS output url
        :param dis: DIS channel settings
        :param webhook: webhook address settings
        :return: output parameters
        """
        output = {}
        if obs is not None:
            output["obs"] = obs
        if dis is not None:
            output["dis"] = dis
        if webhook is not None:
            output["webhook"] = webhook
        return output

    @staticmethod
    def generate_service_config(service_config):
        """
        Generate service_config parameters
        :param service_config: service config, the field structure is related to the algorithm
        :return: service_config parameters
        """
        return service_config

    @staticmethod
    def generate_obs(bucket, path):
        """
        Generate OBS output path
        :param bucket:OBS bucket name
        :param path: OBS path except for bucket
        :return: obs parameters
        """
        obs = {
            "bucket": bucket,
            "path": path
        }
        return obs

    @staticmethod
    def generate_dis(stream_name):
        """
        Generate DIS parameters
        :param stream_name: DIS channel name
        :return: dis parameters
        """
        dis = {
            "stream_name": stream_name
        }
        return dis

    @staticmethod
    def generate_webhook(url, headers):
        """
        Generate Webhook parameters
        :param url: url address
        :param headers: headers
        :return: webhook parameters
        """
        webhook = {
            "url": url,
            "headers": headers
        }
        return webhook
