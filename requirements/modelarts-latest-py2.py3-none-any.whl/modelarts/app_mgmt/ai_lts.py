# coding=utf-8
"""
A ModelArts Service can get service log.
"""
import os
import sys
from json import JSONEncoder

sys.path.append(os.getcwd())

from modelarts import constant
from modelarts.config.auth import auth_by_apig


class LTS(object):
    """
    log tank service management class, which is used to query logs.
    """

    @staticmethod
    def list_logs(lts_endpoint, session, log_group_id, log_stream_id, start_time,
                  end_time, labels):
        """
        Query logs
        :param lts_endpoint: log service endpoint
        :param session: modelarts session
        :param log_group_id: log group id
        :param log_stream_id: log stream id
        :param start_time: search start time (UTC time, in milliseconds)
        :param end_time: search end time (UTC time, in milliseconds)
        :param labels: set of log filtering conditions in which different log sources require different fields
        :return: log details
        """
        project_id = session.project_id
        request_url = "/v2/" + project_id + "/groups/" + log_group_id + "/streams/" + log_stream_id + "/content/query"
        body = {
            "start_time": start_time,
            "end_time": end_time,
            "labels": labels
        }
        session.host = lts_endpoint
        request_body = JSONEncoder().encode(body).encode("utf8")
        return auth_by_apig(session, constant.HTTPS_POST, request_url, body=request_body)
