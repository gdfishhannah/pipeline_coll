"""
Description: This script is only used for toolkit to run distribute training task.
Author: ModelArts SDK Team
"""

import argparse
import ast
import logging
import sys

from modelarts.image_mgmt import ImageSave
from modelarts.scripts.util import get_session
from modelarts.estimatorV2 import Estimator
from modelarts.train_params import InputData, TrainingFiles, OutputData

logging.getLogger().setLevel(logging.INFO)


def save_image(train_args, session):
    """
    :param train_args: it contains the parameters of user input
    :param session: modelarts session
    """
    if train_args.save_image:
        if train_args.is_roma:
            image_save = ImageSave(session=session,
                                   name=train_args.image_name,
                                   tag=train_args.tag,
                                   description=train_args.description)
        else:
            image_save = ImageSave(session=session,
                                   name=train_args.image_name,
                                   tag=train_args.tag,
                                   description=train_args.description,
                                   organization=train_args.organization)
        image_save.save()


def get_inputs(train_args):
    """
    :param train_args: it contains the parameters of user input
    :return: a list containing all the input training data
    """
    input_list = []
    input_data_param_num = 3
    args_input_data = train_args.input_data
    for i in range(train_args.input_num):
        obs_path = args_input_data[i * input_data_param_num]
        if not len(obs_path):
            obs_path = None
        name = args_input_data[i * input_data_param_num + 2]
        if not len(name):
            name = None
        input_data = InputData(obs_path=obs_path,
                               local_path=args_input_data[i * input_data_param_num + 1],
                               name=name,
                               is_local_source=train_args.is_local_source)
        input_list.append(input_data)
    return input_list


def get_outputs(train_args):
    """
    :param train_args: it contains the parameters of user input
    :return: a list containing all the training output data
    """
    output_list = []
    output_data_param_num = 3
    args_output_data = train_args.output_data
    for i in range(train_args.output_num):
        obs_path = args_output_data[i * output_data_param_num]
        if not len(obs_path):
            obs_path = None
        name = args_output_data[i * output_data_param_num + 2]
        if not len(name):
            name = None
        output_data = OutputData(obs_path=obs_path,
                                 local_path=args_output_data[i * output_data_param_num + 1],
                                 name=name)
        output_list.append(output_data)
    return output_list


def parse_input_parameters(args_param):
    """
    Parse user input parameters
    :return: a structure contains all the parameters
    """
    parser = argparse.ArgumentParser(description="This script is used for toolkit of distributed training.")
    # 1. These parameters are used for session initialization
    parser.add_argument("--region_name", type=str, required=True)
    parser.add_argument("--is_roma", type=ast.literal_eval, required=True)
    # for hwc session initialization
    parser.add_argument("--access_key", type=str, required=False)
    parser.add_argument("--secret_key", type=str, required=False)
    # for roma session initialization
    parser.add_argument("--w3_account", type=str, required=False)
    parser.add_argument("--app_id", type=str, required=False)
    parser.add_argument("--app_token", type=str, required=False)

    # 2. These parameters are used to initialize input data
    # The number of input data
    parser.add_argument("--input_num", type=int, default=0, required=False)
    # The parameters for input data are obs_path, local_path and name. If one parameter is not needed, please enter "".
    # If there are multi inputs, you can just add parameters in input_data
    parser.add_argument("--input_data", nargs="*", type=str, required=False)
    parser.add_argument("--is_local_source", type=ast.literal_eval, default=False, required=False)

    # 3. These parameters are used for training files
    parser.add_argument("--code_dir", type=str, required=True)
    parser.add_argument("--boot_file", type=str, required=True)
    parser.add_argument("--code_obs_path", type=str, required=False)

    # 4. These parameters are used for output data
    # The number of output data
    parser.add_argument("--output_num", type=int, default=0, required=False)
    # The parameters for output data are obs_path, local_path and name. If one parameter is not needed, please enter "".
    # If there are multi inputs, you can just add parameters in input_data
    parser.add_argument("--output_data", nargs="*", type=str, required=False)

    # 5. These parameters are used to initialize Estimator
    parser.add_argument("--run_parameters", nargs="*", type=str, required=False)
    parser.add_argument("--framework_type", type=str, required=True)
    parser.add_argument("--train_instance_type", type=str, required=True)
    parser.add_argument("--train_instance_count", type=int, required=True)
    parser.add_argument("--log_url", type=str, required=False)
    parser.add_argument("--job_description", type=str, required=False)

    # 6. These parameters are used to submit a training job
    parser.add_argument("--job_name", type=str, required=False)
    parser.add_argument("--wait", type=ast.literal_eval, required=False)
    parser.add_argument("--priority", type=int, required=False)

    # 7. These parameters are used to save current notebook as a new image
    parser.add_argument("--save_image", type=ast.literal_eval, required=True)
    parser.add_argument("--image_name", type=str, required=False)
    parser.add_argument("--tag", type=str, required=False)
    parser.add_argument("--organization", type=str, required=False)
    parser.add_argument("--description", type=str, required=False, default="")

    return parser.parse_args(args_param)


def organize_input_run_parameters(run_parameters):
    """
    Turn run parameters from user input into expected format.
    :param run_parameters: run_parameters are in the format of key=value
    :return: run parameters of expected format.
    """
    new_parameters = []
    if run_parameters is None:
        return new_parameters
    for i in range(len(run_parameters) // 2):
        new_parameters.append({"name": run_parameters[i * 2], "value": run_parameters[i * 2 + 1]})
    return new_parameters


if __name__ == "__main__":
    args = parse_input_parameters(sys.argv[1:])
    session = get_session(args)
    save_image(args, session)
    inputs = get_inputs(args)
    training_file = TrainingFiles(code_dir=args.code_dir, boot_file=args.boot_file, obs_path=args.code_obs_path)
    outputs = get_outputs(args)
    # submit training job
    estimator = Estimator(session=session,
                          training_files=training_file,
                          outputs=outputs,
                          parameters=organize_input_run_parameters(args.run_parameters),
                          framework_type=args.framework_type,
                          train_instance_type=args.train_instance_type,
                          train_instance_count=args.train_instance_count,
                          log_url=args.log_url,
                          job_description=args.job_description)
    instance = estimator.fit(inputs=inputs, job_name=args.job_name, wait=args.wait, priority=args.priority)
    logging.info("job_id:%s", instance.job_id)
