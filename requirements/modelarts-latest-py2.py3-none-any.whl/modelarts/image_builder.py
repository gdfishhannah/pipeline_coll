import os
import subprocess
import json
import shlex
import shutil
import logging
import re
import tempfile
import time
import signal
import sys
import platform
from threading import Thread
from typing import Dict
from functools import wraps

import yaml
import psutil

from . import constant
from .config.auth import auth_by_apig
from .service import SWRManagement
from .notebook_mgmt import Notebook
from modelarts.util.string_util import query_var
from modelarts.images.image_api import get_image_api_instance
from modelarts.util.notebook_util import is_roma_notebook


def check_call(func):
    @wraps(func)
    def wrapper(*args, **kwargs):
        # only retry when pushed image to swr
        need_retry = kwargs.get("need_retry", True)
        log_info = " " if need_retry else "Invalid base image in your dockerfile. "
        retry_count = constant.SWR_RETRY_TIME + 1 if need_retry else 1
        for _time in range(retry_count):
            try:
                result = func(*args, **kwargs)
            except Exception as e:
                if _time >= retry_count - 1:
                    raise ValueError(f"{log_info}{e}")
                else:
                    time.sleep(constant.SWR_RETRY_INTERVAL)
                    continue
            return result

    return wrapper


def ignore_unused_parameter(*arg):
    return arg


@check_call
def get_swr_image_size(session, image_url, need_retry=False):
    ignore_unused_parameter(need_retry)
    return SWRManagement(session=session).query_image_size(image_url)


@check_call
def get_swr_image_layers(session, image_url, need_retry=False):
    ignore_unused_parameter(need_retry)
    layers = SWRManagement(session=session).query_image_layers(image_url)
    return len(layers) if layers is not None else 0


def get_notebook_arch(session):
    cur_image_id = Notebook(session).get_notebook_info().get('image', {}).get('id')
    if cur_image_id is None:
        return ""
    image_instance = get_image_api_instance(session)
    return image_instance.get_image_by_id(cur_image_id).get("arch")


def get_notebook_swr(session):
    return Notebook(session).get_notebook_info().get('image', {}).get('swr_path')


def is_valid_organization(session, organization):
    return SWRManagement(session=session).is_namespace_exists(namespace=organization)


def complete_build_handler(session, local_path, obs_path, push, image_url=None, remove_local=False):
    summary_info = []
    if image_url is not None:
        repository, tag = image_url.split(":")
        summary_info.extend([f"Repository: {repository}",
                             f"Tag: {tag}"])
    if not push:
        image_size = os.path.getsize(local_path)
        summary_info.append(f"Compressed Image Size: {image_size // 2 ** 20}MB")
        if obs_path is not None:
            session.obs.copy(local_path, obs_path)
            summary_info.append(f"OBS Image Path: {obs_path}")
        if not remove_local:
            summary_info.append(f"Local Image Path: {local_path}")
        else:
            os.remove(local_path)
    else:
        summary_info.append("Compressed Image Size: "
                            f"{get_swr_image_size(session, image_url.split('/', 1)[-1], need_retry=True) // 2 ** 20}MB")
        summary_info.append(f"SWR Download Command: docker pull {image_url}")

    return summary_info


class ContainerBuilder:
    IMAGE_ID = "image_id"
    DOCKERFILE = "dockerfile"

    def __init__(self, session, file_path, image_url=None, context=None, build_args: Dict = None):
        self.file_path = file_path
        self.metadata = None
        self.image_type = None
        self.register = None
        self.image = None
        self.image_builder = None
        self.build_args = None
        self.session = session
        self._parse_yaml()
        self.init_builder(image_url=image_url, context=context, build_args=build_args)

    @staticmethod
    def _load_yaml(file_path):
        if not os.path.exists(file_path):
            raise FileNotFoundError(f"Path {file_path} does not exist.")
        if not file_path.endswith(".yaml") and not file_path.endswith(".yml"):
            raise ValueError(f"Invalid yaml file {file_path}.")
        with open(file_path, 'r') as f:
            try:
                metadata = yaml.safe_load(f.read())
            except Exception as e:
                raise ValueError(f"Invalid devcontainer yaml file, {e}")
        return metadata

    def init_builder(self, image_url=None, context=None, build_args=None):
        if self.image_type.lower() == "dockerfile":
            build_args = build_args if build_args is not None else self.build_args
            # Dockerfile
            self.image_mode = ContainerBuilder.DOCKERFILE
            dockerfile_path = os.path.join(os.path.dirname(self.file_path), self.image)
            self.image_builder = ImageBuilder(session=self.session,
                                              dockerfile_path=dockerfile_path,
                                              image_url=image_url,
                                              context=context,
                                              build_args=build_args)
        else:
            self.image_mode = ContainerBuilder.IMAGE_ID

    def _get_swr_path(self, image_id):
        image_info = Notebook(self.session).get_image_info_by_id(image_id)
        if image_info is None:
            raise ValueError(f"Invalid Image id {image_id} in {self.file_path}, which does not exist.")
        return image_info.get("swr_path")

    def _parse_yaml(self):
        self.metadata = self._load_yaml(self.file_path)
        image_info = self.metadata.get('image')
        if image_info is None:
            raise ValueError(f"Missing image info in yaml {self.file_path}.")
        self.image_type = image_info.get("type")
        self.image = image_info.get("value")
        self.build_args = {item.get("name"): item.get("value") for item in image_info.get("buildArgs", [])}
        self.__check_image_type()
        self.register = self.metadata.get("register")
        if self.register is None:
            return

        self.__check_arch()
        self.__check_resource_category()

    def __check_image_type(self):
        if not isinstance(self.image_type, str):
            raise ValueError(f"Invalid image type {self.image_type} in {self.file_path}, expect str.")
        if self.image_type.lower() not in [ContainerBuilder.IMAGE_ID, ContainerBuilder.DOCKERFILE]:
            raise ValueError(f"Invalid image type {self.image_type} in {self.file_path}.")

    def __check_resource_category(self):
        res_cate = self.register.get("resource_category")
        if res_cate is None:
            return
        if not isinstance(res_cate, list):
            raise ValueError(f"Resource category must be a list in {self.file_path}.")
        cate_set = set(res_cate) - constant.VAILD_RESOURCE_CATEGORY
        if len(cate_set) != 0:
            raise ValueError(f"Resource category: {res_cate} in {self.file_path} is invalid, "
                             f"only supports {constant.VAILD_RESOURCE_CATEGORY}.")
        if "Ascend" in res_cate and "GPU" in res_cate:
            raise ValueError(f"Invalid resource category {res_cate} in {self.file_path}, "
                             "Ascend and GPU are mutually exclusive.")

    def __check_arch(self):
        arch = self.register.get("arch")
        if arch is None:
            return

        if arch not in [constant.X86_ARCH, constant.ARM_ARCH]:
            raise ValueError(f"Arch info {arch} must be one of the {[constant.X86_ARCH, constant.ARM_ARCH]}.")
        notebook_arch = get_notebook_arch(session=self.session)
        if notebook_arch != "" and arch != notebook_arch.upper():
            raise ValueError(f"Invalid arch info {arch} in {self.file_path}, "
                             f"current notebook only supports {notebook_arch.upper()}.")

    def build_push(self, asynchrony=False, log_path=None, simple_log=False,
                   local_path=None, obs_path=None, tty=False):
        return_value = self._get_swr_path(self.image) if self.image_mode == ContainerBuilder.IMAGE_ID \
            else self.image_builder.build_push(asynchrony=asynchrony,
                                               log_path=log_path,
                                               simple_log=simple_log,
                                               local_path=local_path,
                                               obs_path=obs_path,
                                               tty=tty)
        return dict(type=self.image_mode, value=return_value, extra_params=dict(image_type=self.image_type,
                                                                                image_id=self.image,
                                                                                register=self.register
                                                                                ))


class ImageBuilder(object):
    def __init__(self, session, dockerfile_path: str, image_url: str = None, context: str = None,
                 build_args: Dict = None, image_name: str = None):
        """
        Initialize a image builder, determine the attributes of the image build.
        :param session: Building interactions with Cloud service.
        :param dockerfile_path: dockerfile path
        :param image_url: container image organization, name, tag
        :param context: image build context
        :param build_args: build args for dockerfile
        :param image_name: container image organization, name, tag, which has been deprecated
        """
        if image_name is not None:
            logging.warning("image_name is deprecated and has been removed. Please use image_url instead.")
            image_url = image_url if image_url is not None else image_name
        self.context = context
        self.dockerfile_path = dockerfile_path
        self.session = session
        self.image_url = image_url
        self.build_args = dict() if build_args is None else build_args
        self._check_param(dockerfile_path, context)
        self._check_image_url()

        swr_endpoint = query_var(cfg_var=f"SWR_{session.region_name}", env_var="SWR_ENDPOINT", remove_prefix=True)
        self.repo_url = swr_endpoint.replace("swr-api", "swr") if "swr-api" in swr_endpoint else swr_endpoint
        self.swr_host = swr_endpoint.replace("swr", "swr-api") if "swr-api" not in swr_endpoint else swr_endpoint

        self._init_auth()
        self.after_build_callback = None

    @staticmethod
    def _get_buildctl_cmd():
        return "{} --addr tcp://127.0.0.1:1234".format(os.getenv("BUILDKIT_DIR"))

    @staticmethod
    def _get_filename(file_path):
        """
        Get buildkit dockerfile path and filename path
        """
        return os.path.dirname(file_path), os.path.basename(file_path)

    @classmethod
    def disk_usage(cls, is_print=True):
        """
        view the cache of disk in building image
        """
        buildctl_cmd = cls._get_buildctl_cmd()
        cmd = "{} du".format(buildctl_cmd)
        result = subprocess.getstatusoutput(cmd)
        if is_print:
            print(result[1])
        return result

    @classmethod
    def prune_cache(cls, is_print=True):
        """
        prune the cache of disk in building image
        """
        buildctl_cmd = cls._get_buildctl_cmd()
        cmd = "{} prune".format(buildctl_cmd)
        result = subprocess.getstatusoutput(cmd)
        if is_print:
            print(result[1])
        return result

    def _check_image_url(self):
        if not self.image_url:
            raise Exception(f"The image url {self.image_url} is invalid!")
        image_url_info = self.image_url.split("/")
        if len(self.image_url.split(":")) <= 1 or (len(image_url_info) < 1 or len(image_url_info) > 2):
            raise Exception("Invalid image url, please follow 'organization/image_name:tag'.")
        if len(image_url_info) == 2:
            organization = image_url_info[0]
            if is_roma_notebook():
                return
            if not is_valid_organization(self.session, organization):
                raise ValueError(f"Invalid image url, organization {organization} does not exist.")

    def _check_param(self, dockerfile_path, context):
        if not os.getenv('IMAGE_REPO_URL'):
            raise Exception("The function of building image only applies to Modelarts Notebook or Devcontainer!")

        if not os.getenv("BUILDKIT_DIR"):
            raise Exception("The build image need buildkit, which is not supported now!")

        if not os.path.isfile(dockerfile_path):
            raise Exception(f"Dockerfile path {dockerfile_path} does not exist.")

        if context is not None and not os.path.isdir(context):
            raise Exception(f"Image context path {context} does not exist.")
        if context is None:
            context = os.path.dirname(dockerfile_path)
        self.context = context
        self._check_base_image()

    def _check_base_image(self):
        # Only check image size from swr repository
        try:
            from dockerfile_parse import DockerfileParser
        except ImportError:
            return
        with os.fdopen(os.open(self.dockerfile_path, os.O_RDONLY, constant.FILE_PERMISSION), "r") as fp:
            dfp = DockerfileParser(fileobj=fp, build_args=self.build_args)
            if dfp.baseimage is None:
                raise ValueError(f"Dockerfile does not contain base image info in {self.dockerfile_path}.")
            if not dfp.baseimage.startswith("swr"):
                print("\033[93m Warning: Skip checking the base image which is not from swr. \033[0m")
                return
            base_image = dfp.baseimage.split("/", 1)[-1]
            real_image_size = get_swr_image_size(session=self.session, image_url=base_image, need_retry=False)
            real_image_layers = get_swr_image_layers(session=self.session, image_url=base_image, need_retry=False)
            if real_image_size is not None and real_image_size > constant.LIMIT_BUILDKIT_IMAGE_SIZE:
                raise ValueError("Base image in dockerfile must be smaller than "
                                 f"{constant.LIMIT_BUILDKIT_IMAGE_SIZE // (2 ** 20)} MB, "
                                 f"but got {real_image_size // (2 ** 20)} MB.")
            if real_image_layers > constant.LIMIT_BUILDKIT_IMAGE_LAYERS:
                raise ValueError("The layer of base image in dockerfile must be smaller than "
                                 f"{constant.LIMIT_BUILDKIT_IMAGE_LAYERS}, "
                                 f"but got {real_image_layers}.")

    def _check_output(self, push=True, local_path=None, obs_path=None):
        remove_local = False
        tarball_name = f"{self.image_url.split(':')[0].rsplit('/', -1)[-1]}.tar"
        if not push:
            if local_path is None:
                local_path = os.path.abspath(os.path.join(tempfile.mkdtemp(), tarball_name))
                remove_local = True
            else:
                if local_path.endswith(".tar"):
                    # deal with "" situation
                    if os.path.dirname(local_path):
                        os.makedirs(os.path.dirname(local_path), exist_ok=True)
                    tarball_name = os.path.basename(local_path)
                    local_path = os.path.abspath(local_path)
                else:
                    raise ValueError(f"local path must end with .tar, but got {local_path}.")
        else:
            if local_path is not None:
                print("\033[93m Warning: Built image will be pushed to swr repository, "
                      f"local path {local_path} will be ignored. \033[0m")
        if obs_path is not None:
            if not obs_path.startswith(constant.OBS_HEAD_FORMAT):
                raise ValueError(f"Invalid obs path {obs_path}, which should start with {constant.OBS_HEAD_FORMAT}.")
            if not self.session.obs.is_bucket_exists(obs_path.split("/")[2]):
                raise ValueError(f"Bucket {obs_path.split('/')[2]} does not exist.")
            if not obs_path.endswith(".tar"):
                if not obs_path.endswith("/"):
                    obs_path = obs_path + "/"
                obs_path = obs_path + tarball_name
        return local_path, obs_path, remove_local

    def _get_swr_auth(self):
        """
        Send a request to swr service to get auth
        """
        request_url = "/v2/manage/utils/secret"
        return auth_by_apig(self.session, constant.HTTPS_POST, request_url, host=self.swr_host)

    def _init_auth(self):
        """
        Config .docker/config.json
        """
        try:
            swr_auth = self._get_swr_auth()
        except Exception as e:
            raise Exception('Failed to init swr auth. The reason is : %s' % e)

        user_home = os.getenv("HOME", "/home/ma-user")
        docker_path = os.path.join(user_home, ".docker")
        if not os.path.isdir(docker_path):
            os.makedirs(docker_path, exist_ok=True)

        docker_config_path = os.path.join(docker_path, "config.json")
        config_path = os.path.realpath(docker_config_path)
        try:
            with os.fdopen(os.open(config_path, os.O_WRONLY | os.O_CREAT | os.O_TRUNC,
                                   constant.FILE_PERMISSION), "w") as wf:
                wf.write(json.dumps(swr_auth))
        except Exception as e:
            raise Exception("Failed to generate the docker config file. The reason is: %s" % e)

    def build_push(self, asynchrony=False, log_path=None, simple_log=False,
                   local_path=None, obs_path=None, tty=False):

        """
        build image by using buildctl
        :return: image build result
        """
        if tty and (platform.system() == "Windows" or is_notebook()):
            tty = False
            simple_log = True
            logging.warning("tty mode does not support in current environment, simple log mode will be used.")

        push = True if local_path is None and obs_path is None else False
        if push and len(self.image_url.split('/')) == 1:
            raise ValueError("Invalid image url, please provide swr organization info when push to remote swr.")
        local_path, obs_path, remove_local = self._check_output(push=push, local_path=local_path, obs_path=obs_path)
        if push:
            image_path = "{}/{}".format(self.repo_url, self.image_url)
            output = "--output type=image,name={},push=true".format(image_path)
        else:
            image_path = self.image_url
            output = f"--output type=docker,name={image_path},dest={local_path}"
        self.after_build_callback = (complete_build_handler,
                                     dict(session=self.session,
                                          local_path=local_path,
                                          obs_path=obs_path,
                                          push=push,
                                          image_url=image_path,
                                          remove_local=remove_local))
        buildctl_cmd = self._get_buildctl_cmd()
        dir_name, base_name = self._get_filename(self.dockerfile_path)
        opt_var = ""
        for k, v in self.build_args.items():
            opt_var += f"--opt build-arg:{k}={v} "
        sh_cmd = "{} build --frontend dockerfile.v0 --local context={} --local dockerfile={} " \
                 "{} --opt filename={} {}".format(buildctl_cmd, self.context, dir_name, opt_var, base_name, output)
        if log_path is not None:
            os.makedirs(os.path.dirname(log_path), exist_ok=True)
        log_path = log_path if log_path is not None else \
            os.path.join(os.path.dirname(self.dockerfile_path), "build_log.log")
        return Processor(sh_cmd, asynchrony=asynchrony, log_path=log_path,
                         simple_log=simple_log, tty=tty, callback=self.after_build_callback)


class Processor:
    FAILED = "failed"
    RUNNING = "running"
    UPLOADING = "uploading"
    COMPLETED = "completed"

    def __init__(self, sh_cmd, session=None, log_path="build_log.log",
                 asynchrony=False, simple_log=False, tty=False, callback=None):
        self.step_pattern = re.compile(r"\[internal].*|\[(\s|\w){1,3}/\d{1,3}] .*")
        self.time_pattern = re.compile(r"DONE .*s")
        self.push_pattern = re.compile(r"exporting .*|pushing .*")
        self.error_pattern = re.compile(r"ERROR:.*|WARNING .*")
        self.session = session
        self.simple_log = simple_log
        self.log_path = log_path
        self.callback = callback
        self.disk_usage = None
        self.previous_pattern = None
        self.is_step_change = True
        self.during_part_time = None
        self.summary_info = None
        self.global_stop_signal = False
        self.tty = tty
        if tty:
            from ptyprocess import PtyProcessUnicode

            width, height = shutil.get_terminal_size()
            self.proc = PtyProcessUnicode.spawn(shlex.split(sh_cmd), dimensions=(height, width))
        else:
            self.proc = subprocess.Popen(shlex.split(sh_cmd), shell=False,
                                         stdout=subprocess.PIPE,
                                         stderr=subprocess.STDOUT)
        self.__status = Processor.RUNNING
        self.start_time = time.time()
        signal.signal(signal.SIGINT, self.recover_terminal_env_handler)
        if platform.system() != "Windows":
            signal.signal(signal.SIGTSTP, self.recover_terminal_env_handler)

        if not asynchrony:
            self._capture_output(True, True)
            if self.status != Processor.FAILED:
                self.__status = Processor.COMPLETED
        else:
            t = Thread(target=self._capture_output,
                       args=(False, False))
            t.setDaemon(True)
            t.start()
        reset_terminal()

    @staticmethod
    def recover_terminal_env_handler(_, __):
        reset_terminal()
        sys.exit(0)

    @property
    def status(self):
        return self.get_status()

    @property
    def summary(self):
        return self.summary_info

    @staticmethod
    def print_terminal(print_line=None, simple_log=False, is_flush=False, previous_line_len=0):
        # print full log or simple log to console
        if simple_log:
            print('\r' + " " * previous_line_len, end="", flush=is_flush)
        # print full line to notebook output, but only print one line to terminal
        print_line = print_line if is_notebook() or not is_flush else \
            print_line[:min(len(print_line), shutil.get_terminal_size()[0])]
        print('\r' + print_line, end="" if is_flush else "\n", flush=is_flush)
        return print_line

    @staticmethod
    def _remove_redundancy_symbol(origin_str):
        """
        remove the symbol of "#" from buildctl build result
        origin_str: #1 [internal] load build definition from ./Dockerfile
        return str: [internal] load build definition from ./Dockerfile
        """
        num = origin_str.find(" ")
        new_str = origin_str[num:len(origin_str)] if num > 0 else ""
        return new_str

    @staticmethod
    def convert_time(during):
        if during <= 60:
            return f"{during:.1f}s"
        during = int(during)
        minute = during // 60
        if minute <= 60:
            return f"{minute}min {int(during) % 60}s"
        hour = minute // 60
        return f"{hour}h {int(minute) % 60}min {int(during) % 60}s"

    def cache_usage_watcher(self):
        while self._is_running() and not self.global_stop_signal:
            usage_rate = get_disk_info(constant.BUILDKIT_MOUNT_PATH).get("usage_rate", -1)
            if usage_rate > constant.LIMIT_USAGE_RATE:
                ImageBuilder.prune_cache(is_print=False)
                self.stop()
                raise ValueError(f"Stop building image: disk usage rate is {usage_rate * 100}% which "
                                 f"exceeds {constant.LIMIT_USAGE_RATE * 100}%.")

            pattern = re.compile(r"Total:\t*[0-9]\d*\.?\d.*")
            usage_log = ImageBuilder.disk_usage(is_print=False)
            if usage_log[0] != 0:
                continue
            res = pattern.search(usage_log[-1])
            if res is None:
                continue
            usage = res.group().lstrip("Total:").strip()
            self.disk_usage = usage
            if usage.endswith("GB"):
                usage_cache = float(usage.rstrip("GB"))
                if usage_cache >= constant.LIMIT_BUILDKIT_DISK_USAGE and usage_rate > 0.5:
                    ImageBuilder.prune_cache(is_print=False)
                    self.stop()
                    raise ValueError(f"Stop building image: disk usage is {usage_cache}GB which"
                                     f"exceeds {constant.LIMIT_BUILDKIT_DISK_USAGE}GB.")
            time.sleep(constant.DISK_USAGE_RETRY_INTERVAL)

    def _summary(self, during=None, is_print=True):
        during = time.time() - self.start_time if during is None else during
        summary_list = [""] * 2
        summary_info = "Summary Board"
        build_time = f"Image Build Time: {self.convert_time(during)}"
        summary_list.append(build_time)
        if self.callback:
            args = self.callback[1]
            if not args.get("push", True) and args.get("obs_path", None):
                self.__status = Processor.UPLOADING
            summary_list.extend(self.callback[0](**args))
        max_summary_len = max([len(item) for item in summary_list]) + 1
        summary_list.append("*" * (max_summary_len + 3))
        summary_list[0] = "*" * (max_summary_len + 3)
        summary_list[1] = f"*{summary_info:^{max_summary_len}} *"
        for index, item in enumerate(summary_list[2:-1]):
            summary_list[index + 2] = f"* {item:<{max_summary_len}}*"
        if is_print:
            print("\n" + "\n".join(summary_list))
        return summary_list

    def _capture_output(self, terminal=True, print_summary=True):
        watcher = Thread(target=self.cache_usage_watcher)
        watcher.setDaemon(True)
        watcher.start()

        f_simple = None if (not self.simple_log or self.tty) else \
            os.fdopen(os.open(os.path.join(os.path.dirname(self.log_path), "simple_log.log"),
                              os.O_WRONLY | os.O_CREAT | os.O_TRUNC, constant.FILE_PERMISSION), "w")
        with os.fdopen(os.open(self.log_path, os.O_WRONLY | os.O_CREAT | os.O_TRUNC,
                               constant.FILE_PERMISSION), "w") as f_full:
            if self.tty:
                self._write_with_tty(file_full=f_full, terminal=terminal)
            else:
                self._write_with_plain(file_full=f_full, file_simple=f_simple, terminal=terminal)

            if not self.global_stop_signal and self._is_running_completed():
                self.summary_info = "\n".join(self._summary(is_print=print_summary))
                f_full.write(self.summary_info + "\n")
                f_full.flush()
            else:
                print(f"\n\033[91m Failed to build image, for details, see {os.path.abspath(self.log_path)}.\033[0m")
        if f_simple is not None and not self.global_stop_signal and self._is_running_completed():
            f_simple.write("\n" + self.summary_info)
            f_simple.close()
        self.__status = Processor.COMPLETED

    def _write_with_plain(self, file_full, file_simple, terminal=False):
        previous_line_len, tail = 0, 0
        while self.proc.poll() is None and not self.global_stop_signal:
            line = self.proc.stdout.readline()
            line = line.strip().decode()
            if line is None:
                continue

            line, is_flush = self._format_output(line)
            # write full log to file
            file_full.write(line + "\n")
            file_full.flush()
            if not self.simple_log:
                is_flush = False
            else:
                # write simple log to file
                tail = write_simple_log(file_simple, line, tail, previous_line_len, is_flush=is_flush)
            if terminal:
                line = self.print_terminal(print_line=line, simple_log=self.simple_log,
                                           is_flush=is_flush, previous_line_len=previous_line_len)
            previous_line_len = len(line) if is_notebook() else min(len(line), shutil.get_terminal_size()[0])

    def _write_with_tty(self, file_full, terminal=False):
        while self.proc.isalive() and not self.global_stop_signal:
            file_full.flush()
            try:
                line = self.proc.readline().rstrip()
            except Exception:
                break
            if terminal:
                print(line)
            if "[+] Building" in line:
                file_full.seek(0)
            file_full.write(line + "\n")

    def _is_running_completed(self):
        return (not self.proc.isalive() and self.proc.exitstatus == 0) if self.tty else self.proc.poll() == 0

    def _is_running(self):
        return self.proc.poll() is None if not self.tty else self.proc.isalive()

    def _format_output(self, origin_str):
        """
        Filter step and time info from output, other info will be flushed.
        """
        for pattern in [self.step_pattern, self.time_pattern, self.push_pattern, self.error_pattern]:
            log_info = pattern.search(origin_str)
            if log_info is None:
                continue
            if pattern == self.step_pattern:
                if self.previous_pattern == log_info.group():
                    self.is_step_change = False
                    self.during_part_time = None
                    return log_info.group(), True
                else:
                    self.previous_pattern = log_info.group()
                    self.is_step_change = True
                    if self.during_part_time is not None:
                        return_value = self.during_part_time + "\n" + log_info.group()
                        self.during_part_time = None
                        return return_value + log_info.group(), False

            if pattern == self.time_pattern and not self.is_step_change:
                self.during_part_time = log_info.group()
                return log_info.group(), True
            return log_info.group(), False
        return self._remove_redundancy_symbol(origin_str), True

    def get_status(self):
        if self.tty:
            self.proc.isalive()
            return_code = self.proc.exitstatus
        else:
            return_code = self.proc.poll()
        if return_code is None:
            self.__status = Processor.RUNNING
            return self.__status
        if return_code != 0:
            self.__status = Processor.FAILED
        if self.__status != Processor.COMPLETED:
            return self.__status
        return self.__status

    def stop(self):
        self.proc.close() if self.tty else self.proc.terminate()
        self.global_stop_signal = True

    def get_output(self):
        if self.status != Processor.RUNNING:
            logging.info(f"Build process has been stopped, build log: {os.path.abspath(self.log_path)}.")
            return ""
        with open(self.log_path, "r") as f:
            return f.read()


def write_simple_log(file, line, tail, previous_line_len, is_flush=False):
    file.seek(tail)
    if not is_flush:
        file.write(line + "\n")
        tail = file.tell()
    else:
        file.write('\r' + " " * previous_line_len)
        file.flush()
        file.seek(tail)
        file.write("\r" + line.rstrip())
    file.flush()
    return tail


def is_notebook():
    try:
        # Jupyter notebook or qt console
        from IPython import get_ipython
        return get_ipython().__class__.__name__ == "ZMQInteractiveShell"
    except ImportError:
        return False


def get_disk_info(disk_path: str = None) -> Dict:
    disk_path = disk_path if disk_path is not None else constant.BUILDKIT_MOUNT_PATH
    if not os.path.exists(disk_path):
        return dict(total=-1, used=-1, free=-1, usage_rate=0)
    total, used, free, percent = psutil.disk_usage(disk_path)
    return dict(
        total=safe_divide(total, (2 ** 30)),
        used=safe_divide(used, (2 ** 30)),
        free=safe_divide(free, (2 ** 30)),
        usage_rate=percent / 100
    )


def safe_divide(numerator, denominator):
    try:
        result = float(numerator / denominator)
    except ZeroDivisionError as e:
        raise ValueError('obs_constant.MAX_BLOCK_SIZE can not be zero') from e
    return round(result, 2)


def reset_terminal():
    # set default terminal font color
    print("\033[0m\033[0m", end="")
    # show cursor in terminal
    print("\033[?25h", end="")
